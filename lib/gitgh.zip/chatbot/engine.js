// lib/chatbot/engine.js - MOTOR REAL CONECTADO A TU BD
import { query } from '../database';

// ============================================================================
// ENGINES BÁSICOS Y FUNCIONALES - SOLO BD REAL
// ============================================================================

class SynonymManager {
  constructor() {
    this.isInitialized = false;
    this.synonyms = {};
  }

  async initialize() {
    this.synonyms = {
      'tehilim': ['salmos', 'psalms', 'tehillim'],
      'torah': ['tora', 'pentateuco', 'jumash', 'chumash'],
      'sidur': ['siddur', 'sidurim', 'oraciones'],
      'talit': ['tallit', 'tallitot', 'manto'],
      'tefilin': ['tefilín', 'phylacteries', 'filacterias'],
      'mezuza': ['mezuzah', 'mezuzot', 'pergamino'],
      'shabbat': ['shabat', 'sabbath'],
      'kipa': ['kipá', 'yarmulke', 'solideo'],
      'emunah': ['fe', 'creencia'],
      'breslov': ['braslav', 'breslev']
    };
    this.isInitialized = true;
  }

  expandQuery(query) {
    let expanded = [query.toLowerCase()];
    const words = query.toLowerCase().split(' ');
    
    words.forEach(word => {
      const synonyms = this.synonyms[word] || [];
      expanded.push(...synonyms);
    });
    
    return [...new Set(expanded)];
  }
}

class IntentClassifier {
  constructor() {
    this.isInitialized = false;
  }

  async initialize() {
    this.intentPatterns = {
      greeting: {
        patterns: [/^(hola|hello|shalom|buenos|buenas|hey)/i],
        confidence: 0.95
      },
      product_search: {
        patterns: [
          /(busco|necesito|quiero|ver|mostrar|tienen|hay|venden)/i,
          /(tehilim|torah|sidur|talit|tefilin|mezuza|kipa|shofar|menorah)/i,
          /(libro|libros|articulo|producto)/i
        ],
        confidence: 0.90
      },
      price_inquiry: {
        patterns: [/(precio|cuesta|vale|cuanto|costo)/i],
        confidence: 0.88
      },
      availability_check: {
        patterns: [/(disponible|stock|hay|existe)/i],
        confidence: 0.85
      }
    };
    this.isInitialized = true;
  }

  async classifyIntent(message) {
    const results = [];
    let maxConfidence = 0;
    let primaryIntent = null;

    for (const [intentType, config] of Object.entries(this.intentPatterns)) {
      let matches = 0;
      
      for (const pattern of config.patterns) {
        if (pattern.test(message)) {
          matches++;
        }
      }

      if (matches > 0) {
        const confidence = (matches / config.patterns.length) * config.confidence * 100;
        results.push({ type: intentType, confidence });

        if (confidence > maxConfidence) {
          maxConfidence = confidence;
          primaryIntent = { type: intentType, confidence };
        }
      }
    }

    return {
      primary: primaryIntent || { type: 'general_inquiry', confidence: 50 },
      all: results,
      confidence: maxConfidence
    };
  }
}

class ResponseGenerator {
  constructor() {
    this.isInitialized = false;
  }

  async initialize() {
    this.isInitialized = true;
  }

  formatProductList(products, searchTerm) {
    if (!products || products.length === 0) {
      return `No encontré productos para "${searchTerm}" en nuestra base de datos.

Para consulta directa:
https://wa.me/573009291156?text=Busco%20${encodeURIComponent(searchTerm)}

Sitio web: https://www.judaicabreslovcolombia.com`;
    }

    let response = `Productos encontrados para "${searchTerm}":\n\n`;
    
    products.slice(0, 5).forEach((product, index) => {
      const price = new Intl.NumberFormat('es-CO').format(product.display_price);
      response += `${index + 1}. **${product.name}**\n`;
      response += `Precio: $${price}\n`;
      response += `Estado: ${this._formatStock(product.stock_status)}\n`;
      if (product.short_description) {
        response += `${product.short_description.substring(0, 100)}...\n`;
      }
      response += `https://www.judaicabreslovcolombia.com/producto/${product.slug}\n\n`;
    });

    response += `Contacto: https://wa.me/573009291156`;
    return response;
  }

  _formatStock(status) {
    const statusMap = {
      'in_stock': 'Disponible',
      'out_of_stock': 'Agotado',
      'on_backorder': 'En pedido'
    };
    return statusMap[status] || 'Consultar';
  }
}

// ============================================================================
// MOTOR PRINCIPAL - SOLO BD REAL
// ============================================================================

export class AdvancedMultiEngineChatbot {
  constructor() {
    this.engines = {
      synonymManager: new SynonymManager(),
      intentClassifier: new IntentClassifier(),
      responseGenerator: new ResponseGenerator()
    };

    this.isInitialized = false;
    console.log('Motor inicializado - Solo BD real');
  }

  async initialize() {
    if (this.isInitialized) return true;

    try {
      console.log('Inicializando motor con BD real...');
      
      // Verificar conexión a BD
      await query('SELECT 1');
      console.log('Conexión a BD verificada');

      // Inicializar engines
      await this.engines.synonymManager.initialize();
      await this.engines.intentClassifier.initialize();
      await this.engines.responseGenerator.initialize();

      // Verificar productos en BD
      const productCount = await query("SELECT COUNT(*) as count FROM products WHERE status = 'active'");
      console.log(`Productos activos en BD: ${productCount[0]?.count || 0}`);

      this.isInitialized = true;
      console.log('Motor inicializado completamente');
      return true;
      
    } catch (error) {
      console.error('Error inicializando motor:', error);
      throw error;
    }
  }

  async processMessage(message, conversationId, sessionId, userContext = {}) {
    const startTime = Date.now();
    
    try {
      await this.initialize();
      
      console.log(`Procesando mensaje: "${message}"`);

      // Clasificar intención
      const intentResult = await this.engines.intentClassifier.classifyIntent(message);
      console.log(`Intención detectada: ${intentResult.primary.type} (${intentResult.primary.confidence.toFixed(1)}%)`);

      // Procesar según intención
      let result;
      switch (intentResult.primary.type) {
        case 'greeting':
          result = await this._handleGreeting();
          break;
        case 'product_search':
        case 'price_inquiry':
        case 'availability_check':
          result = await this._handleProductSearch(message);
          break;
        default:
          result = await this._handleGeneral(message);
      }

      // Agregar metadata
      result.intent = intentResult.primary.type;
      result.confidence = intentResult.primary.confidence / 100;
      result.processingTime = Date.now() - startTime;

      console.log(`Procesamiento completado en ${result.processingTime}ms`);
      return result;

    } catch (error) {
      console.error('Error procesando mensaje:', error);
      return this._generateErrorResponse(error, message);
    }
  }

  async _handleGreeting() {
    return {
      success: true,
      response: `¡Shalom! Bienvenido a Judaica Breslov Colombia.

Soy tu asistente para productos judaicos auténticos.

¿En qué puedo ayudarte?
• Libros (Tehilim, Torah, Sidur)
• Artículos religiosos (Tefilín, Talit, Mezuzot)
• Artículos para Shabbat
• Joyería judaica

Contacto directo: https://wa.me/573009291156`,
      requiresHuman: false,
      suggestions: ['Buscar libros', 'Ver artículos religiosos', 'Contactar asesor'],
      products: []
    };
  }

  async _handleProductSearch(message) {
    try {
      console.log('Buscando productos en BD real...');

      // Expandir términos de búsqueda
      const expandedTerms = this.engines.synonymManager.expandQuery(message);
      console.log('Términos expandidos:', expandedTerms);

      // Construir consulta SQL
      const searchConditions = expandedTerms.map(() => `
        LOWER(p.name) LIKE ? OR 
        LOWER(COALESCE(p.description, '')) LIKE ? OR
        LOWER(COALESCE(p.short_description, '')) LIKE ? OR
        LOWER(COALESCE(p.tags, '')) LIKE ?
      `).join(' OR ');

      const sqlQuery = `
        SELECT 
          p.id, p.name, p.slug, p.price, p.sale_price,
          p.stock_status, p.featured, p.description, p.short_description,
          CASE 
            WHEN p.sale_price IS NOT NULL AND p.sale_price > 0 
            THEN p.sale_price 
            ELSE p.price 
          END as display_price
        FROM products p
        WHERE p.status = 'active' 
          AND (${searchConditions})
        ORDER BY p.featured DESC, p.price ASC
        LIMIT 8
      `;

      // Preparar parámetros
      const queryParams = [];
      expandedTerms.forEach(term => {
        const likeTerm = `%${term}%`;
        queryParams.push(likeTerm, likeTerm, likeTerm, likeTerm);
      });

      console.log('Ejecutando consulta SQL...');
      const products = await query(sqlQuery, queryParams);
      
      console.log(`Productos encontrados: ${products.length}`);
      
      if (products.length > 0) {
        console.log('Productos reales de BD:', products.map(p => p.name));
      }

      // Generar respuesta
      const responseText = this.engines.responseGenerator.formatProductList(products, message);

      return {
        success: true,
        response: responseText,
        requiresHuman: products.length === 0,
        suggestions: products.length > 0 ? ['Ver más detalles', 'Consultar disponibilidad'] : ['Contactar asesor', 'Ver catálogo'],
        products: products
      };

    } catch (error) {
      console.error('Error en búsqueda de productos:', error);
      return {
        success: false,
        response: `Error al buscar productos en la base de datos.

Para asistencia inmediata:
https://wa.me/573009291156?text=Error%20búsqueda%20${encodeURIComponent(message)}`,
        requiresHuman: true,
        suggestions: ['Contactar soporte'],
        products: []
      };
    }
  }

  async _handleGeneral(message) {
    return {
      success: true,
      response: `Entiendo tu consulta sobre "${message}".

Te ayudo con productos judaicos auténticos:
• Libros religiosos
• Artículos rituales  
• Objetos para el hogar judío

Para consulta específica:
https://wa.me/573009291156?text=${encodeURIComponent(message)}

Sitio web: https://www.judaicabreslovcolombia.com

¿Podrías ser más específico sobre lo que necesitas?`,
      requiresHuman: false,
      suggestions: ['Ver productos', 'Contactar asesor'],
      products: []
    };
  }

  _generateErrorResponse(error, message) {
    const errorId = Math.random().toString(36).substr(2, 9);
    
    return {
      success: false,
      response: `Error del sistema (${errorId})

Disculpa, hay un problema técnico con la base de datos.

Contacto inmediato:
https://wa.me/573009291156?text=Error%20${errorId}%20-%20${encodeURIComponent(message)}

Error: ${error.message}`,
      intent: 'system_error',
      confidence: 0,
      requiresHuman: true,
      suggestions: ['Contactar WhatsApp', 'Intentar de nuevo'],
      products: [],
      metadata: {
        errorId,
        timestamp: Date.now()
      }
    };
  }

  // Método para estadísticas del sistema
  getSystemStats() {
    return {
      status: this.isInitialized ? 'active' : 'inactive',
      engines: Object.keys(this.engines).length,
      version: 'real-db-v1.0',
      timestamp: new Date().toISOString()
    };
  }

  // Método para mantenimiento
  async performMaintenance() {
    console.log('Realizando mantenimiento...');
    
    try {
      // Verificar conexión BD
      await query('SELECT 1');
      console.log('Mantenimiento: BD conectada OK');
      
      // Verificar productos
      const count = await query("SELECT COUNT(*) as count FROM products WHERE status = 'active'");
      console.log(`Mantenimiento: ${count[0]?.count || 0} productos activos`);
      
      return { success: true, message: 'Mantenimiento completado' };
    } catch (error) {
      console.error('Error en mantenimiento:', error);
      return { success: false, error: error.message };
    }
  }
}