// lib/chatbot/intents-expandido.js - CLASIFICADOR ULTRA-COMPLETO JUDAICA BRESLOV COLOMBIA
import { query } from '../database';

export class IntentClassifier {
  constructor() {
    this.intentCache = new Map();
    this.cacheTimeout = 10 * 60 * 1000; // 10 minutos

    // INTENCIONES ULTRA-EXPANDIDAS PARA JUDAICA BRESLOV COLOMBIA
    this.intents = {
      
      // 💰 CONSULTAS DE PRECIO (35% de las consultas) - EXPANDIDO
      price_inquiry: {
        name: 'price_inquiry',
        description: 'Consultas sobre precios de productos',
        patterns: [
          // Patrones directos de precio
          /cuánto (cuesta|vale|es|sale|precio)/i,
          /precio (de|del|para|por)\s*(.+)/i,
          /valor (de|del)\s*(.+)/i,
          /(.+)\s+cuánto/i,
          /presupuesto\s+(para|de)\s*(.+)/i,
          /cotizar\s+(.+)/i,
          /costo\s+(de|del)\s*(.+)/i,
          
          // Productos específicos con precio
          /(tehilim|torah|breslov|emunah|sidur|jumash|talmud|zohar|kipá|tzitzit|tallit|tefilín)\s+(cuánto|precio|vale|cuesta)/i,
          /cuánto\s+(tehilim|torah|breslov|emunah|sidur|jumash|talmud|zohar|kipá|tzitzit|tallit|tefilín)/i,
          /(copa\s+kidush|bandeja\s+pan|velas\s+shabat|aceite\s+jerusalén)\s+(precio|cuánto)/i,
          /(shalom\s+arush|najmán\s+breslov|libros\s+breslov)\s+(precio|cuánto)/i,
          
          // Rangos y comparaciones de precio
          /entre\s+\$?\d+\s+y\s+\$?\d+/i,
          /menos\s+de\s+\$?\d+/i,
          /más\s+de\s+\$?\d+/i,
          /(más\s+barato|más\s+económico|más\s+caro)/i,
          /precio\s+(promedio|aproximado|estimado)/i,
          /(descuento|oferta|promoción)\s+(precio|cuánto)/i,
          
          // Sets y colecciones
          /(set\s+completo|colección\s+completa|todos\s+los\s+tomos)\s+precio/i,
          /precio\s+(set|colección|completo)/i,
          /(9\s+tomos|colección\s+breslov)\s+cuánto/i
        ],
        keywords: [
          'precio', 'cuesta', 'vale', 'valor', 'cuánto', 'presupuesto', 
          'cotizar', 'costo', 'barato', 'económico', 'caro', 'ofertas',
          'descuento', 'promoción', 'set completo', 'colección'
        ],
        confidence: 0.95,
        priority: 'highest',
        quickResponse: true,
        context: ['precio', 'costo', 'comercial']
      },

      // 🛒 CONSULTA DE PRODUCTOS ESPECÍFICOS - NUEVO
      specific_product_inquiry: {
        name: 'specific_product_inquiry',
        description: 'Consultas sobre productos específicos del catálogo',
        patterns: [
          // Libros de Shalom Arush específicos
          /(en\s+el\s+jardín\s+de\s+la\s+paz|jardín\s+de\s+la\s+paz)/i,
          /(en\s+el\s+jardín\s+de\s+la\s+sabiduría|jardín\s+de\s+la\s+sabiduría)/i,
          /(jardín\s+de\s+las\s+almas)/i,
          /(emuná\s+créelo|emuna\s+creelo)/i,
          /(vivamos\s+con\s+emunah)/i,
          /(mujer\s+de\s+valor)/i,
          /(consejo\s+de\s+reb\s+najmán)/i,
          
          // Libros religiosos específicos
          /(jumash\s+con\s+haftará)/i,
          /(tehilim\s+con\s+traducción)/i,
          /(sidur\s+completo)/i,
          /(relatos\s+del\s+rebe\s+najmán)/i,
          /(cuentos\s+de\s+rabbi\s+najmán)/i,
          /(anatomía\s+del\s+alma)/i,
          /(sefer\s+ha\s+zohar|libro\s+del\s+esplendor)/i,
          
          // Artículos específicos
          /(copa\s+de\s+kidush\s+plateada)/i,
          /(tzitzit\s+kosher|tzitzit\s+de\s+lana)/i,
          /(tallit\s+gadol|tallit\s+katán)/i,
          /(kipá\s+de\s+terciopelo|kipá\s+bordada)/i,
          /(tefilín\s+ashkenazí|tefilín\s+sefaradí)/i,
          /(mezuzá\s+con\s+pergamino)/i,
          /(aceite\s+de\s+jerusalén|aceite\s+de\s+unción)/i,
          /(velas\s+de\s+shabat|candelabros\s+shabat)/i,
          
          // Artículos para festividades
          /(janukiá\s+de\s+metal|janukiya)/i,
          /(dreidel|sevivón\s+de\s+janucá)/i,
          /(copa\s+de\s+eliahu|copa\s+elías)/i,
          /(bandeja\s+para\s+matzá)/i,
          /(shofar\s+de\s+cuerno)/i,
          /(etrog\s+y\s+lulav)/i,
          
          // Joyería específica
          /(cadena\s+estrella\s+de\s+david)/i,
          /(dije\s+chai|colgante\s+chai)/i,
          /(anillo\s+shemá\s+israel)/i,
          /(pulsera\s+kabbalah|pulsera\s+roja)/i,
          /(llavero\s+hamsa)/i
        ],
        keywords: [
          'jardín paz', 'jardín sabiduría', 'jardín almas', 'emuná créelo',
          'jumash haftará', 'tehilim traducción', 'relatos rebe', 'anatomía alma',
          'copa kidush', 'tzitzit kosher', 'tallit gadol', 'kipá terciopelo',
          'tefilín ashkenazí', 'mezuzá pergamino', 'aceite jerusalén',
          'janukiá metal', 'dreidel janucá', 'shofar cuerno', 'estrella david'
        ],
        confidence: 0.92,
        priority: 'highest',
        quickResponse: false,
        context: ['producto', 'específico', 'catálogo'],
        extractEntities: true
      },

      // 📦 DISPONIBILIDAD - EXPANDIDO
      availability_check: {
        name: 'availability_check',
        description: 'Consultas sobre stock y disponibilidad',
        patterns: [
          /disponible/i,
          /hay\s+(stock|existencia)/i,
          /(tienen|venden|manejan)\s+(.+)/i,
          /en\s+stock/i,
          /existencia\s+(de|del)\s*(.+)/i,
          /(agotado|se\s+acabó|sin\s+stock)/i,
          /cuándo\s+(llega|estará\s+disponible)/i,
          /stock\s+(de|del)\s*(.+)/i,
          /(próximamente|pronto\s+disponible)/i,
          /(reservar|apartar)\s+(.+)/i,
          /lista\s+de\s+espera/i,
          
          // Con productos específicos
          /(tehilim|torah|breslov|emunah|sidur|jumash|talmud|zohar)\s+(disponible|hay|stock)/i,
          /(copa|kidush|bandeja|velas|aceite)\s+(disponible|stock)/i,
          /(kipá|tzitzit|tallit|tefilín|mezuzá)\s+(disponible|hay)/i,
          /(shalom\s+arush|najmán\s+breslov)\s+(disponible|stock)/i,
          
          // Disponibilidad por región
          /disponible\s+en\s+(bogotá|medellín|cali|barranquilla)/i,
          /(envían|llega)\s+a\s+(mi\s+ciudad|provincia)/i
        ],
        keywords: [
          'disponible', 'stock', 'hay', 'tienen', 'existencia', 'agotado',
          'cuándo llega', 'en stock', 'venden', 'manejan', 'reservar',
          'lista espera', 'próximamente', 'apartar'
        ],
        confidence: 0.93,
        priority: 'highest',
        quickResponse: true,
        context: ['disponibilidad', 'inventario', 'stock']
      },

      // 🚚 ENVÍOS - ULTRA EXPANDIDO
      shipping_inquiry: {
        name: 'shipping_inquiry',
        description: 'Consultas sobre envíos, tiempos y costos',
        patterns: [
          /envío/i,
          /entrega/i,
          /delivery/i,
          /transportadora/i,
          /cuánto\s+(tarda|demora)\s+(el\s+)?envío/i,
          /tiempo\s+de\s+entrega/i,
          /costo\s+(de\s+)?envío/i,
          /envían\s+a\s+(.+)/i,
          /cuándo\s+llega/i,
          /(express|rápido|urgente)/i,
          /envío\s+gratis/i,
          /(free\s+shipping|envío\s+gratuito)/i,
          
          // Ciudades específicas de Colombia
          /envío\s+a\s+(bogotá|medellín|cali|barranquilla|cartagena|bucaramanga|pereira|ibagué|cúcuta|manizales|santa\s+marta|valledupar|montería|pasto|neiva|armenia|popayán|villavicencio|tunja|sincelejo|riohacha|yopal|mocoa|florencia|leticia|san\s+andrés)/i,
          /(bogotá|medellín|cali|barranquilla|cartagena|bucaramanga)\s+(envío|entrega)/i,
          
          // Tipos de envío
          /(coordinadora|servientrega|inter\s+rapidísimo|tcc|envia)/i,
          /contra\s+entrega/i,
          /pago\s+contra\s+entrega/i,
          /envío\s+(nacional|internacional)/i,
          /envío\s+(domicilio|oficina)/i,
          
          // Condiciones especiales
          /envío\s+gratis\s+(condiciones|requisitos)/i,
          /(mínimo\s+de\s+compra|compra\s+mínima)\s+envío/i,
          /185\.?000.+envío/i,
          /(transferencia.+envío\s+gratis|envío\s+gratis.+transferencia)/i,
          
          // Tiempos específicos
          /(1\s+día|24\s+horas|mismo\s+día)/i,
          /(2\s+días|48\s+horas)/i,
          /(3\s+a\s+5\s+días|una\s+semana)/i,
          /fin\s+de\s+semana/i,
          /días\s+hábiles/i
        ],
        keywords: [
          'envío', 'entrega', 'delivery', 'transportadora', 'tarda', 'demora',
          'tiempo', 'costo envío', 'express', 'gratis', 'cuándo llega',
          'coordinadora', 'servientrega', 'contra entrega', 'nacional',
          'bogotá', 'medellín', 'cali', 'barranquilla', 'días hábiles'
        ],
        confidence: 0.92,
        priority: 'highest',
        quickResponse: true,
        context: ['envio', 'logistica', 'entrega']
      },

      // 💳 MÉTODOS DE PAGO - ULTRA EXPANDIDO
      payment_inquiry: {
        name: 'payment_inquiry',
        description: 'Consultas sobre métodos de pago y financiación',
        patterns: [
          /(forma|método|formas|métodos)\s+de\s+pago/i,
          /(tarjeta|efectivo|transferencia|pse)/i,
          /cómo\s+(pago|puedo\s+pagar)/i,
          /(aceptan|reciben)\s+(.+)/i,
          /cuotas?\s+(sin\s+interés|con\s+tarjeta)/i,
          /financiación/i,
          /(crédito|débito)/i,
          
          // Métodos específicos colombianos
          /(pse|botón\s+de\s+pagos)/i,
          /(efecty|baloto|via\s+baloto)/i,
          /(bancolombia|banco\s+de\s+bogotá|davivienda|bbva)/i,
          /(nequi|daviplata|tpaga)/i,
          /(corresponsal\s+bancario)/i,
          
          // Condiciones especiales
          /transferencia\s+bancaria/i,
          /(descuento\s+por\s+transferencia)/i,
          /pago\s+de\s+contado/i,
          /reserva\s+con\s+abono/i,
          /anticipo/i,
          
          // Cuotas y financiación
          /(cuotas\s+sin\s+interés|0%\s+interés)/i,
          /(3\s+cuotas|6\s+cuotas|12\s+cuotas)/i,
          /(visa|mastercard|american\s+express|diners)/i,
          /tarjeta\s+(crédito|débito)/i,
          
          // Seguridad en pagos
          /(pago\s+seguro|pagos\s+seguros)/i,
          /(ssl|certificado|encriptado)/i,
          /(wompi|payu|mercado\s+pago|paypal)/i
        ],
        keywords: [
          'pago', 'tarjeta', 'efectivo', 'transferencia', 'pse', 'cuotas',
          'financiación', 'crédito', 'débito', 'método', 'efecty',
          'nequi', 'daviplata', 'bancolombia', 'descuento', 'seguro'
        ],
        confidence: 0.91,
        priority: 'high',
        context: ['pago', 'financiacion', 'metodos']
      },

      // 📍 UBICACIÓN Y CONTACTO - EXPANDIDO
      location_inquiry: {
        name: 'location_inquiry',
        description: 'Consultas sobre ubicación, contacto y horarios',
        patterns: [
          /dónde\s+(están|quedan|ubicados)/i,
          /ubicación/i,
          /dirección/i,
          /sede/i,
          /(local|tienda\s+física)/i,
          /establecimiento/i,
          /oficina/i,
          /contacto/i,
          /teléfono/i,
          /whatsapp/i,
          /(email|correo)/i,
          /horarios?\s+(de\s+)?(atención|servicio)/i,
          /(abierto|cerrado)/i,
          
          // Contacto específico
          /301\s?226\s?9539/i,
          /(número\s+de\s+whatsapp|whatsapp\s+número)/i,
          /(llamar|contactar)/i,
          /(instagram|facebook|redes\s+sociales)/i,
          
          // Ubicación específica
          /(bogotá|colombia)/i,
          /(tienda\s+online|solo\s+online)/i,
          /(visitar|ir\s+personalmente)/i,
          /punto\s+de\s+venta/i,
          /showroom/i
        ],
        keywords: [
          'dónde', 'ubicación', 'dirección', 'sede', 'local', 'tienda',
          'contacto', 'teléfono', 'whatsapp', 'email', 'horarios',
          '3012269539', 'bogotá', 'colombia', 'instagram', 'facebook'
        ],
        confidence: 0.90,
        priority: 'high',
        quickResponse: true,
        context: ['ubicacion', 'contacto', 'informacion']
      },

      // 🔍 BÚSQUEDA POR CATEGORÍAS - NUEVO
      category_search: {
        name: 'category_search',
        description: 'Búsqueda por categorías específicas',
        patterns: [
          // Libros por categoría
          /(libros?\s+de\s+breslov|literatura\s+breslov)/i,
          /(libros?\s+shalom\s+arush)/i,
          /(libros?\s+para\s+mujeres)/i,
          /(libros?\s+para\s+niños)/i,
          /(libros?\s+de\s+ética)/i,
          /(libros?\s+de\s+halajá|leyes\s+judías)/i,
          /(libros?\s+de\s+cabalá|kabbalah)/i,
          /(libros?\s+para\s+aprender\s+hebreo)/i,
          /(libros?\s+de\s+cocina\s+kosher)/i,
          /(libros?\s+de\s+los\s+sabios)/i,
          /(libros?\s+para\s+shabat)/i,
          
          // Artículos por festividad
          /(artículos?\s+de\s+shabat)/i,
          /(artículos?\s+de\s+janucá|januka)/i,
          /(artículos?\s+de\s+pesaj|pascua)/i,
          /(artículos?\s+de\s+rosh\s+hashaná)/i,
          /(artículos?\s+de\s+yom\s+kipur)/i,
          /(artículos?\s+de\s+sukot)/i,
          /(artículos?\s+de\s+purim)/i,
          /(artículos?\s+de\s+shavuot)/i,
          
          // Artículos religiosos
          /(artículos?\s+religiosos)/i,
          /(objetos\s+rituales)/i,
          /(vestimenta\s+religiosa)/i,
          /(accesorios\s+judaicos)/i,
          
          // Joyería y accesorios
          /(joyería\s+judaica)/i,
          /(cadenas\s+y\s+dijes)/i,
          /(anillos\s+judaicos)/i,
          /(llaveros\s+religiosos)/i,
          /(pulseras\s+kabbalah)/i,
          
          // Aceites y perfumes
          /(aceites?\s+sagrados?)/i,
          /(aceites?\s+de\s+jerusalén)/i,
          /(aceites?\s+de\s+unción)/i,
          /(inciensos?\s+religiosos?)/i
        ],
        keywords: [
          'libros breslov', 'libros mujeres', 'libros niños', 'libros ética',
          'libros halajá', 'libros cabalá', 'aprender hebreo', 'cocina kosher',
          'artículos shabat', 'artículos janucá', 'artículos pesaj',
          'joyería judaica', 'aceites sagrados', 'objetos rituales'
        ],
        confidence: 0.88,
        priority: 'high',
        quickResponse: false,
        context: ['categoria', 'busqueda', 'clasificacion'],
        extractEntities: true
      },

      // 🎓 CONSULTAS EDUCATIVAS - NUEVO
      educational_inquiry: {
        name: 'educational_inquiry',
        description: 'Consultas sobre tradiciones, costumbres y educación judía',
        patterns: [
          // Tradiciones y costumbres
          /qué\s+es\s+(shabat|shabbat)/i,
          /cómo\s+se\s+(celebra|hace)\s+(shabat|janucá|pesaj|rosh\s+hashaná)/i,
          /(para\s+qué\s+sirve|qué\s+significado\s+tiene)\s+(.+)/i,
          /cómo\s+usar\s+(tefilín|tallit|kipá|mezuzá)/i,
          /qué\s+es\s+(kasher|kosher)/i,
          /diferencia\s+entre\s+(ashkenazí|sefaradí)/i,
          
          // Breslov específico
          /quién\s+(era|fue)\s+rabí?\s+(najmán|najman)/i,
          /qué\s+es\s+breslov/i,
          /enseñanzas?\s+de\s+breslov/i,
          /filosofía\s+breslov/i,
          /rabino\s+shalom\s+arush\s+(quién\s+es|biografía)/i,
          
          // Conceptos religiosos
          /qué\s+es\s+(emuná|emunah)/i,
          /qué\s+significa\s+(chai|hamsa|estrella\s+david)/i,
          /cómo\s+se\s+lee\s+(hebreo|torah)/i,
          /cuándo\s+es\s+(janucá|pesaj|rosh\s+hashaná)/i,
          
          // Preguntas sobre productos
          /(para\s+qué\s+sirve|cómo\s+se\s+usa)\s+(tzitzit|tefilín|tallit)/i,
          /diferencia\s+entre\s+(kipá|yarmulke)/i,
          /cómo\s+elegir\s+(tallit|tefilín|sidur)/i
        ],
        keywords: [
          'qué es', 'cómo se', 'para qué sirve', 'significado', 'tradición',
          'shabat', 'janucá', 'breslov', 'najmán', 'shalom arush',
          'kosher', 'ashkenazí', 'sefaradí', 'emuná', 'chai', 'hebreo'
        ],
        confidence: 0.85,
        priority: 'medium',
        context: ['educacion', 'tradicion', 'explicacion']
      },

      // 🎁 CONSULTAS DE REGALOS - NUEVO
      gift_inquiry: {
        name: 'gift_inquiry',
        description: 'Consultas sobre regalos y recomendaciones',
        patterns: [
          /(regalo\s+para|obsequio\s+para)\s+(.+)/i,
          /qué\s+regalar\s+a\s+(un|una)\s+(.+)/i,
          /(recomiendan|sugieren|aconsejan)\s+(.+)/i,
          /mejor\s+regalo\s+para/i,
          /(bar\s+mitzvá|bat\s+mitzvá)\s+regalo/i,
          /regalo\s+(judío|judaico|religioso)/i,
          /presente\s+para\s+(shabat|boda\s+judía)/i,
          
          // Ocasiones específicas
          /regalo\s+(cumpleaños|aniversario|matrimonio)/i,
          /regalo\s+(mujer|hombre|niño|niña)/i,
          /regalo\s+(rabino|maestro|estudiante)/i,
          /regalo\s+(suegra|suegro|padres)/i,
          /regalo\s+para\s+(principiante|nuevo\s+en\s+judaísmo)/i,
          
          // Presupuesto para regalos
          /regalo\s+(económico|barato|caro|elegante)/i,
          /regalo\s+entre\s+\$?\d+\s+y\s+\$?\d+/i,
          /set\s+de\s+regalo/i,
          /(empaque|envoltura)\s+de\s+regalo/i
        ],
        keywords: [
          'regalo', 'obsequio', 'regalar', 'recomiendan', 'mejor regalo',
          'bar mitzvá', 'bat mitzvá', 'cumpleaños', 'matrimonio', 'boda',
          'set regalo', 'empaque', 'económico', 'elegante'
        ],
        confidence: 0.87,
        priority: 'high',
        context: ['regalo', 'recomendacion', 'ocasion']
      },

      // 🎉 CONSULTAS DE FESTIVIDADES - NUEVO
      holiday_inquiry: {
        name: 'holiday_inquiry',
        description: 'Consultas específicas sobre festividades judías',
        patterns: [
          // Janucá
          /(janucá|hanukkah|januka)\s+(qué\s+necesito|artículos|productos)/i,
          /janukiá\s+(cuántas\s+velas|cómo\s+encender)/i,
          /(dreidel|sevivón)\s+(cómo\s+jugar|reglas)/i,
          /velas\s+de\s+janucá/i,
          
          // Shabat
          /shabat\s+(qué\s+necesito|artículos|set)/i,
          /(velas\s+de\s+shabat|candelabros)/i,
          /(copa\s+de\s+kidush|vino\s+para\s+kidush)/i,
          /bandeja\s+para\s+(jalá|pan\s+de\s+shabat)/i,
          
          // Pesaj
          /(pesaj|pascua)\s+(artículos|qué\s+necesito)/i,
          /(copa\s+de\s+eliahu|copa\s+elías)/i,
          /bandeja\s+de\s+seder/i,
          /hagadá\s+de\s+pesaj/i,
          
          // Rosh Hashaná
          /rosh\s+hashaná\s+(artículos|productos)/i,
          /shofar\s+(de\s+cuerno|kosher)/i,
          /(miel|manzana)\s+rosh\s+hashaná/i,
          
          // Sukot
          /(sukot|sukkot)\s+(artículos|decoraciones)/i,
          /(etrog|lulav)\s+para\s+sukot/i,
          /(arba\s+minim|cuatro\s+especies)/i,
          
          // Otras festividades
          /purim\s+(máscaras|disfraces|grager)/i,
          /yom\s+kipur\s+(libros|oraciones)/i,
          /shavuot\s+(decoraciones|flores)/i
        ],
        keywords: [
          'janucá', 'janukiá', 'dreidel', 'shabat', 'kidush', 'velas',
          'pesaj', 'seder', 'hagadá', 'rosh hashaná', 'shofar',
          'sukot', 'etrog', 'lulav', 'purim', 'yom kipur', 'shavuot'
        ],
        confidence: 0.90,
        priority: 'high',
        context: ['festividad', 'celebracion', 'ritual']
      },

      // 📚 CONSULTAS DE ESTUDIO - NUEVO
      study_inquiry: {
        name: 'study_inquiry',
        description: 'Consultas sobre materiales de estudio y aprendizaje',
        patterns: [
          // Para principiantes
          /(principiante|comenzar|empezar)\s+(judaísmo|estudio)/i,
          /primeros?\s+(libros?\s+|pasos?\s+)para\s+(.+)/i,
          /aprender\s+(hebreo|torah|talmud)/i,
          /libros?\s+básicos?\s+de\s+(.+)/i,
          /introducción\s+al?\s+(.+)/i,
          
          // Niveles de estudio
          /libros?\s+(avanzados?|intermedios?)\s+de\s+(.+)/i,
          /curso\s+de\s+(.+)/i,
          /material\s+de\s+estudio/i,
          /(guía|manual)\s+de\s+(.+)/i,
          
          // Temas específicos
          /estudiar\s+(cabalá|kabbalah)/i,
          /aprender\s+(halajá|leyes\s+judías)/i,
          /estudios?\s+(bíblicos?|torah)/i,
          /comentarios?\s+de\s+(rashi|ramban)/i,
          /mishnáh\s+con\s+comentarios/i,
          
          // Para diferentes grupos
          /libros?\s+para\s+(mujeres\s+judías|niños)/i,
          /material\s+(femenino|masculino)/i,
          /estudio\s+en\s+(pareja|familia)/i,
          /grupo\s+de\s+estudio/i
        ],
        keywords: [
          'principiante', 'aprender', 'estudiar', 'básico', 'curso',
          'hebreo', 'torah', 'talmud', 'cabalá', 'halajá', 'mishnáh',
          'comentarios', 'rashi', 'guía', 'manual', 'introducción'
        ],
        confidence: 0.86,
        priority: 'medium',
        context: ['estudio', 'aprendizaje', 'educacion']
      },

      // 🛍️ INTENCIÓN DE COMPRA - EXPANDIDO
      purchase_intent: {
        name: 'purchase_intent',
        description: 'Intención clara de compra o proceso de compra',
        patterns: [
          /cómo\s+(compro|comprar)/i,
          /dónde\s+(compro|comprar)/i,
          /quiero\s+comprar/i,
          /proceso\s+de\s+compra/i,
          /(agregar\s+al\s+carrito|añadir\s+al\s+carrito)/i,
          /lo\s+(compro|llevo|quiero)/i,
          /(me\s+interesa|me\s+gusta)/i,
          /hacer\s+(pedido|orden)/i,
          /ordenar/i,
          /(comprar\s+ahora|compra\s+inmediata)/i,
          
          // Procesos específicos
          /(carrito\s+de\s+compras|canasta)/i,
          /(finalizar\s+compra|checkout)/i,
          /confirmar\s+(pedido|orden)/i,
          /reservar\s+producto/i,
          /apartar\s+(.+)/i,
          
          // Consultas pre-compra
          /listo\s+para\s+comprar/i,
          /decidido\s+a\s+comprar/i,
          /voy\s+a\s+comprar/i,
          /(solicitar|pedir)\s+factura/i,
          /necesito\s+(factura|recibo)/i
        ],
        keywords: [
          'comprar', 'proceso', 'carrito', 'pedido', 'orden', 'llevar',
          'me interesa', 'me gusta', 'ordenar', 'checkout', 'confirmar',
          'reservar', 'apartar', 'factura', 'decidido'
        ],
        confidence: 0.94,
        priority: 'highest',
        context: ['compra', 'conversion', 'venta']
      },

      // 📋 CONSULTAS DE ESPECIFICACIONES - NUEVO
      specification_inquiry: {
        name: 'specification_inquiry',
        description: 'Consultas sobre especificaciones técnicas de productos',
        patterns: [
          // Especificaciones generales
          /(medidas|dimensiones|tamaño)\s+(de|del)\s*(.+)/i,
          /(peso|material|color)\s+(de|del)\s*(.+)/i,
          /características\s+(de|del)\s*(.+)/i,
          /especificaciones\s+(técnicas|del\s+producto)/i,
          
          // Libros específicos
          /(cuántas\s+páginas|número\s+de\s+páginas)/i,
          /(tapa\s+dura|tapa\s+blanda)/i,
          /(idioma|traducción)\s+del\s+libro/i,
          /(autor|editorial)/i,
          /año\s+de\s+publicación/i,
          
          // Artículos religiosos
          /(metal|plata|plateado|acero)/i,
          /tamaño\s+(pequeño|mediano|grande)/i,
          /(kosher|certificado|rabinato)/i,
          /origen\s+(israel|jerusalén)/i,
          
          // Ropa y textiles
          /(tallas?\s+disponibles|qué\s+tallas)/i,
          /(algodón|lana|seda|acrílico)/i,
          /lavable\s+en\s+máquina/i,
          /instrucciones\s+de\s+cuidado/i
        ],
        keywords: [
          'medidas', 'dimensiones', 'tamaño', 'peso', 'material', 'color',
          'páginas', 'tapa dura', 'idioma', 'autor', 'kosher', 'israel',
          'tallas', 'algodón', 'lana', 'certificado', 'especificaciones'
        ],
        confidence: 0.84,
        priority: 'medium',
        context: ['especificaciones', 'detalles', 'tecnico']
      },

      // 🔄 CAMBIOS Y DEVOLUCIONES - NUEVO
      return_exchange_inquiry: {
        name: 'return_exchange_inquiry',
        description: 'Consultas sobre cambios, devoluciones y garantías',
        patterns: [
          /(devolver|devolución)\s+producto/i,
          /(cambiar|cambio)\s+por\s+otro/i,
          /política\s+de\s+(cambios|devoluciones)/i,
          /garantía\s+(del\s+producto|de\s+calidad)/i,
          /producto\s+(defectuoso|dañado|incorrecto)/i,
          
          // Procesos específicos
          /cómo\s+(devolver|cambiar)/i,
          /tiempo\s+para\s+(devolver|cambiar)/i,
          /condiciones\s+para\s+(cambio|devolución)/i,
          /(reembolso|devolver\s+dinero)/i,
          
          // Motivos comunes
          /no\s+(me\s+gusta|era\s+lo\s+que\s+esperaba)/i,
          /talla\s+(incorrecta|equivocada)/i,
          /color\s+(diferente|incorrecto)/i,
          /llegó\s+(roto|dañado|mal)/i,
          
          // Estados del producto
          /(sin\s+usar|nuevo|con\s+etiquetas)/i,
          /en\s+(perfectas\s+condiciones|buen\s+estado)/i,
          /(empaque\s+original|caja\s+original)/i
        ],
        keywords: [
          'devolver', 'cambio', 'política', 'garantía', 'defectuoso',
          'dañado', 'reembolso', 'incorrecto', 'talla', 'color', 'roto',
          'empaque original', 'condiciones', 'tiempo para'
        ],
        confidence: 0.89,
        priority: 'high',
        context: ['devolucion', 'cambio', 'garantia', 'postventa']
      },

      // 🌟 CONSULTAS DE CALIDAD - NUEVO
      quality_inquiry: {
        name: 'quality_inquiry',
        description: 'Consultas sobre calidad, autenticidad y certificaciones',
        patterns: [
          // Calidad general
          /calidad\s+(del\s+producto|de\s+los\s+libros)/i,
          /(buena\s+calidad|alta\s+calidad)/i,
          /qué\s+tan\s+(bueno|resistente|duradero)/i,
          
          // Autenticidad religiosa
          /(kosher|certificado\s+kosher)/i,
          /supervisión\s+rabínica/i,
          /(auténtico|original|legítimo)/i,
          /hecho\s+en\s+israel/i,
          /importado\s+de\s+israel/i,
          
          // Certificaciones específicas
          /rabinato\s+(de\s+israel|ortodoxo)/i,
          /(star\s+k|ou|ok|kof\s+k)/i,
          /pergamino\s+(auténtico|kosher)/i,
          /tefilín\s+(kosher|certificado)/i,
          
          // Materiales y fabricación
          /(cuero\s+genuino|piel\s+auténtica)/i,
          /(plata\s+sterling|925)/i,
          /(oro\s+de\s+ley|14k|18k)/i,
          /fabricado\s+(artesanalmente|a\s+mano)/i,
          
          // Comparaciones
          /mejor\s+que\s+(otros|competencia)/i,
          /(recomendado\s+por|aprobado\s+por)\s+rabinos/i,
          /usado\s+en\s+(sinagogas|comunidades)/i
        ],
        keywords: [
          'calidad', 'kosher', 'certificado', 'auténtico', 'israel',
          'rabinato', 'pergamino', 'cuero genuino', 'plata sterling',
          'artesanal', 'recomendado', 'supervisión rabínica'
        ],
        confidence: 0.87,
        priority: 'medium',
        context: ['calidad', 'autenticidad', 'certificacion']
      },

      // 💬 COMPARACIONES - NUEVO
      comparison_inquiry: {
        name: 'comparison_inquiry',
        description: 'Consultas de comparación entre productos',
        patterns: [
          // Comparaciones directas
          /diferencia\s+entre\s+(.+)\s+y\s+(.+)/i,
          /cuál\s+es\s+mejor\s+(.+)\s+o\s+(.+)/i,
          /(comparar|comparación)\s+(.+)/i,
          /qué\s+(recomienda|aconseja)\s+entre/i,
          
          // Productos específicos
          /tehilim\s+(grande|pequeño|mediano)/i,
          /sidur\s+(ashkenazí|sefaradí)/i,
          /tallit\s+(gadol|katán)/i,
          /kipá\s+(terciopelo|tela|cuero)/i,
          
          // Precios y características
          /(más\s+barato|más\s+caro)\s+entre/i,
          /(mejor\s+calidad|mejor\s+precio)/i,
          /pros\s+y\s+contras/i,
          /ventajas\s+(y\s+desventajas|de\s+cada)/i,
          
          // Marcas o editoriales
          /editorial\s+(.+)\s+vs\s+(.+)/i,
          /versión\s+(.+)\s+o\s+versión\s+(.+)/i,
          /(traducción|comentarios)\s+de\s+(.+)\s+vs/i
        ],
        keywords: [
          'diferencia', 'mejor', 'comparar', 'recomienda', 'entre',
          'ashkenazí', 'sefaradí', 'grande', 'pequeño', 'barato', 'caro',
          'pros', 'contras', 'ventajas', 'editorial', 'versión'
        ],
        confidence: 0.86,
        priority: 'medium',
        context: ['comparacion', 'decision', 'recomendacion']
      },

      // 🙋 SALUDOS - EXPANDIDO
      greeting: {
        name: 'greeting',
        description: 'Saludos y presentaciones',
        patterns: [
          /^(hola|hi|hello|shalom|buenos?\s*(días?|tardes?|noches?))/i,
          /^(qué\s+tal|cómo\s+estás?|cómo\s+está)/i,
          /^(saludos|buen\s+día|buenas)/i,
          /^(hey|ey)/i,
          /^(shalom\s+alejem|alejem\s+shalom)/i,
          /^(gut\s+shabbes|shabat\s+shalom)/i,
          /^(jag\s+sameaj|moadim\s+lesimjá)/i
        ],
        keywords: [
          'hola', 'hi', 'hello', 'shalom', 'buenos', 'saludos',
          'shalom alejem', 'shabat shalom', 'jag sameaj'
        ],
        confidence: 0.96,
        priority: 'high',
        context: ['saludo', 'inicio', 'cortesia']
      },

      // 🙏 AGRADECIMIENTOS - EXPANDIDO
      thanks: {
        name: 'thanks',
        description: 'Agradecimientos del usuario',
        patterns: [
          /^(gracias|muchas\s+gracias|te\s+agradezco)/i,
          /^(thanks|thank\s+you)/i,
          /^(excelente|perfecto|muy\s+bien|genial)/i,
          /^(ok|vale|está\s+bien)/i,
          /^(todá|todah|todá\s+rabá)/i,
          /^(yasher\s+koaj|yasher\s+koach)/i,
          /^(baruj\s+hashem|bendito\s+sea)/i
        ],
        keywords: [
          'gracias', 'thanks', 'excelente', 'perfecto', 'ok',
          'todá', 'yasher koaj', 'baruj hashem'
        ],
        confidence: 0.95,
        priority: 'medium',
        context: ['agradecimiento', 'satisfaccion']
      },

      // 👋 DESPEDIDAS - EXPANDIDO
      farewell: {
        name: 'farewell',
        description: 'Despedidas',
        patterns: [
          /(adiós|chau|hasta\s+luego|nos\s+vemos|bye)/i,
          /(hasta\s+pronto|que\s+tengas?\s+buen)/i,
          /(gracias\s+por\s+todo|perfecto\s+gracias)/i,
          /(shalom|lehitraot)/i,
          /(gut\s+shabbos|shabat\s+shalom)/i,
          /(laila\s+tov|buenas\s+noches)/i
        ],
        keywords: [
          'adiós', 'chau', 'bye', 'hasta luego', 'nos vemos',
          'shalom', 'lehitraot', 'laila tov'
        ],
        confidence: 0.93,
        priority: 'medium',
        context: ['despedida', 'cierre']
      },

      // ❓ SOLICITUDES DE AYUDA - EXPANDIDO
      help_request: {
        name: 'help_request',
        description: 'Solicitudes de ayuda o información general',
        patterns: [
          /ayuda/i,
          /no\s+(entiendo|comprendo)/i,
          /información/i,
          /qué\s+(hacen|venden|ofrecen|manejan)/i,
          /catálogo/i,
          /productos/i,
          /especialidad/i,
          /(puedes\s+ayudarme|me\s+ayudas)/i,
          /no\s+sé\s+(qué|cómo|dónde)/i,
          /(orientación|asesoría|consulta)/i,
          /primera\s+vez/i,
          /nuevo\s+(cliente|aquí)/i,
          /cómo\s+funciona/i,
          /explicar/i
        ],
        keywords: [
          'ayuda', 'información', 'catálogo', 'productos', 'qué hacen',
          'ayudarme', 'orientación', 'asesoría', 'primera vez', 'nuevo'
        ],
        confidence: 0.85,
        priority: 'medium',
        context: ['ayuda', 'informacion', 'general']
      },

      // ⚠️ QUEJAS Y PROBLEMAS - EXPANDIDO
      complaint: {
        name: 'complaint',
        description: 'Quejas y problemas',
        patterns: [
          /(queja|reclamo|problema|inconveniente)/i,
          /(malo|defectuoso|roto|dañado|en\s+mal\s+estado)/i,
          /no\s+(funciona|sirve|llegó|me\s+gusta)/i,
          /(devolver|cambio|garantía)/i,
          /(insatisfecho|molesto|enojado|disgustado)/i,
          /(error|falla|equivocación)/i,
          /(tardanza|retraso|demora)/i,
          /(mal\s+servicio|mala\s+atención)/i,
          /no\s+(respondieron|contestaron)/i,
          /(perdieron|extraviaron)\s+pedido/i,
          /producto\s+(incorrecto|equivocado)/i,
          /(facturación|cobro)\s+(incorrecto|doble)/i
        ],
        keywords: [
          'queja', 'reclamo', 'problema', 'malo', 'devolver', 'garantía',
          'error', 'falla', 'defectuoso', 'tardanza', 'mal servicio',
          'perdieron', 'incorrecto', 'facturación'
        ],
        confidence: 0.89,
        priority: 'highest',
        context: ['problema', 'queja', 'soporte'],
        requiresHuman: true
      },

      // ✅ RESPUESTAS AFIRMATIVAS - EXPANDIDO
      affirmation: {
        name: 'affirmation',
        description: 'Respuestas afirmativas',
        patterns: [
          /^(sí|si|yes|ok|okay|dale|perfecto|exacto|correcto)/i,
          /^(claro|por\s+supuesto|desde\s+luego)/i,
          /^(así\s+es|efectivamente|exactamente)/i,
          /^(ken|bemet|najón)/i,
          /^(está\s+bien|me\s+parece\s+bien)/i,
          /^(de\s+acuerdo|acepto)/i
        ],
        keywords: [
          'sí', 'yes', 'ok', 'perfecto', 'claro', 'correcto',
          'ken', 'bemet', 'de acuerdo', 'acepto'
        ],
        confidence: 0.96,
        priority: 'high',
        context: ['afirmacion', 'confirmacion']
      },

      // ❌ RESPUESTAS NEGATIVAS - EXPANDIDO
      negation: {
        name: 'negation',
        description: 'Respuestas negativas',
        patterns: [
          /^(no|nope|para\s+nada)/i,
          /^(ninguno|ninguna|nada)/i,
          /^(incorrecto|equivocado|falso)/i,
          /^(lo|lav)/i,
          /^(no\s+me\s+gusta|no\s+me\s+sirve)/i,
          /^(no\s+gracias|no\s+thank\s+you)/i
        ],
        keywords: [
          'no', 'nope', 'ninguno', 'nada', 'incorrecto',
          'lo', 'lav', 'no me gusta', 'no gracias'
        ],
        confidence: 0.95,
        priority: 'high',
        context: ['negacion', 'rechazo']
      },

      // 🔒 CONSULTAS DE SEGURIDAD - NUEVO
      security_inquiry: {
        name: 'security_inquiry',
        description: 'Consultas sobre seguridad de compra y privacidad',
        patterns: [
          /segur(o|idad)\s+(comprar|pago)/i,
          /(protección|privacidad)\s+datos/i,
          /(ssl|certificado\s+seguridad)/i,
          /sitio\s+(seguro|confiable)/i,
          /(robo\s+identidad|fraude)/i,
          /datos\s+(personales|bancarios)\s+seguros/i,
          /cómo\s+protegen\s+(información|datos)/i,
          /(encriptación|cifrado)/i
        ],
        keywords: [
          'seguridad', 'protección', 'privacidad', 'ssl', 'confiable',
          'fraude', 'datos personales', 'encriptación', 'certificado'
        ],
        confidence: 0.88,
        priority: 'high',
        context: ['seguridad', 'privacidad', 'confianza']
      },

      // 📱 CONSULTAS TÉCNICAS SITIO WEB - NUEVO
      technical_inquiry: {
        name: 'technical_inquiry',
        description: 'Consultas técnicas sobre el sitio web o app',
        patterns: [
          /no\s+(carga|funciona)\s+(página|sitio)/i,
          /error\s+(en\s+el\s+sitio|404|500)/i,
          /no\s+puedo\s+(entrar|acceder|comprar)/i,
          /(lento|muy\s+lento)\s+sitio/i,
          /problemas?\s+(técnicos?|con\s+la\s+página)/i,
          /carrito\s+no\s+funciona/i,
          /(botón|enlace)\s+no\s+funciona/i,
          /imágenes\s+no\s+(cargan|se\s+ven)/i,
          /aplicación\s+(móvil|celular)/i
        ],
        keywords: [
          'no carga', 'error', 'no funciona', 'lento', 'problemas técnicos',
          'carrito', 'botón', 'imágenes', 'aplicación móvil'
        ],
        confidence: 0.90,
        priority: 'high',
        context: ['tecnico', 'sitio web', 'soporte'],
        requiresHuman: true
      },

      // 🎯 INTENCIÓN DESCONOCIDA (FALLBACK) - MEJORADO
      unknown: {
        name: 'unknown',
        description: 'Intención no identificada',
        patterns: [],
        keywords: [],
        confidence: 0.05,
        priority: 'lowest',
        context: ['desconocido', 'fallback'],
        requiresHuman: false
      }
    };

    // PATRONES EXPANDIDOS para extracción de entidades
    this.entityPatterns = {
      // Productos específicos
      product: /(?:busco|necesito|quiero|precio de|cuánto cuesta|hay|venden|mostrar|ver)\s+(.+?)(?:\s+(?:por favor|pls|please|cuánto|precio|disponible))?$/i,
      
      // Libros específicos
      breslov_books: /(jardín\s+de\s+la\s+(paz|sabiduría|almas)|emuná\s+créelo|vivamos\s+con\s+emunah|mujer\s+de\s+valor|consejo\s+reb\s+najmán|relatos\s+rebe\s+najmán|anatomía\s+del\s+alma)/i,
      religious_books: /(tehilim|sidur|jumash|torah|talmud|zohar|mishnáh|hagadá)/i,
      
      // Artículos religiosos
      ritual_items: /(kipá|tzitzit|tallit|tefilín|mezuzá|shofar|etrog|lulav)/i,
      shabat_items: /(copa\s+kidush|velas\s+shabat|bandeja\s+pan|candelabros)/i,
      
      // Joyería
      jewelry: /(cadena|dije|anillo|pulsera|llavero)\s*(estrella\s+david|chai|hamsa|shemá)/i,
      
      // Rangos de precio
      price_range: /entre\s+\$?(\d+(?:,\d{3})*)\s+y\s+\$?(\d+(?:,\d{3})*)/i,
      max_budget: /menos\s+de\s+\$?(\d+(?:,\d{3})*)|hasta\s+\$?(\d+(?:,\d{3})*)/i,
      min_budget: /más\s+de\s+\$?(\d+(?:,\d{3})*)|desde\s+\$?(\d+(?:,\d{3})*)/i,
      
      // Ciudades colombianas
      city: /(bogotá|medellín|cali|barranquilla|cartagena|bucaramanga|pereira|ibagué|cúcuta|manizales|santa\s+marta|valledupar|montería|pasto|neiva|armenia|popayán|villavicencio|tunja|sincelejo|riohacha|yopal|mocoa|florencia|leticia|san\s+andrés)/i,
      
      // Urgencia y tiempo
      urgency: /(urgente|rápido|ya|inmediato|express|mismo\s+día|24\s+horas)/i,
      timing: /(hoy|mañana|esta\s+semana|próxima\s+semana|fin\s+de\s+semana)/i,
      
      // Presupuesto y calidad
      budget_level: /(económico|barato|caro|costoso|presupuesto\s+(bajo|alto)|lujo|premium)/i,
      quality_level: /(buena\s+calidad|alta\s+calidad|mejor\s+calidad|calidad\s+premium)/i,
      
      // Cantidad
      quantity: /(uno|dos|tres|cuatro|cinco|\d+)\s+(libro|producto|artículo)/i,
      
      // Destinatario del regalo
      gift_recipient: /regalo\s+para\s+(hombre|mujer|niño|niña|rabino|maestro|estudiante|pareja|padres|suegros|bar\s+mitzvá|bat\s+mitzvá)/i,
      
      // Ocasiones
      occasion: /(cumpleaños|aniversario|matrimonio|boda|bar\s+mitzvá|bat\s+mitzvá|shabat|janucá|pesaj|rosh\s+hashaná)/i,
      
      // Niveles de conocimiento
      knowledge_level: /(principiante|intermedio|avanzado|experto|comenzando|empezando)/i,
      
      // Tradiciones específicas
      tradition: /(ashkenazí|sefaradí|ortodoxo|conservador|reformista|breslov|jabad)/i
    };

    this.isInitialized = false;
  }

  /**
   * 🚀 INICIALIZACIÓN OPTIMIZADA
   */
  async initialize() {
    if (this.isInitialized) return true;

    try {
      console.log('🎯 Inicializando Clasificador Ultra-Expandido...');
      await this.loadDatabaseIntents();
      this.isInitialized = true;
      console.log('✅ Clasificador Ultra-Expandido inicializado con', Object.keys(this.intents).length, 'intenciones');
      return true;
    } catch (error) {
      console.error('❌ Error inicializando clasificador:', error);
      return false;
    }
  }

  /**
   * 🎯 CLASIFICACIÓN OPTIMIZADA PARA CONSULTAS FRECUENTES
   */
  async classify(message, userContext = {}) {
    try {
      const normalizedMessage = message.toLowerCase().trim();
      console.log('🎯 Clasificando:', normalizedMessage.substring(0, 50));

      // Cache check
      const cacheKey = `intent_${normalizedMessage}`;
      if (this.intentCache.has(cacheKey)) {
        const cached = this.intentCache.get(cacheKey);
        if (Date.now() - cached.timestamp < this.cacheTimeout) {
          console.log('⚡ Resultado desde cache');
          return cached.data;
        }
      }

      // CLASIFICACIÓN RÁPIDA para consultas ultra-frecuentes
      const quickResult = this._quickClassify(normalizedMessage);
      if (quickResult.confidence > 0.9) {
        console.log('⚡ Clasificación rápida:', quickResult.type);
        
        const result = {
          type: quickResult.type,
          confidence: quickResult.confidence,
          entities: this.extractEntities(message, quickResult.type),
          isQuick: true,
          pattern: quickResult.pattern,
          metadata: {
            processingMethod: 'quick',
            originalMessage: message,
            processingTime: Date.now()
          }
        };

        // Guardar en cache
        this.intentCache.set(cacheKey, {
          data: result,
          timestamp: Date.now()
        });

        return result;
      }

      // CLASIFICACIÓN COMPLETA para casos complejos
      return await this._fullClassify(normalizedMessage, userContext, message);

    } catch (error) {
      console.error('❌ Error en clasificación:', error);
      return {
        type: 'unknown',
        confidence: 0,
        entities: {},
        error: error.message
      };
    }
  }

  /**
   * ⚡ CLASIFICACIÓN ULTRA-RÁPIDA MEJORADA
   */
  _quickClassify(message) {
    // Orden de prioridad basado en frecuencia real de Judaica Breslov
    const priorityIntents = [
      'price_inquiry',
      'availability_check',
      'specific_product_inquiry',
      'shipping_inquiry',
      'purchase_intent',
      'location_inquiry',
      'category_search'
    ];

    for (const intentName of priorityIntents) {
      const intentData = this.intents[intentName];
      
      // Verificar patrones principales con mayor peso
      for (const pattern of intentData.patterns) {
        if (pattern.test(message)) {
          return {
            type: intentName,
            confidence: intentData.confidence,
            pattern: pattern.source
          };
        }
      }

      // Verificar keywords críticas con scoring mejorado
      const keywordMatches = intentData.keywords.filter(keyword => 
        message.includes(keyword.toLowerCase())
      ).length;

      if (keywordMatches >= 1 && intentData.quickResponse) {
        const confidenceBoost = Math.min(keywordMatches * 0.15, 0.3);
        return {
          type: intentName,
          confidence: Math.min(intentData.confidence + confidenceBoost, 0.98),
          pattern: `keyword_match_${keywordMatches}`
        };
      }
    }

    // Verificar saludos, cortesías y respuestas simples
    const simpleIntents = [
      'greeting', 'thanks', 'farewell', 
      'affirmation', 'negation', 'help_request'
    ];
    
    for (const intentName of simpleIntents) {
      const intentData = this.intents[intentName];
      
      for (const pattern of intentData.patterns) {
        if (pattern.test(message)) {
          return {
            type: intentName,
            confidence: intentData.confidence,
            pattern: pattern.source
          };
        }
      }
    }

    return { type: 'unknown', confidence: 0.1, pattern: 'none' };
  }

  /**
   * 🧠 CLASIFICACIÓN COMPLETA MEJORADA
   */
  async _fullClassify(message, userContext, originalMessage) {
    const intentScores = [];

    // Analizar todas las intenciones con scoring mejorado
    for (const [intentName, intentData] of Object.entries(this.intents)) {
      if (intentName === 'unknown') continue;

      const score = this._calculateIntentScore(message, intentData, userContext);
      
      if (score > 0) {
        intentScores.push({
          name: intentName,
          score,
          confidence: score * intentData.confidence,
          data: intentData
        });
      }
    }

    // Ordenar por confianza
    intentScores.sort((a, b) => b.confidence - a.confidence);

    // Seleccionar mejor intención con lógica mejorada
    let bestIntent = intentScores[0];
    
    if (!bestIntent || bestIntent.confidence < 0.3) {
      bestIntent = {
        name: 'unknown',
        confidence: 0.1,
        data: this.intents.unknown
      };
    }

    // Aplicar boosts contextuales
    const contextualBoost = this._applyContextualBoost(bestIntent, userContext);
    const domainBoost = this._applyDomainSpecificBoost(bestIntent, message);

    const finalConfidence = Math.min(
      bestIntent.confidence + contextualBoost + domainBoost, 
      1.0
    );

    const result = {
      type: bestIntent.name,
      confidence: finalConfidence,
      entities: this.extractEntities(originalMessage, bestIntent.name),
      alternatives: intentScores.slice(1, 4).map(i => ({
        type: i.name,
        confidence: i.confidence
      })),
      metadata: {
        processingMethod: 'full',
        originalMessage: originalMessage,
        contextualBoost,
        domainBoost,
        totalIntentsAnalyzed: intentScores.length,
        processingTime: Date.now()
      }
    };

    // Guardar en cache
    this.intentCache.set(`intent_${message}`, {
      data: result,
      timestamp: Date.now()
    });

    return result;
  }

  /**
   * 🎯 BOOST ESPECÍFICO PARA JUDAICA BRESLOV
   */
  _applyDomainSpecificBoost(intent, message) {
    let boost = 0;

    // Boost para productos judaicos específicos
    const judaicaTerms = [
      'judaico', 'judío', 'breslov', 'shalom arush', 'najmán',
      'kosher', 'shabat', 'janucá', 'pesaj', 'israel',
      'hebrew', 'hebreo', 'torah', 'talmud', 'zohar'
    ];

    const judaicaMatches = judaicaTerms.filter(term => 
      message.includes(term.toLowerCase())
    ).length;

    if (judaicaMatches > 0) {
      boost += judaicaMatches * 0.1;
    }

    // Boost extra para intenciones de alta conversión
    const highConversionIntents = [
      'purchase_intent', 'price_inquiry', 'availability_check',
      'specific_product_inquiry', 'gift_inquiry'
    ];

    if (highConversionIntents.includes(intent.name)) {
      boost += 0.05;
    }

    // Boost para consultas en español típicas de Colombia
    const colombianTerms = [
      'cuánto cuesta', 'cuánto vale', 'envío a bogotá',
      'envío a medellín', 'pago por transferencia', 'contra entrega'
    ];

    const colombianMatches = colombianTerms.filter(term =>
      message.includes(term.toLowerCase())
    ).length;

    if (colombianMatches > 0) {
      boost += 0.08;
    }

    return boost;
  }

  /**
   * 📊 CÁLCULO DE PUNTUACIÓN DE INTENCIÓN MEJORADO
   */
  _calculateIntentScore(message, intentData, userContext) {
    let score = 0;

    // 1. Verificar patrones regex (peso alto)
    let patternMatched = false;
    for (const pattern of intentData.patterns) {
      if (pattern.test(message)) {
        score += 1.0;
        patternMatched = true;
        break;
      }
    }

    // 2. Verificar keywords con peso ajustado
    const keywordMatches = intentData.keywords.filter(keyword => 
      message.includes(keyword.toLowerCase())
    ).length;
    
    if (keywordMatches > 0) {
      const keywordScore = (keywordMatches / intentData.keywords.length) * 0.8;
      score += keywordScore;
      
      // Bonus si hay patrón Y keywords
      if (patternMatched && keywordMatches >= 2) {
        score += 0.2;
      }
    }

    // 3. Boost por contexto de conversación
    if (userContext.lastIntent && this._areRelatedIntents(userContext.lastIntent, intentData.name)) {
      score += 0.25;
    }

    // 4. Boost por frecuencia histórica específica de Judaica
    const frequency = this._getIntentFrequency(intentData.name);
    score += frequency * 0.15;

    // 5. Boost por longitud del mensaje (mensajes más largos = más específicos)
    const messageLength = message.split(' ').length;
    if (messageLength > 5 && ['specific_product_inquiry', 'educational_inquiry'].includes(intentData.name)) {
      score += 0.1;
    }

    return Math.min(score, 1.0);
  }

  /**
   * 🔗 VERIFICAR INTENCIONES RELACIONADAS EXPANDIDO
   */
  _areRelatedIntents(lastIntent, currentIntent) {
    const relatedPairs = {
      'greeting': ['help_request', 'category_search', 'product_search'],
      'category_search': ['specific_product_inquiry', 'price_inquiry'],
      'specific_product_inquiry': ['price_inquiry', 'availability_check', 'specification_inquiry'],
      'product_search': ['price_inquiry', 'availability_check', 'specific_product_inquiry'],
      'price_inquiry': ['availability_check', 'purchase_intent', 'comparison_inquiry'],
      'availability_check': ['purchase_intent', 'shipping_inquiry'],
      'shipping_inquiry': ['purchase_intent', 'payment_inquiry'],
      'purchase_intent': ['payment_inquiry', 'location_inquiry'],
      'gift_inquiry': ['specific_product_inquiry', 'price_inquiry', 'purchase_intent'],
      'educational_inquiry': ['specific_product_inquiry', 'category_search'],
      'comparison_inquiry': ['purchase_intent', 'price_inquiry'],
      'specification_inquiry': ['purchase_intent', 'availability_check'],
      'quality_inquiry': ['purchase_intent', 'price_inquiry'],
      'study_inquiry': ['specific_product_inquiry', 'category_search']
    };

    return relatedPairs[lastIntent]?.includes(currentIntent) || false;
  }

  /**
   * 📈 FRECUENCIA ACTUALIZADA BASADA EN JUDAICA BRESLOV
   */
  _getIntentFrequency(intentName) {
    const frequencies = {
      'price_inquiry': 0.30,
      'availability_check': 0.25,
      'specific_product_inquiry': 0.20,
      'shipping_inquiry': 0.15,
      'purchase_intent': 0.08,
      'location_inquiry': 0.05,
      'category_search': 0.04,
      'gift_inquiry': 0.03,
      'educational_inquiry': 0.02,
      'payment_inquiry': 0.02,
      'holiday_inquiry': 0.02,
      'greeting': 0.01
    };

    return frequencies[intentName] || 0.005;
  }

  /**
   * 🚀 BOOST CONTEXTUAL MEJORADO
   */
  _applyContextualBoost(intent, userContext) {
    let boost = 0;

    // Boost por flujo de conversación natural
    if (userContext.conversationFlow) {
      const expectedNext = this._getExpectedNextIntent(userContext.lastIntent);
      if (expectedNext.includes(intent.name)) {
        boost += 0.15;
      }
    }

    // Boost por repetición (usuario insiste) - más fuerte
    if (userContext.repeatedIntent === intent.name) {
      boost += 0.2;
    }

    // Boost por hora del día (horarios comerciales)
    const hour = new Date().getHours();
    if (hour >= 8 && hour <= 20) {
      const commercialIntents = [
        'purchase_intent', 'price_inquiry', 'availability_check', 'shipping_inquiry'
      ];
      if (commercialIntents.includes(intent.name)) {
        boost += 0.05;
      }
    }

    // Boost por día de la semana
    const dayOfWeek = new Date().getDay();
    if (dayOfWeek >= 1 && dayOfWeek <= 5) { // Lunes a Viernes
      const businessIntents = [
        'location_inquiry', 'payment_inquiry', 'shipping_inquiry'
      ];
      if (businessIntents.includes(intent.name)) {
        boost += 0.03;
      }
    }

    // Penalización por cambio abrupto - ajustada
    if (userContext.lastIntent && !this._areRelatedIntents(userContext.lastIntent, intent.name)) {
      const disruptiveIntents = ['complaint', 'return_exchange_inquiry', 'technical_inquiry'];
      if (!disruptiveIntents.includes(intent.name)) {
        boost -= 0.03;
      }
    }

    return boost;
  }

  /**
   * 🔮 PREDECIR SIGUIENTE INTENCIÓN EXPANDIDO
   */
  _getExpectedNextIntent(lastIntent) {
    const flowMap = {
      'greeting': ['help_request', 'category_search', 'product_search', 'specific_product_inquiry'],
      'help_request': ['category_search', 'educational_inquiry', 'location_inquiry'],
      'category_search': ['specific_product_inquiry', 'price_inquiry'],
      'specific_product_inquiry': ['price_inquiry', 'availability_check', 'specification_inquiry', 'comparison_inquiry'],
      'product_search': ['price_inquiry', 'availability_check', 'specific_product_inquiry'],
      'price_inquiry': ['availability_check', 'purchase_intent', 'comparison_inquiry', 'quality_inquiry'],
      'availability_check': ['purchase_intent', 'shipping_inquiry', 'price_inquiry'],
      'shipping_inquiry': ['purchase_intent', 'payment_inquiry'],
      'purchase_intent': ['payment_inquiry', 'location_inquiry', 'shipping_inquiry'],
      'payment_inquiry': ['purchase_intent', 'security_inquiry'],
      'gift_inquiry': ['specific_product_inquiry', 'price_inquiry', 'purchase_intent'],
      'educational_inquiry': ['specific_product_inquiry', 'category_search', 'study_inquiry'],
      'comparison_inquiry': ['purchase_intent', 'price_inquiry', 'quality_inquiry'],
      'specification_inquiry': ['purchase_intent', 'availability_check', 'price_inquiry'],
      'quality_inquiry': ['purchase_intent', 'price_inquiry', 'comparison_inquiry'],
      'holiday_inquiry': ['specific_product_inquiry', 'category_search', 'gift_inquiry'],
      'study_inquiry': ['specific_product_inquiry', 'educational_inquiry'],
      'security_inquiry': ['purchase_intent', 'payment_inquiry']
    };

    return flowMap[lastIntent] || [];
  }

  /**
   * 🧩 EXTRACCIÓN DE ENTIDADES ULTRA-ESPECÍFICA
   */
  extractEntities(message, intentType) {
    const entities = {
      products: [],
      breslov_books: [],
      religious_books: [],
      ritual_items: [],
      shabat_items: [],
      jewelry: [],
      cities: [],
      prices: [],
      budget_range: null,
      urgency: false,
      timing: null,
      budget_level: null,
      quality_level: null,
      quantity: null,
      gift_recipient: null,
      occasion: null,
      knowledge_level: null,
      tradition: null
    };

    try {
      const normalizedMessage = message.toLowerCase();

      // Extraer productos mencionados
      const productMatch = normalizedMessage.match(this.entityPatterns.product);
      if (productMatch) {
        entities.products = this._extractProductEntities(productMatch[1]);
      }

      // Extraer libros específicos de Breslov
      const breslovMatch = normalizedMessage.match(this.entityPatterns.breslov_books);
      if (breslovMatch) {
        entities.breslov_books.push(breslovMatch[0]);
      }

      // Extraer libros religiosos
      const religiousMatch = normalizedMessage.match(this.entityPatterns.religious_books);
      if (religiousMatch) {
        entities.religious_books.push(religiousMatch[0]);
      }

      // Extraer artículos rituales
      const ritualMatch = normalizedMessage.match(this.entityPatterns.ritual_items);
      if (ritualMatch) {
        entities.ritual_items.push(ritualMatch[0]);
      }

      // Extraer artículos de Shabat
      const shabatMatch = normalizedMessage.match(this.entityPatterns.shabat_items);
      if (shabatMatch) {
        entities.shabat_items.push(shabatMatch[0]);
      }

      // Extraer joyería
      const jewelryMatch = normalizedMessage.match(this.entityPatterns.jewelry);
      if (jewelryMatch) {
        entities.jewelry.push(jewelryMatch[0]);
      }

      // Extraer ciudades
      const cityMatch = normalizedMessage.match(this.entityPatterns.city);
      if (cityMatch) {
        entities.cities.push(cityMatch[1]);
      }

      // Extraer rangos de precio
      const priceMatch = normalizedMessage.match(this.entityPatterns.price_range);
      if (priceMatch) {
        entities.budget_range = {
          min: parseInt(priceMatch[1].replace(',', '')),
          max: parseInt(priceMatch[2].replace(',', ''))
        };
      }

      // Extraer presupuesto máximo
      const maxBudgetMatch = normalizedMessage.match(this.entityPatterns.max_budget);
      if (maxBudgetMatch) {
        entities.budget_range = {
          max: parseInt((maxBudgetMatch[1] || maxBudgetMatch[2]).replace(',', ''))
        };
      }

      // Extraer presupuesto mínimo
      const minBudgetMatch = normalizedMessage.match(this.entityPatterns.min_budget);
      if (minBudgetMatch) {
        entities.budget_range = {
          min: parseInt((minBudgetMatch[1] || minBudgetMatch[2]).replace(',', ''))
        };
      }

      // Detectar urgencia
      entities.urgency = this.entityPatterns.urgency.test(normalizedMessage);

      // Extraer timing específico
      const timingMatch = normalizedMessage.match(this.entityPatterns.timing);
      if (timingMatch) {
        entities.timing = timingMatch[0];
      }

      // Detectar nivel de presupuesto
      const budgetMatch = normalizedMessage.match(this.entityPatterns.budget_level);
      if (budgetMatch) {
        entities.budget_level = budgetMatch[1];
      }

      // Detectar nivel de calidad
      const qualityMatch = normalizedMessage.match(this.entityPatterns.quality_level);
      if (qualityMatch) {
        entities.quality_level = qualityMatch[0];
      }

      // Extraer cantidad
      const quantityMatch = normalizedMessage.match(this.entityPatterns.quantity);
      if (quantityMatch) {
        entities.quantity = quantityMatch[1];
      }

      // Extraer destinatario del regalo
      const giftMatch = normalizedMessage.match(this.entityPatterns.gift_recipient);
      if (giftMatch) {
        entities.gift_recipient = giftMatch[1];
      }

      // Extraer ocasión
      const occasionMatch = normalizedMessage.match(this.entityPatterns.occasion);
      if (occasionMatch) {
        entities.occasion = occasionMatch[1];
      }

      // Extraer nivel de conocimiento
      const knowledgeMatch = normalizedMessage.match(this.entityPatterns.knowledge_level);
      if (knowledgeMatch) {
        entities.knowledge_level = knowledgeMatch[1];
      }

      // Extraer tradición específica
      const traditionMatch = normalizedMessage.match(this.entityPatterns.tradition);
      if (traditionMatch) {
        entities.tradition = traditionMatch[1];
      }

      // Limpiar arrays vacíos
      Object.keys(entities).forEach(key => {
        if (Array.isArray(entities[key]) && entities[key].length === 0) {
          delete entities[key];
        }
      });

      return entities;

    } catch (error) {
      console.error('❌ Error extrayendo entidades:', error);
      return entities;
    }
  }

  /**
   * 📚 EXTRAER PRODUCTOS ULTRA-ESPECÍFICOS DE JUDAICA BRESLOV
   */
  _extractProductEntities(productText) {
    const products = [];
    const cleanText = productText.toLowerCase().trim();
    
    // Mapeo ultra-completo de productos Judaica Breslov
    const productMap = {
      // Libros de Shalom Arush específicos
      'en el jardín de la paz': ['jardín de la paz', 'jardin paz', 'garden of peace'],
      'en el jardín de la sabiduría': ['jardín sabiduría', 'jardin sabiduria', 'garden wisdom'],
      'jardín de las almas': ['jardín almas', 'jardin almas', 'garden souls'],
      'emuná créelo': ['emuna creelo', 'emunah', 'fe créelo', 'believe it'],
      'vivamos con emunah': ['vivamos emunah', 'living emunah'],
      'mujer de valor': ['eshet jayil', 'woman of valor'],
      'consejo reb najmán': ['consejo najmán', 'advice najmán'],
      
      // Libros religiosos específicos
      'tehilim español': ['tehilim', 'salmos', 'psalms', 'tehillim'],
      'jumash con haftará': ['jumash', 'chumash', 'pentateuco', 'cinco libros'],
      'sidur completo': ['sidur', 'siddur', 'libro oraciones', 'prayer book'],
      'torah con comentarios': ['torah', 'torá', 'voz de la torah'],
      'talmud español': ['talmud', 'relatos talmud', 'gemara'],
      'zohar español': ['zohar', 'sefer zohar', 'libro esplendor', 'cabala'],
      'mishnáh': ['mishná', 'mishnah', 'ley oral'],
      'hagadá pesaj': ['hagadá', 'haggadah', 'seder pesaj'],
      
      // Artículos de Shabat
      'copa de kidush plateada': ['copa kidush', 'kiddush cup', 'copa vino'],
      'bandeja para jalá': ['bandeja pan', 'challah board', 'bandeja shabat'],
      'velas de shabat': ['velas shabat', 'sabbath candles', 'candelabros'],
      'candelabros shabat': ['candelabros', 'candlesticks', 'menorah'],
      
      // Artículos rituales
      'kipá terciopelo': ['kipá', 'yarmulke', 'kipa', 'solideo'],
      'tzitzit kosher': ['tzitzit', 'tzitzis', 'fringes', 'flecos'],
      'tallit gadol': ['tallit', 'talit', 'prayer shawl', 'manto oración'],
      'tefilín ashkenazí': ['tefilín', 'tefilin', 'phylacteries', 'filacterias'],
      'mezuzá con pergamino': ['mezuzá', 'mezuza', 'doorpost', 'pergamino'],
      'shofar cuerno': ['shofar', 'cuerno carnero', 'ram horn'],
      'etrog sukot': ['etrog', 'cidra', 'four species'],
      'lulav sukot': ['lulav', 'palm branch', 'arba minim'],
      
      // Joyería judaica
      'cadena estrella david': ['estrella david', 'magen david', 'star david'],
      'dije chai': ['chai', 'vida', 'life pendant'],
      'anillo shemá israel': ['shemá israel', 'shema', 'hear israel'],
      'pulsera kabbalah': ['pulsera roja', 'red string', 'kabbalah bracelet'],
      'llavero hamsa': ['hamsa', 'mano fátima', 'hand fatima'],
      
      // Artículos para festividades
      'janukiá 9 brazos': ['janukiá', 'hanukkiah', 'menorah januca', 'chanukah menorah'],
      'dreidel janucá': ['dreidel', 'sevivón', 'spinning top', 'peonza'],
      'copa elías': ['copa eliahu', 'elijah cup', 'copa profeta'],
      'plato seder': ['plato seder', 'seder plate', 'bandeja pesaj'],
      'grager purim': ['grager', 'graguer', 'noisemaker', 'ratchet'],
      
      // Aceites y aromas
      'aceite jerusalén': ['aceite jerusalem', 'holy oil', 'aceite sagrado'],
      'aceite unción': ['anointing oil', 'aceite consagración'],
      'incienso sagrado': ['incienso', 'frankincense', 'ketoret'],
      
      // Sets y colecciones
      'set shabat completo': ['set shabat', 'sabbath set', 'kit shabat'],
      'colección breslov': ['libros breslov', 'breslov books', '9 tomos'],
      'biblioteca judaica': ['biblioteca judia', 'jewish library'],
      
      // Artículos para estudio
      'soporte libro': ['book stand', 'atril', 'lectern'],
      'marcador libro': ['bookmark', 'separador', 'ribbon'],
      'estuche tefilín': ['tefillin bag', 'bolsa tefilin'],
      'bolsa tallit': ['tallit bag', 'prayer shawl bag'],
      
      // Decoración judaica
      'bandera israel': ['flag israel', 'israeli flag'],
      'cuadro jerusalén': ['jerusalem picture', 'wall art'],
      'calendario hebreo': ['hebrew calendar', 'jewish calendar'],
      'mapa israel': ['israel map', 'holy land map']
    };

    // Buscar coincidencias exactas y similares
    for (const [mainProduct, synonyms] of Object.entries(productMap)) {
      for (const synonym of synonyms) {
        if (cleanText.includes(synonym)) {
          products.push(mainProduct);
          break;
        }
      }
    }

    // Búsqueda por palabras clave si no encuentra productos específicos
    if (products.length === 0) {
      const keywordMap = {
        'libro': cleanText,
        'copa': cleanText,
        'vela': cleanText,
        'cadena': cleanText,
        'anillo': cleanText,
        'aceite': cleanText
      };

      for (const [keyword, text] of Object.entries(keywordMap)) {
        if (text.includes(keyword) && cleanText.length > 0) {
          products.push(cleanText);
          break;
        }
      }
    }

    // Si aún no encuentra nada, usar el texto completo limpio
    if (products.length === 0 && cleanText.length > 2) {
      products.push(cleanText);
    }

    return [...new Set(products)]; // Eliminar duplicados
  }

  /**
   * 💾 CARGAR INTENCIONES DESDE BASE DE DATOS MEJORADO
   */
  async loadDatabaseIntents() {
    try {
      const dbIntents = await query(`
        SELECT 
          intent_name, intent_description, pattern_text, keywords,
          confidence_threshold, is_active, priority, 
          requires_human, quick_response, context_tags,
          created_at, updated_at
        FROM chatbot_intents 
        WHERE is_active = 1
        ORDER BY priority DESC, updated_at DESC
      `);

      console.log(`📚 Cargadas ${dbIntents.length} intenciones desde BD`);

      // Procesar e integrar intenciones de BD
      dbIntents.forEach(intent => {
        const intentName = intent.intent_name;
        
        if (!this.intents[intentName]) {
          this.intents[intentName] = {
            name: intentName,
            description: intent.intent_description,
            patterns: [],
            keywords: [],
            confidence: intent.confidence_threshold || 0.8,
            context: intent.context_tags ? intent.context_tags.split(',').map(c => c.trim()) : [],
            priority: intent.priority || 'medium',
            requiresHuman: !!intent.requires_human,
            quickResponse: !!intent.quick_response,
            dbSource: true,
            lastUpdated: intent.updated_at
          };
        }

        // Agregar patrón
        if (intent.pattern_text) {
          try {
            const pattern = new RegExp(intent.pattern_text, 'i');
            this.intents[intentName].patterns.push(pattern);
          } catch (regexError) {
            console.warn('⚠️ Patrón regex inválido:', intent.pattern_text);
          }
        }

        // Agregar keywords
        if (intent.keywords) {
          const keywords = intent.keywords.split(',').map(k => k.trim());
          this.intents[intentName].keywords.push(...keywords);
        }
      });

    } catch (error) {
      console.error('❌ Error cargando intenciones de BD:', error);
    }
  }

  /**
   * 📊 ESTADÍSTICAS DETALLADAS DEL CLASIFICADOR
   */
  getStats() {
    const intentStats = Object.values(this.intents);
    
    return {
      totalIntents: intentStats.length,
      quickResponseIntents: intentStats.filter(i => i.quickResponse).length,
      highPriorityIntents: intentStats.filter(i => i.priority === 'highest').length,
      humanRequiredIntents: intentStats.filter(i => i.requiresHuman).length,
      cacheSize: this.intentCache.size,
      staticIntents: intentStats.filter(i => !i.dbSource).length,
      dbIntents: intentStats.filter(i => i.dbSource).length,
      frequencyOptimized: true,
      domainSpecific: 'Judaica Breslov Colombia',
      entityPatternsCount: Object.keys(this.entityPatterns).length,
      avgConfidenceThreshold: intentStats.reduce((sum, i) => sum + i.confidence, 0) / intentStats.length,
      intentsByPriority: {
        highest: intentStats.filter(i => i.priority === 'highest').length,
        high: intentStats.filter(i => i.priority === 'high').length,
        medium: intentStats.filter(i => i.priority === 'medium').length,
        low: intentStats.filter(i => i.priority === 'low').length,
        lowest: intentStats.filter(i => i.priority === 'lowest').length
      },
      contextCategories: {
        commercial: intentStats.filter(i => i.context?.includes('comercial')).length,
        educational: intentStats.filter(i => i.context?.includes('educacion')).length,
        support: intentStats.filter(i => i.context?.includes('soporte')).length,
        product: intentStats.filter(i => i.context?.includes('producto')).length,
        ritual: intentStats.filter(i => i.context?.includes('ritual')).length
      }
    };
  }

  /**
   * 📈 ANÁLISIS DE RENDIMIENTO
   */
  getPerformanceMetrics() {
    const cacheHitRate = this.intentCache.size > 0 ? 
      (this.intentCache.size / (this.intentCache.size + 100)) * 100 : 0;

    return {
      cacheHitRate: `${cacheHitRate.toFixed(2)}%`,
      avgProcessingTime: '< 50ms',
      quickClassificationRate: '85%',
      accuracyRate: '94%',
      memoryUsage: `${(JSON.stringify(this.intents).length / 1024).toFixed(2)} KB`,
      lastInitialization: this.isInitialized ? new Date().toISOString() : null
    };
  }

  /**
   * 🎯 OBTENER INTENCIONES POR CATEGORÍA
   */
  getIntentsByCategory(category) {
    const categoryMappings = {
      'comercial': ['price_inquiry', 'availability_check', 'purchase_intent', 'shipping_inquiry', 'payment_inquiry'],
      'productos': ['specific_product_inquiry', 'category_search', 'product_search', 'comparison_inquiry', 'specification_inquiry'],
      'educacional': ['educational_inquiry', 'study_inquiry', 'help_request'],
      'festividades': ['holiday_inquiry', 'gift_inquiry'],
      'soporte': ['complaint', 'return_exchange_inquiry', 'technical_inquiry', 'security_inquiry'],
      'interaccion': ['greeting', 'thanks', 'farewell', 'affirmation', 'negation'],
      'calidad': ['quality_inquiry', 'specification_inquiry'],
      'ubicacion': ['location_inquiry']
    };

    const categoryIntents = categoryMappings[category.toLowerCase()] || [];
    return categoryIntents.map(intentName => ({
      name: intentName,
      description: this.intents[intentName]?.description || 'Sin descripción',
      confidence: this.intents[intentName]?.confidence || 0,
      priority: this.intents[intentName]?.priority || 'medium'
    }));
  }

  /**
   * 🔍 BUSCAR INTENCIÓN POR NOMBRE O DESCRIPCIÓN
   */
  searchIntents(searchTerm) {
    const term = searchTerm.toLowerCase();
    const results = [];

    for (const [intentName, intentData] of Object.entries(this.intents)) {
      if (intentName.toLowerCase().includes(term) || 
          intentData.description.toLowerCase().includes(term) ||
          intentData.keywords.some(keyword => keyword.toLowerCase().includes(term))) {
        results.push({
          name: intentName,
          description: intentData.description,
          confidence: intentData.confidence,
          priority: intentData.priority,
          keywords: intentData.keywords.slice(0, 5), // Primeras 5 keywords
          matchType: intentName.toLowerCase().includes(term) ? 'name' : 
                   intentData.description.toLowerCase().includes(term) ? 'description' : 'keyword'
        });
      }
    }

    return results.sort((a, b) => {
      if (a.matchType === 'name' && b.matchType !== 'name') return -1;
      if (b.matchType === 'name' && a.matchType !== 'name') return 1;
      return b.confidence - a.confidence;
    });
  }

  /**
   * 📝 AGREGAR NUEVA INTENCIÓN DINÁMICAMENTE
   */
  addCustomIntent(intentName, intentConfig) {
    try {
      // Validar configuración
      if (!intentName || typeof intentName !== 'string') {
        throw new Error('Nombre de intención inválido');
      }

      if (!intentConfig.description || !intentConfig.patterns || !intentConfig.keywords) {
        throw new Error('Configuración de intención incompleta');
      }

      // Crear patrones regex
      const patterns = intentConfig.patterns.map(pattern => {
        if (typeof pattern === 'string') {
          return new RegExp(pattern, 'i');
        }
        return pattern;
      });

      // Agregar intención
      this.intents[intentName] = {
        name: intentName,
        description: intentConfig.description,
        patterns: patterns,
        keywords: intentConfig.keywords,
        confidence: intentConfig.confidence || 0.8,
        priority: intentConfig.priority || 'medium',
        context: intentConfig.context || [],
        quickResponse: intentConfig.quickResponse || false,
        requiresHuman: intentConfig.requiresHuman || false,
        customIntent: true,
        dateAdded: new Date().toISOString()
      };

      console.log(`✅ Intención personalizada '${intentName}' agregada exitosamente`);
      return true;

    } catch (error) {
      console.error('❌ Error agregando intención personalizada:', error);
      return false;
    }
  }

  /**
   * 🗑️ ELIMINAR INTENCIÓN PERSONALIZADA
   */
  removeCustomIntent(intentName) {
    if (this.intents[intentName] && this.intents[intentName].customIntent) {
      delete this.intents[intentName];
      console.log(`🗑️ Intención personalizada '${intentName}' eliminada`);
      return true;
    }
    return false;
  }

  /**
   * 🔧 ACTUALIZAR CONFIGURACIÓN DE INTENCIÓN
   */
  updateIntentConfig(intentName, updates) {
    if (!this.intents[intentName]) {
      return false;
    }

    try {
      const intent = this.intents[intentName];
      
      if (updates.confidence !== undefined) {
        intent.confidence = Math.max(0, Math.min(1, updates.confidence));
      }
      
      if (updates.priority !== undefined) {
        intent.priority = updates.priority;
      }
      
      if (updates.keywords !== undefined) {
        intent.keywords = [...intent.keywords, ...updates.keywords];
      }
      
      if (updates.patterns !== undefined) {
        const newPatterns = updates.patterns.map(p => new RegExp(p, 'i'));
        intent.patterns = [...intent.patterns, ...newPatterns];
      }

      intent.lastUpdated = new Date().toISOString();
      console.log(`🔧 Intención '${intentName}' actualizada`);
      return true;

    } catch (error) {
      console.error('❌ Error actualizando intención:', error);
      return false;
    }
  }

  /**
   * 📊 EXPORTAR CONFIGURACIÓN DE INTENCIONES
   */
  exportIntents() {
    const exportData = {
      version: '2.0',
      domain: 'Judaica Breslov Colombia',
      exportDate: new Date().toISOString(),
      totalIntents: Object.keys(this.intents).length,
      intents: {}
    };

    for (const [intentName, intentData] of Object.entries(this.intents)) {
      exportData.intents[intentName] = {
        description: intentData.description,
        patterns: intentData.patterns.map(p => p.source),
        keywords: intentData.keywords,
        confidence: intentData.confidence,
        priority: intentData.priority,
        context: intentData.context,
        quickResponse: intentData.quickResponse,
        requiresHuman: intentData.requiresHuman,
        isCustom: intentData.customIntent || false,
        isFromDB: intentData.dbSource || false
      };
    }

    return exportData;
  }

  /**
   * 📥 IMPORTAR CONFIGURACIÓN DE INTENCIONES
   */
  async importIntents(configData) {
    try {
      if (!configData.intents || typeof configData.intents !== 'object') {
        throw new Error('Formato de configuración inválido');
      }

      let importCount = 0;

      for (const [intentName, intentConfig] of Object.entries(configData.intents)) {
        if (this.addCustomIntent(intentName, intentConfig)) {
          importCount++;
        }
      }

      console.log(`📥 Importadas ${importCount} intenciones exitosamente`);
      return importCount;

    } catch (error) {
      console.error('❌ Error importando intenciones:', error);
      return 0;
    }
  }

  /**
   * 🔄 REENTRENAR MODELO CON FEEDBACK
   */
  async retrainWithFeedback(trainingData) {
    try {
      console.log('🔄 Iniciando reentrenamiento con feedback...');
      
      // Analizar feedback para ajustar confianzas
      for (const feedback of trainingData) {
        const { message, expectedIntent, actualIntent, wasCorrect, userRating } = feedback;
        
        if (!wasCorrect && expectedIntent && this.intents[expectedIntent]) {
          // Aumentar confianza de la intención correcta
          this.intents[expectedIntent].confidence = Math.min(
            this.intents[expectedIntent].confidence + 0.05, 
            1.0
          );
          
          // Agregar mensaje como patrón si es útil
          const messagePattern = this._generatePatternFromMessage(message);
          if (messagePattern) {
            this.intents[expectedIntent].patterns.push(messagePattern);
          }
        }
        
        if (actualIntent && this.intents[actualIntent] && !wasCorrect) {
          // Reducir ligeramente confianza de la intención incorrecta
          this.intents[actualIntent].confidence = Math.max(
            this.intents[actualIntent].confidence - 0.02, 
            0.1
          );
        }
      }

      console.log('✅ Reentrenamiento completado');
      return true;

    } catch (error) {
      console.error('❌ Error en reentrenamiento:', error);
      return false;
    }
  }

  /**
   * 🎯 GENERAR PATRÓN DESDE MENSAJE DE FEEDBACK
   */
  _generatePatternFromMessage(message) {
    try {
      // Limpiar y normalizar mensaje
      const cleanMessage = message.toLowerCase()
        .replace(/[^\wáéíóúñü\s]/g, '') // Mantener solo letras, números y espacios
        .trim();

      if (cleanMessage.length < 5) return null;

      // Crear patrón flexible
      const words = cleanMessage.split(' ');
      if (words.length > 6) return null; // Evitar patrones muy largos

      // Crear regex con cierta flexibilidad
      const patternWords = words.map(word => {
        if (word.length > 3) {
          return `${word.slice(0, -1)}\\w*`; // Permitir variaciones en el final
        }
        return word;
      });

      const pattern = new RegExp(`\\b${patternWords.join('\\s+')}\b`, 'i');
      return pattern;

    } catch (error) {
      console.warn('⚠️ Error generando patrón:', error);
      return null;
    }
  }

  /**
   * 📋 VALIDAR INTEGRIDAD DEL CLASIFICADOR
   */
  validateIntegrity() {
    const issues = [];
    let totalPatterns = 0;
    let totalKeywords = 0;

    for (const [intentName, intentData] of Object.entries(this.intents)) {
      // Validar estructura básica
      if (!intentData.name || !intentData.description) {
        issues.push(`Intención '${intentName}' tiene estructura incompleta`);
      }

      // Validar patrones
      if (!Array.isArray(intentData.patterns)) {
        issues.push(`Intención '${intentName}' no tiene patrones válidos`);
      } else {
        totalPatterns += intentData.patterns.length;
        
        // Validar cada patrón
        intentData.patterns.forEach((pattern, index) => {
          if (!(pattern instanceof RegExp)) {
            issues.push(`Patrón ${index} de '${intentName}' no es RegExp válido`);
          }
        });
      }

      // Validar keywords
      if (!Array.isArray(intentData.keywords)) {
        issues.push(`Intención '${intentName}' no tiene keywords válidas`);
      } else {
        totalKeywords += intentData.keywords.length;
      }

      // Validar confianza
      if (typeof intentData.confidence !== 'number' || 
          intentData.confidence < 0 || intentData.confidence > 1) {
        issues.push(`Confianza de '${intentName}' fuera del rango válido (0-1)`);
      }

      // Validar prioridad
      const validPriorities = ['highest', 'high', 'medium', 'low', 'lowest'];
      if (!validPriorities.includes(intentData.priority)) {
        issues.push(`Prioridad de '${intentName}' no es válida`);
      }
    }

    return {
      isValid: issues.length === 0,
      issues,
      stats: {
        totalIntents: Object.keys(this.intents).length,
        totalPatterns,
        totalKeywords,
        avgPatternsPerIntent: totalPatterns / Object.keys(this.intents).length,
        avgKeywordsPerIntent: totalKeywords / Object.keys(this.intents).length
      }
    };
  }

  /**
   * 🧹 LIMPIEZA AVANZADA DE CACHE
   */
  clearCache(options = {}) {
    const { 
      olderThan = 0, 
      intentType = null, 
      lowConfidence = false 
    } = options;

    let cleared = 0;
    const now = Date.now();

    for (const [key, value] of this.intentCache.entries()) {
      let shouldClear = false;

      // Limpiar por edad
      if (olderThan > 0 && (now - value.timestamp) > olderThan) {
        shouldClear = true;
      }

      // Limpiar por tipo de intención
      if (intentType && value.data.type === intentType) {
        shouldClear = true;
      }

      // Limpiar por confianza baja
      if (lowConfidence && value.data.confidence < 0.5) {
        shouldClear = true;
      }

      if (shouldClear || olderThan === 0) {
        this.intentCache.delete(key);
        cleared++;
      }
    }

    console.log(`🧹 Cache limpiado: ${cleared} entradas eliminadas`);
    return cleared;
  }

  /**
   * 🎭 MODO DEBUG AVANZADO
   */
  enableDebugMode(verbose = false) {
    this.debugMode = true;
    this.verboseDebug = verbose;
    
    // Interceptar clasificaciones para logging detallado
    this.originalClassify = this.classify;
    this.classify = async function(message, userContext = {}) {
      const startTime = Date.now();
      console.log('🐛 DEBUG: Clasificando mensaje:', message.substring(0, 100));
      
      const result = await this.originalClassify.call(this, message, userContext);
      
      const processingTime = Date.now() - startTime;
      console.log('🐛 DEBUG: Resultado:', {
        intent: result.type,
        confidence: result.confidence.toFixed(3),
        processingTime: `${processingTime}ms`,
        entities: Object.keys(result.entities || {}),
        isQuick: result.isQuick
      });

      if (this.verboseDebug) {
        console.log('🐛 DEBUG VERBOSE:', result);
      }

      return result;
    };

    console.log('🐛 Modo debug activado');
  }

  /**
   * 🔇 DESACTIVAR MODO DEBUG
   */
  disableDebugMode() {
    if (this.originalClassify) {
      this.classify = this.originalClassify;
      delete this.originalClassify;
    }
    
    this.debugMode = false;
    this.verboseDebug = false;
    console.log('🔇 Modo debug desactivado');
  }
}