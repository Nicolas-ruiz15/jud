// lib/chatbot/synonyms.js - GESTOR CORREGIDO DE SINÓNIMOS
import { query } from '../database';

export class SynonymManager {
  constructor() {
    // Cache de sinónimos para optimización
    this.synonymCache = new Map();
    this.cacheTimeout = 10 * 60 * 1000; // 10 minutos
    
    // Estado de inicialización
    this.isInitialized = false;
    
    // Sinónimos estáticos base (siempre disponibles)
    this.staticSynonyms = {
      'tefilin': {
        primary: 'tefilin',
        variations: ['tefilín', 'tefillin', 'tfilin', 'tefelin', 'phylacteries', 'filacterias'],
        related: ['cajas de rezo', 'correas', 'retzuot', 'batim', 'parshiot'],
        types: ['rashi', 'rabeinu tam', 'ashkenazi', 'sefaradi', 'sefardi'],
        qualities: ['mehudar', 'kosher', 'simple', 'premium'],
        context: ['rezo', 'oración', 'plegaria', 'mitzvah', 'religioso']
      },
      
      'tallit': {
        primary: 'tallit',
        variations: ['talit', 'tallitot', 'talitot', 'tallis', 'talis'],
        related: ['manto de oración', 'prayer shawl', 'tzitzit', 'tzitzis'],
        types: ['gadol', 'katan', 'lana', 'seda', 'algodón', 'acrílico'],
        qualities: ['kosher', 'mehudar', 'premium', 'simple'],
        context: ['rezo', 'sinagoga', 'shabat', 'festividades']
      },

      'mezuzah': {
        primary: 'mezuzah',
        variations: ['mezuza', 'mezuzot', 'mezuzá'],
        related: ['pergamino', 'klaf', 'estuche', 'caja', 'sofer'],
        types: ['decorativa', 'simple', 'plata', 'madera', 'metal', 'cristal'],
        qualities: ['kosher', 'mehudar', 'artesanal'],
        context: ['puerta', 'hogar', 'casa', 'bendición', 'protección']
      },

      'libros': {
        primary: 'libros',
        variations: ['libro', 'sefer', 'sfarim', 'sefarim', 'texto', 'textos'],
        related: ['sidur', 'sidurim', 'jumash', 'chumash', 'tanaj', 'tanakh', 'tehilim', 'salmos'],
        types: ['torah', 'talmud', 'mishna', 'guemara', 'halajá', 'cabalá', 'zohar', 'midrash'],
        qualities: ['hebreo', 'español', 'bilingüe', 'comentarios', 'traducido'],
        context: ['estudio', 'lectura', 'aprendizaje', 'judaísmo', 'religión']
      },

      'kipa': {
        primary: 'kipa',
        variations: ['kipá', 'kipot', 'yarmulke', 'yarmulka', 'kippah', 'kippa'],
        related: ['solideo', 'gorro judío', 'cobertura'],
        types: ['tejida', 'satén', 'terciopelo', 'cuero', 'bordada', 'serigrafiada'],
        qualities: ['artesanal', 'personalizada', 'ceremonial', 'diaria'],
        context: ['cabeza', 'usar', 'llevar', 'respeto', 'tradición']
      },

      'buscar': {
        primary: 'buscar',
        variations: ['busco', 'buscando', 'encontrar', 'ver', 'mostrar', 'enseñar'],
        related: ['necesito', 'quiero', 'deseo', 'me interesa'],
        context: ['producto', 'información', 'ayuda']
      },

      'comprar': {
        primary: 'comprar',
        variations: ['compro', 'comprando', 'adquirir', 'conseguir', 'obtener'],
        related: ['precio', 'costo', 'valor', 'pagar', 'método de pago'],
        context: ['proceso', 'forma', 'cómo', 'dónde']
      }
    };

    // Sinónimos cargados desde BD
    this.synonyms = { ...this.staticSynonyms };
  }

  /**
   * Inicialización del manager - CORREGIDA
   */
  async initialize() {
    if (this.isInitialized) {
      return true;
    }

    try {
      console.log('🔄 Inicializando Synonym Manager...');
      await this.loadDatabaseSynonyms();
      this.isInitialized = true;
      console.log('✅ Synonym Manager inicializado');
      return true;
    } catch (error) {
      console.error('❌ Error inicializando sinónimos:', error);
      // Usar solo sinónimos estáticos si falla la BD
      this.synonyms = { ...this.staticSynonyms };
      this.isInitialized = true;
      console.log('⚠️ Usando solo sinónimos estáticos');
      return true;
    }
  }

  /**
   * Cargar sinónimos desde la base de datos - CORREGIDO
   */
  async loadDatabaseSynonyms() {
    try {
      // Verificar si la tabla existe
      const tableExists = await query("SHOW TABLES LIKE 'product_synonyms'");
      if (tableExists.length === 0) {
        console.log('⚠️ Tabla product_synonyms no existe, usando sinónimos estáticos');
        return;
      }

      const dbSynonyms = await query(`
        SELECT 
          ps.base_term,
          ps.synonym,
          ps.language,
          ps.context,
          ps.priority,
          ps.is_active
        FROM product_synonyms ps
        WHERE ps.is_active = 1
        ORDER BY ps.priority DESC, ps.base_term ASC
      `);

      console.log(`📚 Cargados ${dbSynonyms.length} sinónimos de la BD`);

      // Procesar sinónimos de BD
      const processedSynonyms = {};
      
      dbSynonyms.forEach(syn => {
        const term = syn.base_term.toLowerCase();
        
        if (!processedSynonyms[term]) {
          processedSynonyms[term] = {
            primary: term,
            variations: [],
            related: [],
            context: [],
            dbSource: true
          };
        }

        // Agregar sinónimo
        const synonymTerm = syn.synonym.toLowerCase();
        if (!processedSynonyms[term].variations.includes(synonymTerm)) {
          processedSynonyms[term].variations.push(synonymTerm);
        }

        // Agregar contexto si existe
        if (syn.context && !processedSynonyms[term].context.includes(syn.context)) {
          processedSynonyms[term].context.push(syn.context);
        }
      });

      // Merge con sinónimos estáticos
      this.synonyms = { ...this.staticSynonyms, ...processedSynonyms };
      
      console.log(`🔗 Total sinónimos disponibles: ${Object.keys(this.synonyms).length}`);

    } catch (error) {
      console.error('❌ Error cargando sinónimos de BD:', error);
      throw error;
    }
  }

  /**
   * Expandir sinónimos en un texto - CORREGIDO
   */
  async expandSynonyms(text) {
    try {
      // Asegurar inicialización
      if (!this.isInitialized) {
        await this.initialize();
      }

      if (!text || typeof text !== 'string') {
        return '';
      }

      const words = text.toLowerCase().split(/\s+/);
      const expandedTerms = new Set();
      
      // Agregar términos originales
      words.forEach(word => {
        if (word.trim()) {
          expandedTerms.add(word.trim());
        }
      });
      
      // Buscar sinónimos para cada palabra
      for (const word of words) {
        if (!word.trim()) continue;
        
        const synonymData = await this.getSynonymsForTerm(word.trim());
        
        if (synonymData) {
          // Agregar variaciones más relevantes
          synonymData.variations?.slice(0, 3).forEach(syn => expandedTerms.add(syn));
          synonymData.related?.slice(0, 2).forEach(rel => expandedTerms.add(rel));
        }
      }

      return Array.from(expandedTerms).join(' ');

    } catch (error) {
      console.error('❌ Error expandiendo sinónimos:', error);
      return text || '';
    }
  }

  /**
   * Obtener sinónimos específicos para un término - CORREGIDO
   */
  async getSynonymsForTerm(term) {
    try {
      if (!term || typeof term !== 'string') {
        return null;
      }

      const normalizedTerm = term.toLowerCase().trim();
      if (!normalizedTerm) {
        return null;
      }
      
      // Verificar cache
      const cacheKey = `synonym_${normalizedTerm}`;
      if (this.synonymCache.has(cacheKey)) {
        const cached = this.synonymCache.get(cacheKey);
        if (Date.now() - cached.timestamp < this.cacheTimeout) {
          return cached.data;
        }
      }

      // Buscar sinónimo exacto
      let synonymData = this.synonyms[normalizedTerm];

      // Si no se encuentra exacto, buscar coincidencias parciales
      if (!synonymData) {
        for (const [key, data] of Object.entries(this.synonyms)) {
          if (key.includes(normalizedTerm) || normalizedTerm.includes(key)) {
            synonymData = data;
            break;
          }
          
          if (data.variations?.some(v => v.includes(normalizedTerm) || normalizedTerm.includes(v))) {
            synonymData = data;
            break;
          }
        }
      }

      // Guardar en cache
      this.synonymCache.set(cacheKey, {
        data: synonymData,
        timestamp: Date.now()
      });

      return synonymData;

    } catch (error) {
      console.error('❌ Error obteniendo sinónimos para término:', error);
      return null;
    }
  }

  /**
   * Obtener sinónimos específicos de productos - CORREGIDO
   */
  async getProductSynonyms(productTerm) {
    try {
      if (!productTerm || typeof productTerm !== 'string') {
        return [productTerm || ''];
      }

      const synonymData = await this.getSynonymsForTerm(productTerm);
      
      if (synonymData) {
        return [
          synonymData.primary,
          ...synonymData.variations || [],
          ...synonymData.related?.slice(0, 2) || []
        ].filter(Boolean);
      }

      // Fallback: buscar en BD si está disponible
      try {
        const tableExists = await query("SHOW TABLES LIKE 'product_synonyms'");
        if (tableExists.length > 0) {
          const dbResults = await query(`
            SELECT DISTINCT synonym 
            FROM product_synonyms ps
            WHERE (
              LOWER(ps.base_term) LIKE ? OR 
              LOWER(ps.synonym) LIKE ?
            ) AND ps.is_active = 1
            LIMIT 10
          `, [`%${productTerm.toLowerCase()}%`, `%${productTerm.toLowerCase()}%`]);

          if (dbResults.length > 0) {
            return [productTerm, ...dbResults.map(r => r.synonym)];
          }
        }
      } catch (dbError) {
        console.log('⚠️ Error en búsqueda de sinónimos de BD:', dbError.message);
      }

      return [productTerm];

    } catch (error) {
      console.error('❌ Error en getProductSynonyms:', error);
      return [productTerm || ''];
    }
  }

  /**
   * Detectar categorías mencionadas en el texto - CORREGIDO
   */
  async detectCategories(text) {
    try {
      if (!text || typeof text !== 'string') {
        return [];
      }

      const categories = [];
      const normalizedText = text.toLowerCase();

      const categoryMap = {
        'libros': ['libro', 'libros', 'sefer', 'sfarim', 'texto', 'lectura', 'estudio'],
        'tefilin': ['tefilin', 'tefilín', 'phylacteries', 'filacterias', 'rezo'],
        'tallitot': ['tallit', 'talit', 'manto', 'tzitzit', 'prayer shawl'],
        'mezuzot': ['mezuzah', 'mezuza', 'pergamino', 'puerta', 'hogar'],
        'kipot': ['kipa', 'kipá', 'yarmulke', 'gorro', 'cabeza'],
        'velas': ['vela', 'velas', 'candela', 'nerot', 'shabat', 'luz']
      };

      for (const [category, keywords] of Object.entries(categoryMap)) {
        if (keywords.some(keyword => normalizedText.includes(keyword))) {
          categories.push(category);
        }
      }

      return categories;

    } catch (error) {
      console.error('❌ Error detectando categorías:', error);
      return [];
    }
  }

  /**
   * Detectar productos específicos mencionados - CORREGIDO
   */
  async detectProducts(text) {
    try {
      if (!text || typeof text !== 'string') {
        return [];
      }

      const products = [];
      const normalizedText = text.toLowerCase();

      for (const [product, data] of Object.entries(this.synonyms)) {
        if (normalizedText.includes(product)) {
          products.push(product);
          continue;
        }

        if (data.variations?.some(variation => normalizedText.includes(variation))) {
          products.push(product);
          continue;
        }

        if (data.related?.some(related => normalizedText.includes(related))) {
          products.push(product);
        }
      }

      return [...new Set(products)];

    } catch (error) {
      console.error('❌ Error detectando productos:', error);
      return [];
    }
  }

  /**
   * Agregar nuevos sinónimos dinámicamente - CORREGIDO
   */
  async addSynonym(baseTerm, synonymTerm, context = 'general') {
    try {
      if (!baseTerm || !synonymTerm) {
        console.warn('⚠️ Términos base y sinónimo son requeridos');
        return false;
      }

      // Verificar si la tabla existe antes de insertar
      const tableExists = await query("SHOW TABLES LIKE 'product_synonyms'");
      if (tableExists.length === 0) {
        console.warn('⚠️ Tabla product_synonyms no existe, agregando solo a memoria');
        
        // Agregar solo a memoria
        const normalizedProduct = baseTerm.toLowerCase();
        if (!this.synonyms[normalizedProduct]) {
          this.synonyms[normalizedProduct] = {
            primary: normalizedProduct,
            variations: [],
            related: [],
            context: []
          };
        }

        if (!this.synonyms[normalizedProduct].variations.includes(synonymTerm)) {
          this.synonyms[normalizedProduct].variations.push(synonymTerm);
        }

        console.log(`✅ Sinónimo agregado en memoria: ${baseTerm} -> ${synonymTerm}`);
        return true;
      }

      await query(`
        INSERT INTO product_synonyms 
        (base_term, synonym, language, context, priority, is_active)
        VALUES (?, ?, 'es', ?, 5, 1)
        ON DUPLICATE KEY UPDATE
          synonym = VALUES(synonym),
          updated_at = NOW()
      `, [baseTerm, synonymTerm, context]);

      // Actualizar cache local
      const normalizedProduct = baseTerm.toLowerCase();
      if (!this.synonyms[normalizedProduct]) {
        this.synonyms[normalizedProduct] = {
          primary: normalizedProduct,
          variations: [],
          related: [],
          context: []
        };
      }

      if (!this.synonyms[normalizedProduct].variations.includes(synonymTerm)) {
        this.synonyms[normalizedProduct].variations.push(synonymTerm);
      }

      console.log(`✅ Sinónimo agregado: ${baseTerm} -> ${synonymTerm}`);
      return true;

    } catch (error) {
      console.error('❌ Error agregando sinónimo:', error);
      return false;
    }
  }

  /**
   * Pre-cargar sinónimos más comunes - CORREGIDO
   */
  async preloadCommonSynonyms() {
    const commonTerms = [
      'tefilin', 'tallit', 'mezuzah', 'libros', 'kipa',
      'precio', 'comprar', 'kosher', 'gracias', 'hola'
    ];

    console.log('🔥 Pre-cargando sinónimos comunes...');
    
    let loadedCount = 0;
    for (const term of commonTerms) {
      try {
        await this.getSynonymsForTerm(term);
        loadedCount++;
      } catch (error) {
        console.warn(`⚠️ Error pre-cargando sinónimo para ${term}:`, error.message);
      }
    }

    console.log(`✅ Pre-cargados sinónimos para ${loadedCount}/${commonTerms.length} términos`);
  }

  /**
   * Limpiar cache de sinónimos
   */
  clearCache() {
    this.synonymCache.clear();
    console.log('🧹 Cache de sinónimos limpiado');
  }

  /**
   * Obtener estadísticas del manager
   */
  getStats() {
    return {
      totalSynonyms: Object.keys(this.synonyms).length,
      cacheSize: this.synonymCache.size,
      staticSynonyms: Object.keys(this.staticSynonyms).length,
      dbSynonyms: Object.keys(this.synonyms).length - Object.keys(this.staticSynonyms).length,
      isInitialized: this.isInitialized
    };
  }

  /**
   * Buscar sinónimos similares - CORREGIDO
   */
  findSimilarSynonyms(term, threshold = 0.7) {
    try {
      if (!term || typeof term !== 'string') {
        return [];
      }

      const similar = [];
      const normalizedTerm = term.toLowerCase();

      for (const [key, data] of Object.entries(this.synonyms)) {
        const similarity = this.calculateSimilarity(normalizedTerm, key);
        
        if (similarity >= threshold) {
          similar.push({
            term: key,
            similarity,
            data
          });
        }
      }

      return similar.sort((a, b) => b.similarity - a.similarity);

    } catch (error) {
      console.error('❌ Error buscando sinónimos similares:', error);
      return [];
    }
  }

  /**
   * Calcular similitud entre dos strings
   */
  calculateSimilarity(str1, str2) {
    try {
      if (!str1 || !str2) return 0;
      
      const longer = str1.length > str2.length ? str1 : str2;
      const shorter = str1.length > str2.length ? str2 : str1;
      
      if (longer.length === 0) return 1.0;
      
      const distance = this.levenshteinDistance(longer, shorter);
      return (longer.length - distance) / longer.length;
    } catch (error) {
      console.error('❌ Error calculando similitud:', error);
      return 0;
    }
  }

  /**
   * Calcular distancia de Levenshtein
   */
  levenshteinDistance(str1, str2) {
    try {
      if (!str1 || !str2) return Math.max(str1?.length || 0, str2?.length || 0);

      const matrix = [];

      for (let i = 0; i <= str2.length; i++) {
        matrix[i] = [i];
      }

      for (let j = 0; j <= str1.length; j++) {
        matrix[0][j] = j;
      }

      for (let i = 1; i <= str2.length; i++) {
        for (let j = 1; j <= str1.length; j++) {
          if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
            matrix[i][j] = matrix[i - 1][j - 1];
          } else {
            matrix[i][j] = Math.min(
              matrix[i - 1][j - 1] + 1,
              matrix[i][j - 1] + 1,
              matrix[i - 1][j] + 1
            );
          }
        }
      }

      return matrix[str2.length][str1.length];
    } catch (error) {
      console.error('❌ Error calculando distancia Levenshtein:', error);
      return 999; // Valor alto en caso de error
    }
  }
}