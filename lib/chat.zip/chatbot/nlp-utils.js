// lib/chatbot/nlp-utils.js - UTILIDADES PROFESIONALES DE NLP
export class NLPUtils {
  constructor() {
    // Palabras vacías en español
    this.stopWords = new Set([
      'el', 'la', 'de', 'que', 'y', 'a', 'en', 'un', 'es', 'se', 'no', 'te', 'lo', 'le',
      'da', 'su', 'por', 'son', 'con', 'para', 'al', 'del', 'los', 'las', 'una', 'sobre',
      'todo', 'también', 'tras', 'otro', 'algún', 'alguna', 'hasta', 'había', 'sido',
      'está', 'estoy', 'estar', 'tiene', 'tener', 'hace', 'hacer', 'puede', 'poder',
      'dijo', 'decir', 'cada', 'donde', 'muy', 'sin', 'vez', 'mucho', 'saber', 'qué',
      'cómo', 'cuál', 'cuándo', 'dónde', 'por qué', 'porque', 'ya', 'sí', 'así', 'aquí',
      'ahí', 'allí', 'ese', 'esa', 'esto', 'esta', 'esos', 'esas', 'mi', 'tu', 'nos',
      'me', 'más', 'pero', 'o', 'si', 'había', 'han', 'he', 'has', 'hemos', 'habían'
    ]);

    // Mapeo de acentos para normalización
    this.accentMap = {
      'á': 'a', 'à': 'a', 'ä': 'a', 'â': 'a', 'ā': 'a', 'ă': 'a', 'ą': 'a',
      'é': 'e', 'è': 'e', 'ë': 'e', 'ê': 'e', 'ē': 'e', 'ĕ': 'e', 'ė': 'e', 'ę': 'e',
      'í': 'i', 'ì': 'i', 'ï': 'i', 'î': 'i', 'ī': 'i', 'ĭ': 'i', 'į': 'i',
      'ó': 'o', 'ò': 'o', 'ö': 'o', 'ô': 'o', 'ō': 'o', 'ŏ': 'o', 'ő': 'o',
      'ú': 'u', 'ù': 'u', 'ü': 'u', 'û': 'u', 'ū': 'u', 'ŭ': 'u', 'ů': 'u', 'ű': 'u', 'ų': 'u',
      'ñ': 'n', 'ç': 'c'
    };

    // Contracciones comunes en español
    this.contractions = {
      'al': 'a el',
      'del': 'de el',
      'nel': 'en el',
      'pal': 'para el',
      'pol': 'por el'
    };

    // Emojis y su significado
    this.emojiMap = {
      '😊': 'feliz',
      '😁': 'feliz',
      '🙂': 'feliz',
      '😍': 'amor',
      '❤️': 'amor',
      '💕': 'amor',
      '😢': 'triste',
      '😭': 'triste',
      '😡': 'enojado',
      '😠': 'enojado',
      '👍': 'bueno',
      '👎': 'malo',
      '🤔': 'pensando',
      '😕': 'confundido',
      '😖': 'preocupado',
      '🙏': 'gracias'
    };

    // Jerga y abreviaciones
    this.slangMap = {
      'q': 'que',
      'xq': 'porque',
      'pq': 'porque',
      'x': 'por',
      'bn': 'bien',
      'bno': 'bueno',
      'tbn': 'también',
      'tmb': 'también',
      'dnd': 'donde',
      'cdo': 'cuando',
      'cm': 'como',
      'xa': 'para',
      'pa': 'para',
      'k': 'que',
      'aki': 'aquí',
      'ai': 'ahí',
      'lla': 'ya',
      'xfa': 'por favor',
      'pf': 'por favor',
      'porfis': 'por favor'
    };

    // Correcciones ortográficas comunes
    this.spellCorrections = {
      // Productos judaicos
      'tefelin': 'tefilin',
      'tefelín': 'tefilin',
      'tefilín': 'tefilin',
      'phylacteries': 'tefilin',
      'filacterias': 'tefilin',
      'talit': 'tallit',
      'talis': 'tallit',
      'mezusa': 'mezuzah',
      'mezuza': 'mezuzah',
      'kippa': 'kipa',
      'yarmulka': 'kipa',
      'yarmulke': 'kipa',
      'kipot': 'kipa',
      'libor': 'libro',
      'livos': 'libros',
      'shofhar': 'shofar',
      'shophar': 'shofar',
      'menora': 'menorah',
      'janukia': 'menorah',
      'chanukia': 'menorah',
      
      // Palabras comunes
      'ace': 'hace',
      'ase': 'hace',
      'asia': 'hacia',
      'aver': 'a ver',
      'aber': 'a ver',
      'haber': 'a ver',
      'porke': 'porque',
      'xke': 'porque',
      'aora': 'ahora',
      'ahora': 'ahora',
      'mui': 'muy',
      'mucho': 'mucho',
      'tanbien': 'también',
      'envio': 'envío',
      'envios': 'envíos',
      'presio': 'precio',
      'precios': 'precios'
    };

    // Patrones de tokenización
    this.tokenPatterns = {
      url: /https?:\/\/[^\s]+/gi,
      email: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/gi,
      phone: /(\+?57\s?)?[0-9]{3}[\s-]?[0-9]{3}[\s-]?[0-9]{4}/gi,
      currency: /\$[0-9,.]+(\.?\d{2})?/gi,
      number: /\b\d+\b/gi,
      hashtag: /#[a-zA-Z0-9_]+/gi,
      mention: /@[a-zA-Z0-9_]+/gi
    };
  }

  /**
   * Normalizar texto completo
   */
  normalizeText(text) {
    if (!text || typeof text !== 'string') {
      return '';
    }

    let normalized = text;

    // 1. Convertir a minúsculas
    normalized = normalized.toLowerCase();

    // 2. Preservar URLs, emails, etc. antes de normalizar
    const preservedTokens = this.preserveSpecialTokens(normalized);
    
    // 3. Remover emojis pero extraer su significado
    normalized = this.processEmojis(normalized);

    // 4. Expandir contracciones
    normalized = this.expandContractions(normalized);

    // 5. Corregir jerga y abreviaciones
    normalized = this.correctSlang(normalized);

    // 6. Corrección ortográfica
    normalized = this.correctSpelling(normalized);

    // 7. Normalizar acentos
    normalized = this.removeAccents(normalized);

    // 8. Limpiar caracteres especiales pero mantener algunos útiles
    normalized = this.cleanSpecialCharacters(normalized);

    // 9. Normalizar espacios múltiples
    normalized = normalized.replace(/\s+/g, ' ').trim();

    // 10. Restaurar tokens especiales si es necesario
    normalized = this.restoreSpecialTokens(normalized, preservedTokens);

    return normalized;
  }

  /**
   * Preservar tokens especiales antes de normalización
   */
  preserveSpecialTokens(text) {
    const tokens = {};
    let counter = 0;

    // Preservar URLs
    text = text.replace(this.tokenPatterns.url, (match) => {
      const placeholder = `__URL_${counter++}__`;
      tokens[placeholder] = match;
      return placeholder;
    });

    // Preservar emails
    text = text.replace(this.tokenPatterns.email, (match) => {
      const placeholder = `__EMAIL_${counter++}__`;
      tokens[placeholder] = match;
      return placeholder;
    });

    // Preservar teléfonos
    text = text.replace(this.tokenPatterns.phone, (match) => {
      const placeholder = `__PHONE_${counter++}__`;
      tokens[placeholder] = match;
      return placeholder;
    });

    // Preservar monedas
    text = text.replace(this.tokenPatterns.currency, (match) => {
      const placeholder = `__CURRENCY_${counter++}__`;
      tokens[placeholder] = match;
      return placeholder;
    });

    return { text, tokens };
  }

  /**
   * Restaurar tokens especiales después de normalización
   */
  restoreSpecialTokens(text, preservedData) {
    let restored = preservedData.text || text;
    const tokens = preservedData.tokens || {};

    for (const [placeholder, originalValue] of Object.entries(tokens)) {
      restored = restored.replace(placeholder, originalValue);
    }

    return restored;
  }

  /**
   * Procesar emojis y extraer significado
   */
  processEmojis(text) {
    let processed = text;
    
    for (const [emoji, meaning] of Object.entries(this.emojiMap)) {
      if (text.includes(emoji)) {
        // Reemplazar emoji por su significado
        processed = processed.replace(new RegExp(emoji, 'g'), ` ${meaning} `);
      }
    }

    // Remover otros emojis que no están mapeados
    processed = processed.replace(/[\u{1F600}-\u{1F64F}]|[\u{1F300}-\u{1F5FF}]|[\u{1F680}-\u{1F6FF}]|[\u{1F1E0}-\u{1F1FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]/gu, ' ');

    return processed;
  }

  /**
   * Expandir contracciones
   */
  expandContractions(text) {
    let expanded = text;
    
    for (const [contraction, expansion] of Object.entries(this.contractions)) {
      const regex = new RegExp(`\\b${contraction}\\b`, 'gi');
      expanded = expanded.replace(regex, expansion);
    }

    return expanded;
  }

  /**
   * Corregir jerga y abreviaciones
   */
  correctSlang(text) {
    let corrected = text;
    
    for (const [slang, correction] of Object.entries(this.slangMap)) {
      const regex = new RegExp(`\\b${slang}\\b`, 'gi');
      corrected = corrected.replace(regex, correction);
    }

    return corrected;
  }

  /**
   * Corrección ortográfica
   */
  correctSpelling(text) {
    let corrected = text;
    
    for (const [wrong, right] of Object.entries(this.spellCorrections)) {
      const regex = new RegExp(`\\b${wrong}\\b`, 'gi');
      corrected = corrected.replace(regex, right);
    }

    return corrected;
  }

  /**
   * Remover acentos
   */
  removeAccents(text) {
    let normalized = text;
    
    for (const [accented, normal] of Object.entries(this.accentMap)) {
      const regex = new RegExp(accented, 'g');
      normalized = normalized.replace(regex, normal);
    }

    return normalized;
  }

  /**
   * Limpiar caracteres especiales manteniendo algunos útiles
   */
  cleanSpecialCharacters(text) {
    // Mantener: letras, números, espacios, signos de puntuación básicos
    return text.replace(/[^\w\s\$\.,\?\!\-]/g, ' ');
  }

  /**
   * Tokenizar texto en palabras
   */
  tokenize(text) {
    const normalized = this.normalizeText(text);
    
    // Dividir por espacios y filtrar tokens vacíos
    const tokens = normalized.split(/\s+/).filter(token => token.length > 0);
    
    return tokens;
  }

  /**
   * Remover palabras vacías
   */
  removeStopWords(tokens) {
    return tokens.filter(token => !this.stopWords.has(token.toLowerCase()));
  }

  /**
   * Stemming básico en español
   */
  stem(word) {
    // Implementación básica de stemming para español
    let stemmed = word.toLowerCase();
    
    // Remover sufijos comunes
    const suffixes = [
      'aciones', 'ación', 'ando', 'endo', 'ados', 'idos', 'ante', 'ente',
      'mente', 'ería', 'oso', 'osa', 'ivo', 'iva', 'able', 'ible',
      'es', 'as', 'os', 'an', 'en', 'ar', 'er', 'ir'
    ];
    
    for (const suffix of suffixes) {
      if (stemmed.endsWith(suffix) && stemmed.length > suffix.length + 2) {
        stemmed = stemmed.slice(0, -suffix.length);
        break;
      }
    }
    
    return stemmed;
  }

  /**
   * Aplicar stemming a un array de tokens
   */
  stemTokens(tokens) {
    return tokens.map(token => this.stem(token));
  }

  /**
   * Extraer n-gramas del texto
   */
  extractNGrams(tokens, n = 2) {
    const ngrams = [];
    
    for (let i = 0; i <= tokens.length - n; i++) {
      const ngram = tokens.slice(i, i + n).join(' ');
      ngrams.push(ngram);
    }
    
    return ngrams;
  }

  /**
   * Calcular frecuencia de términos
   */
  calculateTermFrequency(tokens) {
    const frequency = {};
    
    for (const token of tokens) {
      frequency[token] = (frequency[token] || 0) + 1;
    }
    
    return frequency;
  }

  /**
   * Extraer entidades nombradas básicas
   */
  extractNamedEntities(text) {
    const entities = {
      persons: [],
      places: [],
      organizations: [],
      products: [],
      numbers: [],
      dates: [],
      urls: [],
      emails: [],
      phones: []
    };

    // Extraer URLs
    const urls = text.match(this.tokenPatterns.url) || [];
    entities.urls = urls;

    // Extraer emails
    const emails = text.match(this.tokenPatterns.email) || [];
    entities.emails = emails;

    // Extraer teléfonos
    const phones = text.match(this.tokenPatterns.phone) || [];
    entities.phones = phones;

    // Extraer números
    const numbers = text.match(this.tokenPatterns.number) || [];
    entities.numbers = numbers.map(n => parseInt(n));

    // Extraer fechas básicas
    const datePatterns = [
      /\d{1,2}\/\d{1,2}\/\d{4}/g,
      /\d{1,2}-\d{1,2}-\d{4}/g,
      /\d{4}-\d{1,2}-\d{1,2}/g
    ];

    datePatterns.forEach(pattern => {
      const matches = text.match(pattern) || [];
      entities.dates.push(...matches);
    });

    // Extraer nombres propios (palabras que empiezan con mayúscula)
    const properNouns = text.match(/\b[A-Z][a-z]+\b/g) || [];
    entities.persons = properNouns;

    // Extraer productos judaicos mencionados
    const jewishProducts = [
      'tefilin', 'tallit', 'mezuzah', 'kipa', 'shofar', 'menorah',
      'sidur', 'chumash', 'torah', 'talmud', 'zohar', 'tehilim'
    ];

    const normalizedText = text.toLowerCase();
    jewishProducts.forEach(product => {
      if (normalizedText.includes(product)) {
        entities.products.push(product);
      }
    });

    return entities;
  }

  /**
   * Calcular similitud entre dos textos usando Jaccard
   */
  calculateJaccardSimilarity(text1, text2) {
    const tokens1 = new Set(this.tokenize(text1));
    const tokens2 = new Set(this.tokenize(text2));
    
    const intersection = new Set([...tokens1].filter(x => tokens2.has(x)));
    const union = new Set([...tokens1, ...tokens2]);
    
    return intersection.size / union.size;
  }

  /**
   * Calcular similitud usando coeficiente de Dice
   */
  calculateDiceSimilarity(text1, text2) {
    const tokens1 = this.tokenize(text1);
    const tokens2 = this.tokenize(text2);
    
    const bigrams1 = new Set(this.extractNGrams(tokens1, 2));
    const bigrams2 = new Set(this.extractNGrams(tokens2, 2));
    
    const intersection = new Set([...bigrams1].filter(x => bigrams2.has(x)));
    
    return (2 * intersection.size) / (bigrams1.size + bigrams2.size);
  }

  /**
   * Detectar sentimiento básico del texto
   */
  detectSentiment(text) {
    const positiveWords = [
      'bueno', 'excelente', 'genial', 'perfecto', 'fantástico', 'maravilloso',
      'increíble', 'hermoso', 'precioso', 'love', 'me gusta', 'feliz',
      'contento', 'satisfecho', 'recomiendo', 'gracias'
    ];

    const negativeWords = [
      'malo', 'terrible', 'horrible', 'pésimo', 'odio', 'no me gusta',
      'triste', 'enojado', 'molesto', 'furioso', 'decepcionado',
      'insatisfecho', 'problema', 'error', 'defectuoso', 'roto'
    ];

    const normalizedText = this.normalizeText(text);
    const tokens = this.tokenize(normalizedText);

    let positiveScore = 0;
    let negativeScore = 0;

    tokens.forEach(token => {
      if (positiveWords.some(word => token.includes(word))) {
        positiveScore++;
      }
      if (negativeWords.some(word => token.includes(word))) {
        negativeScore++;
      }
    });

    // Calcular polaridad
    const total = positiveScore + negativeScore;
    if (total === 0) {
      return { sentiment: 'neutral', confidence: 0.5, scores: { positive: 0, negative: 0 } };
    }

    const positiveRatio = positiveScore / total;
    
    if (positiveRatio > 0.6) {
      return { sentiment: 'positive', confidence: positiveRatio, scores: { positive: positiveScore, negative: negativeScore } };
    } else if (positiveRatio < 0.4) {
      return { sentiment: 'negative', confidence: 1 - positiveRatio, scores: { positive: positiveScore, negative: negativeScore } };
    } else {
      return { sentiment: 'neutral', confidence: 0.5, scores: { positive: positiveScore, negative: negativeScore } };
    }
  }

  /**
   * Detectar idioma básico
   */
  detectLanguage(text) {
    const spanishWords = [
      'el', 'la', 'de', 'que', 'y', 'es', 'en', 'un', 'tiene', 'para',
      'con', 'por', 'una', 'su', 'al', 'los', 'como', 'pero', 'sus'
    ];

    const englishWords = [
      'the', 'of', 'and', 'to', 'a', 'in', 'is', 'you', 'that', 'it',
      'he', 'was', 'for', 'on', 'are', 'as', 'with', 'his', 'they'
    ];

    const hebrewWords = [
      'של', 'את', 'על', 'אל', 'מן', 'כל', 'לא', 'או', 'אם', 'כי',
      'שלום', 'ברוך', 'הבא', 'תודה', 'כשר', 'שבת'
    ];

    const tokens = this.tokenize(text.toLowerCase());
    
    let spanishScore = 0;
    let englishScore = 0;
    let hebrewScore = 0;

    tokens.forEach(token => {
      if (spanishWords.includes(token)) spanishScore++;
      if (englishWords.includes(token)) englishScore++;
      if (hebrewWords.includes(token)) hebrewScore++;
    });

    const maxScore = Math.max(spanishScore, englishScore, hebrewScore);
    
    if (maxScore === 0) {
      return { language: 'unknown', confidence: 0 };
    }

    if (spanishScore === maxScore) {
      return { language: 'spanish', confidence: spanishScore / tokens.length };
    } else if (englishScore === maxScore) {
      return { language: 'english', confidence: englishScore / tokens.length };
    } else {
      return { language: 'hebrew', confidence: hebrewScore / tokens.length };
    }
  }

  /**
   * Extraer keywords más importantes del texto
   */
  extractKeywords(text, maxKeywords = 10) {
    const tokens = this.tokenize(text);
    const filteredTokens = this.removeStopWords(tokens);
    const stemmedTokens = this.stemTokens(filteredTokens);
    
    const frequency = this.calculateTermFrequency(stemmedTokens);
    
    // Ordenar por frecuencia y tomar los más importantes
    const sortedKeywords = Object.entries(frequency)
      .sort(([,a], [,b]) => b - a)
      .slice(0, maxKeywords)
      .map(([keyword, freq]) => ({ keyword, frequency: freq }));

    return sortedKeywords;
  }

  /**
   * Validar si un texto es spam o contenido inapropiado
   */
  isSpamOrInappropriate(text) {
    const spamPatterns = [
      /click\s+here/i,
      /free\s+money/i,
      /urgent/i,
      /congratulations/i,
      /winner/i,
      /lottery/i,
      /\b(viagra|cialis)\b/i,
      /\$\$\$+/,
      /!!!+/,
      /CAPS{4,}/
    ];

    const inappropriateWords = [
      // Agregar según necesidad y contexto cultural
    ];

    const normalizedText = text.toLowerCase();

    // Verificar patrones de spam
    for (const pattern of spamPatterns) {
      if (pattern.test(text)) {
        return { isSpam: true, reason: 'spam_pattern', pattern: pattern.source };
      }
    }

    // Verificar palabras inapropiadas
    for (const word of inappropriateWords) {
      if (normalizedText.includes(word)) {
        return { isSpam: true, reason: 'inappropriate_content', word };
      }
    }

    // Verificar exceso de caracteres repetidos
    if (/(.)\1{4,}/.test(text)) {
      return { isSpam: true, reason: 'excessive_repetition' };
    }

    // Verificar exceso de mayúsculas
    const uppercaseRatio = (text.match(/[A-Z]/g) || []).length / text.length;
    if (uppercaseRatio > 0.7 && text.length > 10) {
      return { isSpam: true, reason: 'excessive_caps' };
    }

    return { isSpam: false };
  }

  /**
   * Formatear texto para respuesta
   */
  formatForResponse(text) {
    // Capitalizar primera letra de cada oración
    return text.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
      return prefix + letter.toUpperCase();
    });
  }

  /**
   * Validar estructura de mensaje
   */
  validateMessageStructure(message) {
    const validation = {
      isValid: true,
      issues: [],
      suggestions: []
    };

    // Validar longitud
    if (message.length < 2) {
      validation.isValid = false;
      validation.issues.push('Mensaje demasiado corto');
      validation.suggestions.push('Intenta ser más específico');
    }

    if (message.length > 1000) {
      validation.isValid = false;
      validation.issues.push('Mensaje demasiado largo');
      validation.suggestions.push('Intenta ser más conciso');
    }

    // Validar caracteres excesivos
    if (/(.)\1{10,}/.test(message)) {
      validation.issues.push('Caracteres repetitivos excesivos');
      validation.suggestions.push('Evita repetir caracteres');
    }

    // Validar formato de pregunta
    const hasQuestionWords = /\b(qué|cómo|cuándo|dónde|por qué|cuál|quién)\b/i.test(message);
    const hasQuestionMark = message.includes('?');
    
    if (hasQuestionWords && !hasQuestionMark) {
      validation.suggestions.push('Considera agregar un signo de interrogación');
    }

    return validation;
  }

  /**
   * Obtener estadísticas del texto
   */
  getTextStatistics(text) {
    const tokens = this.tokenize(text);
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const words = tokens.length;
    const characters = text.length;
    const charactersNoSpaces = text.replace(/\s/g, '').length;

    return {
      characters,
      charactersNoSpaces,
      words,
      sentences: sentences.length,
      averageWordsPerSentence: words / sentences.length || 0,
      averageCharactersPerWord: charactersNoSpaces / words || 0,
      readabilityScore: this.calculateReadabilityScore(sentences, words, charactersNoSpaces)
    };
  }

  /**
   * Calcular puntuación básica de legibilidad
   */
  calculateReadabilityScore(sentences, words, characters) {
    if (sentences === 0 || words === 0) return 0;
    
    const avgWordsPerSentence = words / sentences;
    const avgSyllablesPerWord = characters / words; // Aproximación simple
    
    // Fórmula simplificada inspirada en Flesch
    const score = 206.835 - (1.015 * avgWordsPerSentence) - (84.6 * avgSyllablesPerWord);
    
    return Math.max(0, Math.min(100, score));
  }

  /**
   * Limpiar cache y datos temporales
   */
  cleanup() {
    // Implementar limpieza si se agrega cache interno
    console.log('🧹 NLP Utils: Cache limpiado');
  }

  /**
   * Obtener configuración actual
   */
  getConfiguration() {
    return {
      stopWordsCount: this.stopWords.size,
      accentMappings: Object.keys(this.accentMap).length,
      contractions: Object.keys(this.contractions).length,
      slangMappings: Object.keys(this.slangMap).length,
      spellCorrections: Object.keys(this.spellCorrections).length,
      emojiMappings: Object.keys(this.emojiMap).length
    };
  }
}