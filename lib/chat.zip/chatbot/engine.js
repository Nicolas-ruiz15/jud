// lib/chatbot/engine.js - MOTOR CORREGIDO Y OPTIMIZADO
import { SynonymManager } from './synonyms.js';
import { IntentClassifier } from './intents.js';
import { NLPUtils } from './nlp-utils.js';
import { ResponseGenerator } from './responses.js';
import { query } from '../database';

export class ChatbotEngine {
  constructor() {
    this.synonymManager = new SynonymManager();
    this.intentClassifier = new IntentClassifier();
    this.nlpUtils = new NLPUtils();
    this.responseGenerator = new ResponseGenerator();
    
    // Cache para optimización
    this.cache = new Map();
    this.cacheTimeout = 5 * 60 * 1000; // 5 minutos
    
    // Métricas de rendimiento
    this.metrics = {
      totalMessages: 0,
      averageResponseTime: 0,
      intentAccuracy: 0,
      lastUpdate: Date.now()
    };

    // Estado de inicialización
    this.isInitialized = false;
    this.initializationPromise = null;
  }

  /**
   * Inicialización asíncrona del motor
   */
  async initialize() {
    if (this.isInitialized) {
      return true;
    }

    if (this.initializationPromise) {
      return this.initializationPromise;
    }

    this.initializationPromise = this._performInitialization();
    return this.initializationPromise;
  }

  async _performInitialization() {
    try {
      console.log('🤖 Inicializando Motor de Chatbot...');
      
      // Verificar conexión a base de datos
      await this._checkDatabaseConnection();
      
      // Inicializar componentes en paralelo para mejor rendimiento
      await Promise.all([
        this.synonymManager.initialize(),
        this.intentClassifier.initialize(),
        this._createRequiredTables()
      ]);

      this.isInitialized = true;
      console.log('✅ Motor de Chatbot inicializado correctamente');
      return true;
      
    } catch (error) {
      console.error('❌ Error inicializando motor:', error);
      this.isInitialized = false;
      throw error;
    }
  }

  /**
   * Verificar conexión a base de datos
   */
  async _checkDatabaseConnection() {
    try {
      await query('SELECT 1');
      console.log('✅ Conexión a base de datos verificada');
    } catch (error) {
      console.error('❌ Error de conexión a base de datos:', error);
      throw new Error('Base de datos no disponible');
    }
  }

  /**
   * Crear tablas requeridas si no existen
   */
  async _createRequiredTables() {
    const tables = [
      {
        name: 'chat_conversation_context',
        sql: `
          CREATE TABLE IF NOT EXISTS chat_conversation_context (
            id INT AUTO_INCREMENT PRIMARY KEY,
            conversation_id INT NOT NULL,
            session_id VARCHAR(255) NOT NULL,
            current_intent VARCHAR(100),
            intent_history JSON,
            conversation_stage VARCHAR(50) DEFAULT 'initial',
            products_mentioned JSON,
            user_preferences JSON,
            escalation_requested BOOLEAN DEFAULT FALSE,
            admin_takeover BOOLEAN DEFAULT FALSE,
            ai_suggestions_enabled BOOLEAN DEFAULT TRUE,
            metadata JSON,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_conversation_id (conversation_id),
            INDEX idx_session_id (session_id)
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        `
      },
      {
        name: 'chat_performance_metrics',
        sql: `
          CREATE TABLE IF NOT EXISTS chat_performance_metrics (
            id INT AUTO_INCREMENT PRIMARY KEY,
            conversation_id INT,
            session_id VARCHAR(255),
            intent_type VARCHAR(100),
            confidence_score DECIMAL(3,2),
            processing_time_ms INT,
            has_products BOOLEAN DEFAULT FALSE,
            requires_human BOOLEAN DEFAULT FALSE,
            request_id VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_conversation_id (conversation_id),
            INDEX idx_session_id (session_id),
            INDEX idx_intent_type (intent_type),
            INDEX idx_created_at (created_at)
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        `
      },
      {
        name: 'product_synonyms',
        sql: `
          CREATE TABLE IF NOT EXISTS product_synonyms (
            id INT AUTO_INCREMENT PRIMARY KEY,
            base_term VARCHAR(255) NOT NULL,
            synonym VARCHAR(255) NOT NULL,
            language VARCHAR(10) DEFAULT 'es',
            context VARCHAR(100),
            priority INT DEFAULT 5,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY unique_synonym (base_term, synonym),
            INDEX idx_base_term (base_term),
            INDEX idx_synonym (synonym),
            INDEX idx_is_active (is_active)
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        `
      },
      {
        name: 'chatbot_intents',
        sql: `
          CREATE TABLE IF NOT EXISTS chatbot_intents (
            id INT AUTO_INCREMENT PRIMARY KEY,
            intent_name VARCHAR(100) NOT NULL UNIQUE,
            intent_description TEXT,
            pattern_text TEXT,
            keywords TEXT,
            confidence_threshold DECIMAL(3,2) DEFAULT 0.80,
            priority VARCHAR(20) DEFAULT 'medium',
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_intent_name (intent_name),
            INDEX idx_is_active (is_active)
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        `
      }
    ];

    for (const table of tables) {
      try {
        await query(table.sql);
        console.log(`✅ Tabla ${table.name} verificada/creada`);
      } catch (error) {
        console.warn(`⚠️ Error creando tabla ${table.name}:`, error.message);
      }
    }
  }

  /**
   * Procesar mensaje principal - CORREGIDO
   */
  async processMessage(message, conversationId, sessionId, userContext = {}) {
    const startTime = Date.now();
    
    try {
      // Asegurar que el motor esté inicializado
      await this.initialize();
      
      console.log('🤖 Procesando mensaje:', {
        message: message.substring(0, 50) + '...',
        conversationId,
        sessionId: sessionId?.substring(0, 10) + '...'
      });

      // Validaciones básicas
      if (!message || typeof message !== 'string') {
        throw new Error('Mensaje inválido');
      }

      if (!sessionId) {
        throw new Error('Session ID requerido');
      }

      // 1. Normalizar y limpiar texto
      const normalizedMessage = this.nlpUtils.normalizeText(message);
      console.log('📝 Texto normalizado:', normalizedMessage);

      // 2. Expandir sinónimos
      const expandedMessage = await this.synonymManager.expandSynonyms(normalizedMessage);
      console.log('🔄 Sinónimos expandidos:', expandedMessage);

      // 3. Clasificar intención
      const intent = await this.intentClassifier.classify(expandedMessage, userContext);
      console.log('🎯 Intención clasificada:', {
        type: intent.type,
        confidence: intent.confidence.toFixed(2),
        entities: intent.entities
      });

      // 4. Obtener contexto de conversación
      const conversationContext = await this.getConversationContext(conversationId);

      // 5. Buscar productos si es necesario
      let searchResults = [];
      if (this.needsProductSearch(intent)) {
        searchResults = await this.searchProducts(intent.entities, intent.filters);
        console.log('🔍 Productos encontrados:', searchResults.length);
      }

      // 6. Generar respuesta
      const response = await this.responseGenerator.generate({
        intent,
        searchResults,
        conversationContext,
        userContext,
        originalMessage: message
      });

      // 7. Actualizar contexto de conversación
      await this.updateConversationContext(conversationId, {
        lastIntent: intent.type,
        lastEntities: intent.entities,
        productsShown: searchResults.map(p => p.id),
        conversationStage: this.determineConversationStage(intent.type, conversationContext)
      });

      // 8. Registrar métricas
      const processingTime = Date.now() - startTime;
      await this.recordMetrics(conversationId, {
        intent: intent.type,
        confidence: intent.confidence,
        processingTime,
        hasProducts: searchResults.length > 0,
        requiresHuman: response.requiresHuman,
        sessionId
      });

      console.log(`✅ Procesamiento completado en ${processingTime}ms`);

      return {
        success: true,
        response: response.text,
        intent: intent.type,
        confidence: intent.confidence,
        requiresHuman: response.requiresHuman || false,
        suggestions: response.suggestions || [],
        products: searchResults,
        followUpQuestions: response.followUpQuestions || [],
        metadata: {
          processingTime,
          version: 'professional-v1.0-fixed',
          engine: 'modular-chatbot'
        }
      };

    } catch (error) {
      console.error('❌ Error en motor principal:', error);
      return this.generateErrorResponse(error, conversationId, sessionId);
    }
  }

  /**
   * Buscar productos basado en entidades e intención - CORREGIDO
   */
  async searchProducts(entities, filters = {}) {
    try {
      const cacheKey = `search_${JSON.stringify({ entities, filters })}`;
      
      // Verificar cache
      if (this.cache.has(cacheKey)) {
        const cached = this.cache.get(cacheKey);
        if (Date.now() - cached.timestamp < this.cacheTimeout) {
          console.log('📋 Usando búsqueda desde cache');
          return cached.data;
        }
      }

      // Verificar si la tabla products existe
      const tablesResult = await query("SHOW TABLES LIKE 'products'");
      if (tablesResult.length === 0) {
        console.warn('⚠️ Tabla products no existe, usando productos de fallback');
        return this.getFallbackProducts();
      }

      let queryParts = [];
      let params = [];
      
      // Construir query base con manejo de errores
      let baseQuery = `
        SELECT 
          p.id,
          p.name,
          p.slug,
          p.description,
          p.short_description,
          p.price,
          p.sale_price,
          p.sku,
          COALESCE(p.stock_quantity, 0) as stock_quantity,
          COALESCE(p.stock_status, 'in_stock') as stock_status,
          COALESCE(p.featured, 0) as featured,
          p.category_id,
          COALESCE(c.name, 'Sin categoría') as category_name,
          CASE 
            WHEN p.sale_price IS NOT NULL AND p.sale_price > 0 
            THEN p.sale_price 
            ELSE p.price 
          END as display_price,
          CASE 
            WHEN COALESCE(p.stock_status, 'in_stock') = 'in_stock' AND COALESCE(p.stock_quantity, 0) > 0
            THEN 1 
            ELSE 0 
          END as available,
          -- Calcular relevancia
          (
            CASE WHEN COALESCE(p.featured, 0) = 1 THEN 10 ELSE 0 END +
            CASE WHEN COALESCE(p.stock_status, 'in_stock') = 'in_stock' THEN 5 ELSE 0 END +
            CASE WHEN p.sale_price IS NOT NULL THEN 3 ELSE 0 END
          ) as relevance_score
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE COALESCE(p.status, 'active') = 'active'
      `;

      // Agregar filtros por productos específicos
      if (entities.products && entities.products.length > 0) {
        const productConditions = [];
        
        for (const product of entities.products) {
          // Buscar sinónimos del producto
          const synonyms = await this.synonymManager.getProductSynonyms(product);
          
          const productTerms = [];
          const productParams = [];
          
          synonyms.forEach(synonym => {
            productTerms.push(`(
              LOWER(COALESCE(p.name, '')) LIKE ? OR 
              LOWER(COALESCE(p.description, '')) LIKE ? OR
              LOWER(COALESCE(p.short_description, '')) LIKE ?
            )`);
            const searchTerm = `%${synonym.toLowerCase()}%`;
            productParams.push(searchTerm, searchTerm, searchTerm);
          });
          
          if (productTerms.length > 0) {
            productConditions.push(`(${productTerms.join(' OR ')})`);
            params.push(...productParams);
          }
        }
        
        if (productConditions.length > 0) {
          queryParts.push(`(${productConditions.join(' OR ')})`);
        }
      }

      // Agregar filtros adicionales
      if (filters.onlyAvailable) {
        queryParts.push(`COALESCE(p.stock_status, 'in_stock') = 'in_stock'`);
      }

      if (filters.featured) {
        queryParts.push(`COALESCE(p.featured, 0) = 1`);
      }

      // Construir query final
      if (queryParts.length > 0) {
        baseQuery += ` AND (${queryParts.join(' AND ')})`;
      }

      baseQuery += `
        ORDER BY 
          relevance_score DESC,
          COALESCE(p.featured, 0) DESC,
          available DESC,
          p.created_at DESC
        LIMIT ${Math.min(parseInt(filters.limit) || 10, 20)}
      `;

      console.log('🔍 Ejecutando búsqueda:', {
        params: params.slice(0, 5),
        totalParams: params.length
      });

      const results = await query(baseQuery, params);

      // Guardar en cache
      this.cache.set(cacheKey, {
        data: results,
        timestamp: Date.now()
      });

      return results;

    } catch (error) {
      console.error('❌ Error en búsqueda de productos:', error);
      return this.getFallbackProducts();
    }
  }

  /**
   * Obtener productos de fallback - CORREGIDO
   */
  async getFallbackProducts() {
    try {
      // Productos estáticos de ejemplo si la tabla no existe
      const fallbackProducts = [
        {
          id: 1,
          name: 'Tefilín de Cuero Premium',
          price: 450000,
          sale_price: null,
          display_price: 450000,
          stock_status: 'in_stock',
          available: 1,
          category_name: 'Artículos Religiosos',
          slug: 'tefilin-cuero-premium'
        },
        {
          id: 2,
          name: 'Tallit de Lana Tradicional',
          price: 180000,
          sale_price: 150000,
          display_price: 150000,
          stock_status: 'in_stock',
          available: 1,
          category_name: 'Artículos Religiosos',
          slug: 'tallit-lana-tradicional'
        },
        {
          id: 3,
          name: 'Mezuzah Decorativa de Plata',
          price: 95000,
          sale_price: null,
          display_price: 95000,
          stock_status: 'in_stock',
          available: 1,
          category_name: 'Decoración',
          slug: 'mezuzah-decorativa-plata'
        },
        {
          id: 4,
          name: 'Sidur Completo Español-Hebreo',
          price: 75000,
          sale_price: null,
          display_price: 75000,
          stock_status: 'in_stock',
          available: 1,
          category_name: 'Libros',
          slug: 'sidur-completo-espanol-hebreo'
        },
        {
          id: 5,
          name: 'Kipá Bordada Azul',
          price: 25000,
          sale_price: null,
          display_price: 25000,
          stock_status: 'in_stock',
          available: 1,
          category_name: 'Accesorios',
          slug: 'kipa-bordada-azul'
        }
      ];

      return fallbackProducts;
      
    } catch (error) {
      console.error('❌ Error crítico en fallback:', error);
      return [];
    }
  }

  /**
   * Obtener contexto de conversación - CORREGIDO
   */
  async getConversationContext(conversationId) {
    try {
      if (!conversationId) {
        return this.getDefaultContext();
      }

      const [context] = await query(`
        SELECT * FROM chat_conversation_context 
        WHERE conversation_id = ? 
        ORDER BY updated_at DESC 
        LIMIT 1
      `, [conversationId]);

      if (context) {
        return {
          ...context,
          intent_history: this.safeJsonParse(context.intent_history, []),
          products_mentioned: this.safeJsonParse(context.products_mentioned, []),
          user_preferences: this.safeJsonParse(context.user_preferences, {}),
          metadata: this.safeJsonParse(context.metadata, {})
        };
      }

      return this.getDefaultContext(conversationId);

    } catch (error) {
      console.error('❌ Error obteniendo contexto:', error);
      return this.getDefaultContext(conversationId);
    }
  }

  /**
   * Obtener contexto por defecto
   */
  getDefaultContext(conversationId = null) {
    return {
      conversation_id: conversationId,
      intent_history: [],
      products_mentioned: [],
      user_preferences: {},
      conversation_stage: 'initial',
      metadata: {}
    };
  }

  /**
   * Parse JSON seguro
   */
  safeJsonParse(jsonString, defaultValue = null) {
    try {
      return jsonString ? JSON.parse(jsonString) : defaultValue;
    } catch (error) {
      console.warn('⚠️ Error parsing JSON:', error.message);
      return defaultValue;
    }
  }

  /**
   * Actualizar contexto de conversación - CORREGIDO
   */
  async updateConversationContext(conversationId, updates) {
    try {
      if (!conversationId) {
        console.warn('⚠️ No se puede actualizar contexto sin conversation_id');
        return;
      }

      const currentContext = await this.getConversationContext(conversationId);
      
      // Merge de datos
      const updatedContext = {
        ...currentContext,
        ...updates,
        intent_history: [
          ...currentContext.intent_history.slice(-9), // Mantener últimos 10
          updates.lastIntent
        ].filter(Boolean),
        updated_at: new Date()
      };

      await query(`
        INSERT INTO chat_conversation_context 
        (conversation_id, current_intent, intent_history, products_mentioned, 
         conversation_stage, user_preferences, metadata, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
          current_intent = VALUES(current_intent),
          intent_history = VALUES(intent_history),
          products_mentioned = VALUES(products_mentioned),
          conversation_stage = VALUES(conversation_stage),
          user_preferences = VALUES(user_preferences),
          metadata = VALUES(metadata),
          updated_at = NOW()
      `, [
        conversationId,
        updates.lastIntent || 'unknown',
        JSON.stringify(updatedContext.intent_history),
        JSON.stringify(updates.productsShown || []),
        updates.conversationStage || 'active',
        JSON.stringify(updatedContext.user_preferences),
        JSON.stringify(updatedContext.metadata)
      ]);

    } catch (error) {
      console.error('❌ Error actualizando contexto:', error);
    }
  }

  /**
   * Registrar métricas de rendimiento - CORREGIDO
   */
  async recordMetrics(conversationId, metrics) {
    try {
      await query(`
        INSERT INTO chat_performance_metrics 
        (conversation_id, session_id, intent_type, confidence_score, processing_time_ms,
         has_products, requires_human, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
      `, [
        conversationId,
        metrics.sessionId || null,
        metrics.intent || 'unknown',
        Math.min(Math.max(metrics.confidence || 0, 0), 1), // Asegurar rango 0-1
        metrics.processingTime || 0,
        metrics.hasProducts ? 1 : 0,
        metrics.requiresHuman ? 1 : 0
      ]);

      // Actualizar métricas globales
      this.metrics.totalMessages++;
      this.metrics.averageResponseTime = 
        (this.metrics.averageResponseTime + (metrics.processingTime || 0)) / 2;

    } catch (error) {
      console.error('❌ Error registrando métricas:', error);
    }
  }

  /**
   * Generar respuesta de error - CORREGIDO
   */
  generateErrorResponse(error, conversationId, sessionId = null) {
    console.error('🚨 Generando respuesta de error:', error.message);

    return {
      success: false,
      response: `Disculpa, tuve un problema técnico temporal. 

🔧 **Mientras tanto puedes:**
📱 [WhatsApp directo](https://wa.me/573009291156?text=Hola!%20Necesito%20ayuda)
🌐 [Ver tienda online](https://judaicabreslovcolombia.com)
📧 contacto@judaicabreslovcolombia.com

¿Podrías intentar reformular tu pregunta?`,
      intent: 'error',
      confidence: 0,
      requiresHuman: true,
      suggestions: ['Contactar WhatsApp', 'Ver productos', 'Intentar de nuevo'],
      products: [],
      metadata: {
        error: true,
        processingTime: 0,
        version: 'error-fallback'
      },
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    };
  }

  /**
   * Determinar si necesita búsqueda de productos
   */
  needsProductSearch(intent) {
    const searchIntents = [
      'product_search',
      'price_inquiry',
      'availability_check',
      'product_comparison',
      'category_browse'
    ];
    
    return searchIntents.includes(intent.type) || 
           intent.entities.products?.length > 0 ||
           intent.entities.categories?.length > 0;
  }

  /**
   * Determinar etapa de conversación
   */
  determineConversationStage(intentType, context) {
    const stageMap = {
      'greeting': 'initial',
      'product_search': 'browsing',
      'category_browse': 'browsing', 
      'price_inquiry': 'evaluation',
      'availability_check': 'evaluation',
      'product_comparison': 'evaluation',
      'purchase_intent': 'purchase',
      'shipping_inquiry': 'purchase_details',
      'payment_inquiry': 'purchase_details',
      'contact_request': 'support',
      'complaint': 'support',
      'thanks': 'closing'
    };

    return stageMap[intentType] || context.conversation_stage || 'general';
  }

  /**
   * Obtener estadísticas del motor
   */
  getEngineStats() {
    return {
      ...this.metrics,
      cacheSize: this.cache.size,
      uptime: Date.now() - this.metrics.lastUpdate,
      isInitialized: this.isInitialized
    };
  }

  /**
   * Limpiar cache
   */
  clearCache() {
    this.cache.clear();
    console.log('🧹 Cache limpiado');
  }

  /**
   * Método para warm-up del sistema - CORREGIDO
   */
  async warmUp() {
    console.log('🔥 Iniciando warm-up del chatbot...');
    
    try {
      // Inicializar si no está inicializado
      await this.initialize();
      
      // Pre-cargar sinónimos más comunes
      await this.synonymManager.preloadCommonSynonyms();
      
      // Pre-cargar intents más utilizados
      await this.intentClassifier.preloadIntents();
      
      // Pre-cargar productos destacados
      await this.getFallbackProducts();
      
      console.log('✅ Warm-up completado');
      return true;
    } catch (error) {
      console.error('❌ Error en warm-up:', error);
      return false;
    }
  }
}

// Función de conveniencia para uso externo - CORREGIDA
export async function processUserMessage(message, conversationId, sessionId, userContext = {}) {
  try {
    const engine = new ChatbotEngine();
    await engine.initialize();
    return engine.processMessage(message, conversationId, sessionId, userContext);
  } catch (error) {
    console.error('❌ Error en processUserMessage:', error);
    return {
      success: false,
      response: 'Error del sistema. Por favor, contacta por WhatsApp: +57 300 929 1156',
      intent: 'error',
      confidence: 0,
      requiresHuman: true,
      suggestions: ['Contactar WhatsApp'],
      products: [],
      error: error.message
    };
  }
}