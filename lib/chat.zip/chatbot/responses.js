// lib/chatbot/responses.js - GENERADOR PROFESIONAL DE RESPUESTAS
import { query } from '../database';

export class ResponseGenerator {
  constructor() {
    // Templates de respuestas organizados por intención
    this.responseTemplates = {
      // SALUDOS Y CORTESÍA
      greeting: {
        templates: [
          "¡Shalom! 🌟 Bienvenido a **Judaica Breslov Colombia**. Soy tu asistente especializado en productos judaicos kosher. ¿En qué puedo ayudarte hoy?",
          "¡Hola! 👋 Soy tu asistente personal de Judaica Breslov. ¿Buscas algo específico o prefieres explorar nuestro catálogo?",
          "¡Bienvenido! 🕊️ Estoy aquí para ayudarte con todo lo relacionado a productos judaicos auténticos. ¿Qué necesitas?"
        ],
        suggestions: ['Ver productos populares', 'Buscar tefilín', 'Libros judaicos', 'Artículos de Shabat'],
        requiresHuman: false
      },

      farewell: {
        templates: [
          "¡Que tengas un día bendecido! 🙏 Gracias por contactar Judaica Breslov Colombia. Estaremos aquí cuando nos necesites.",
          "¡Shalom! Ha sido un placer ayudarte. No dudes en volver cuando necesites productos judaicos auténticos.",
          "¡Hasta pronto! 👋 Recuerda que siempre puedes contactarnos por WhatsApp: [+57 300 929 1156](https://wa.me/573009291156)"
        ],
        suggestions: ['Ver tienda online', 'Contacto WhatsApp', 'Suscribirse a ofertas'],
        requiresHuman: false
      },

      thanks: {
        templates: [
          "¡Con mucho gusto! 😊 Es un placer ayudarte. ¿Hay algo más en lo que pueda asistirte?",
          "¡De nada! 🌟 Estoy aquí para cualquier consulta sobre productos judaicos. ¿Necesitas algo más?",
          "¡Me alegra haber sido útil! ¿Te gustaría explorar algún producto específico?"
        ],
        suggestions: ['Ver más productos', 'Hacer otra consulta', 'Contactar asesor'],
        requiresHuman: false
      },

      // BÚSQUEDA DE PRODUCTOS
      product_search: {
        single_product: (product) => `
**${product.name}** 🎯

💰 **Precio:** $${new Intl.NumberFormat('es-CO').format(product.display_price)}
${product.sale_price ? `~~$${new Intl.NumberFormat('es-CO').format(product.price)}~~ ¡En oferta!` : ''}
📦 **Disponibilidad:** ${product.available ? '✅ En stock' : '⚠️ Consultar disponibilidad'}

${product.short_description ? `📝 ${product.short_description.substring(0, 150)}...` : ''}

**¿Qué te gustaría saber?**
🔗 [Ver en tienda](https://judaicabreslovcolombia.com/producto/${product.slug})
📱 [Comprar por WhatsApp](https://wa.me/573009291156?text=Hola!%20Me%20interesa%20${encodeURIComponent(product.name)})
        `,
        
        multiple_products: (products) => {
          let response = `Encontré ${products.length} productos que pueden interesarte:\n\n`;
          
          products.slice(0, 5).forEach((product, index) => {
            const price = new Intl.NumberFormat('es-CO').format(product.display_price);
            const status = product.available ? '✅' : '⚠️';
            
            response += `**${index + 1}. ${product.name}**\n`;
            response += `   💰 $${price} ${status}\n`;
            response += `   🔗 [Ver detalles](https://judaicabreslovcolombia.com/producto/${product.slug})\n\n`;
          });

          response += `\n💡 Escribe el número del producto para más detalles, o dime si buscas algo más específico.`;
          return response;
        },

        no_products: (searchTerm) => `
No encontré productos específicos para "${searchTerm}". 

**Pero puedo ayudarte con:**
• 📚 **Libros judaicos** - Sidurim, Jumashim, Tehilim, Zohar
• 🕊️ **Tefilín y Tallitot** - Auténticos y kosher
• 🏠 **Mezuzot** - Artesanales y decorativas  
• 🕯️ **Artículos de Shabat** - Velas, copas, especieros
• 💎 **Joyería judaica** - Cadenas, anillos, colgantes
• 👑 **Kipot** - Variedad de diseños y materiales

¿Qué categoría te interesa? O puedes ser más específico con el nombre del producto.
        `,

        suggestions: ['Ver más detalles', 'Comparar productos', 'Consultar precio', 'Verificar stock'],
        requiresHuman: false
      },

      // CONSULTAS DE PRECIO
      price_inquiry: {
        single_product: (product) => `
💰 **Precio de ${product.name}:**

**Precio actual:** $${new Intl.NumberFormat('es-CO').format(product.display_price)}
${product.sale_price ? `**Precio original:** ~~$${new Intl.NumberFormat('es-CO').format(product.price)}~~\n**¡Ahorro:** $${new Intl.NumberFormat('es-CO').format(product.price - product.sale_price)} (${Math.round((1 - product.sale_price/product.price) * 100)}% descuento)` : ''}

📦 **Estado:** ${product.available ? '✅ Disponible para envío inmediato' : '⏳ Consultar tiempo de entrega'}

**¿Te gustaría comprarlo?**
🛒 [Agregar al carrito](https://judaicabreslovcolombia.com/producto/${product.slug})
📱 [Comprar por WhatsApp](https://wa.me/573009291156?text=Hola!%20Quiero%20comprar%20${encodeURIComponent(product.name)})
        `,

        suggestions: ['Comprar ahora', 'Ver productos similares', 'Consultar financiación', 'Hablar con asesor'],
        requiresHuman: false
      },

      // DISPONIBILIDAD
      availability_check: {
        template: () => `
📦 **Verificando disponibilidad...**

Te ayudo a consultar el stock de productos. ¿Qué producto específico necesitas?

**Información general:**
✅ **Productos en stock** - Envío inmediato
⏳ **Por encargo** - 3-5 días hábiles  
📱 **Consulta directa** - WhatsApp para casos especiales

¿Cuál producto te interesa?
        `,
        suggestions: ['Ver disponibles', 'Hacer pedido', 'Notificarme', 'Contactar asesor'],
        requiresHuman: false
      },

      // PROCESO DE COMPRA
      purchase_intent: {
        template: () => `
🛒 **¿Cómo realizar tu compra?**

**Opción 1 - Tienda Online:**
🌐 [judaicabreslovcolombia.com](https://judaicabreslovcolombia.com)
• Proceso seguro y rápido
• Múltiples métodos de pago

**Opción 2 - WhatsApp Directo:**
📱 [Chat con asesor](https://wa.me/573009291156?text=Hola!%20Quiero%20hacer%20una%20compra)
• Atención personalizada
• Asesoría especializada

**Métodos de pago:**
💳 Tarjetas crédito/débito
🏛️ PSE (Débito inmediato)
🏪 Efecty y corresponsales

¿Prefieres comprar online o necesitas asesoría?
        `,
        suggestions: ['Comprar online', 'WhatsApp', 'Ver métodos pago', 'Calcular envío'],
        requiresHuman: false
      },

      // ENVÍOS
      shipping_inquiry: {
        template: () => `
🚚 **Información de envíos:**

**📍 Cobertura Nacional**

**🏙️ Bogotá:**
• Costo: $15,000
• Tiempo: 1-2 días hábiles

**🇨🇴 Nacional:**
• Costo: $18,000  
• Tiempo: 2-4 días hábiles

**⚡ Express disponible:**
• +$10,000 adicional
• Entrega en 24 horas

**🆓 Envío GRATIS:**
• Compras superiores a $300,000

¿A qué ciudad necesitas el envío?
        `,
        suggestions: ['Calcular envío', 'Ver políticas', 'Rastrear pedido', 'Express'],
        requiresHuman: false
      },

      // CONTACTO
      contact_request: {
        template: () => `
📞 **Contacto directo:**

**📱 WhatsApp:**
[+57 300 929 1156](https://wa.me/573009291156)
• Respuesta inmediata
• Asesoría personalizada

**📧 Email:**
contacto@judaicabreslovcolombia.com

**🕐 Horarios:**
• **Lun-Vie:** 8:00 AM - 6:00 PM
• **Sábados:** 8:00 AM - 2:00 PM  
• **Domingos:** Cerrado

¿Prefieres que te contacte un asesor?
        `,
        suggestions: ['WhatsApp ahora', 'Programar llamada', 'Enviar email', 'Ver ubicación'],
        requiresHuman: true
      },

      // INFORMACIÓN RELIGIOSA
      kashrut_inquiry: {
        template: () => `
✡️ **Certificación Kosher:**

**🏛️ Supervisión rabínica:**
• Certificados auténticos
• Importación directa de Israel
• Comunidad Breslov Colombia

**📜 Productos certificados:**
✅ Tefilín - Sofer auténtico
✅ Mezuzot - Pergaminos kosher
✅ Tallitot - Tzitzit según halajá
✅ Libros - Ediciones autorizadas

¿Necesitas ver algún certificado específico?
        `,
        suggestions: ['Ver certificados', 'Consultar rabino', 'Productos kosher', 'Más información'],
        requiresHuman: false
      },

      // RESPUESTA DESCONOCIDA
      unknown: {
        template: () => `
🤔 No estoy seguro de entender tu consulta.

**Puedo ayudarte con:**
🔍 **Búsqueda de productos**
💰 **Precios y disponibilidad** 
🛒 **Proceso de compra**
📞 **Contacto directo**
✡️ **Orientación religiosa**

**Ejemplos:**
• "Busco tefilín para mi hijo"
• "¿Cuánto cuesta un tallit?"
• "¿Cómo se coloca una mezuzah?"

¿Podrías ser más específico?
        `,
        suggestions: ['Ver productos', 'Hablar con asesor', 'Ver categorías', 'Ayuda'],
        requiresHuman: true
      }
    };

    // Frases de cortesía
    this.courtesyPhrases = {
      opening: [
        '¡Excelente pregunta!',
        'Me da mucho gusto ayudarte.',
        'Por supuesto, te ayudo.',
        'Es un placer asistirte.'
      ],
      closing: [
        '¿Hay algo más en lo que pueda ayudarte?',
        '¿Necesitas información adicional?',
        '¿Hay otra consulta que pueda resolver?'
      ]
    };
  }

  /**
   * Generar respuesta principal
   */
  async generate(context) {
    try {
      const { intent, searchResults, conversationContext, userContext } = context;

      // Seleccionar template apropiado
      const templateData = this.responseTemplates[intent.type] || this.responseTemplates.unknown;

      // Generar contenido específico
      let responseText = await this.generateSpecificResponse(intent, searchResults, templateData);

      // Generar sugerencias
      const suggestions = this.generateSuggestions(intent, searchResults);

      // Determinar si requiere intervención humana
      const requiresHuman = this.shouldRequireHuman(intent, searchResults);

      return {
        text: responseText,
        suggestions,
        requiresHuman,
        metadata: {
          intent: intent.type,
          confidence: intent.confidence,
          hasProducts: searchResults?.length > 0
        }
      };

    } catch (error) {
      console.error('Error generando respuesta:', error);
      return this.generateErrorResponse(error);
    }
  }

  /**
   * Generar respuesta específica según intención
   */
  async generateSpecificResponse(intent, searchResults, templateData) {
    const intentType = intent.type;

    switch (intentType) {
      case 'greeting':
      case 'thanks':
      case 'farewell':
        return this.getRandomTemplate(templateData.templates);

      case 'product_search':
        if (searchResults && searchResults.length > 0) {
          if (searchResults.length === 1) {
            return this.responseTemplates.product_search.single_product(searchResults[0]);
          } else {
            return this.responseTemplates.product_search.multiple_products(searchResults);
          }
        } else {
          const searchTerm = intent.entities?.products?.[0] || 'tu búsqueda';
          return this.responseTemplates.product_search.no_products(searchTerm);
        }

      case 'price_inquiry':
        if (searchResults && searchResults.length > 0) {
          return this.responseTemplates.price_inquiry.single_product(searchResults[0]);
        } else {
          return 'Por favor especifica el producto del cual quieres conocer el precio.';
        }

      case 'availability_check':
        return this.responseTemplates.availability_check.template();

      case 'purchase_intent':
        return this.responseTemplates.purchase_intent.template();

      case 'shipping_inquiry':
        return this.responseTemplates.shipping_inquiry.template();

      case 'contact_request':
        return this.responseTemplates.contact_request.template();

      case 'kashrut_inquiry':
        return this.responseTemplates.kashrut_inquiry.template();

      default:
        return this.responseTemplates.unknown.template();
    }
  }

  /**
   * Obtener template aleatorio
   */
  getRandomTemplate(templates) {
    if (!templates || templates.length === 0) {
      return 'Gracias por tu consulta. ¿En qué más puedo ayudarte?';
    }
    
    const randomIndex = Math.floor(Math.random() * templates.length);
    return templates[randomIndex];
  }

  /**
   * Generar sugerencias contextuales
   */
  generateSuggestions(intent, searchResults) {
    const baseTemplate = this.responseTemplates[intent.type];
    let suggestions = baseTemplate?.suggestions || [];

    if (searchResults && searchResults.length > 0) {
      suggestions = [
        'Ver más detalles',
        'Consultar disponibilidad',
        'Proceso de compra',
        'Productos similares'
      ];
    }

    if (!suggestions.includes('Contactar WhatsApp')) {
      suggestions.push('Contactar WhatsApp');
    }

    return suggestions.slice(0, 4);
  }

  /**
   * Determinar si requiere intervención humana
   */
  shouldRequireHuman(intent, searchResults) {
    const alwaysHuman = ['complaint', 'contact_request'];
    if (alwaysHuman.includes(intent.type)) {
      return true;
    }

    if (intent.confidence < 0.4) {
      return true;
    }

    return false;
  }

  /**
   * Generar respuesta de error
   */
  generateErrorResponse(error) {
    return {
      text: `Disculpa, tuve un problema técnico temporal. 

🔧 **Mientras tanto:**
📱 [WhatsApp directo](https://wa.me/573009291156?text=Hola!%20Necesito%20ayuda)
🌐 [Ver tienda online](https://judaicabreslovcolombia.com)

¿Podrías intentar reformular tu pregunta?`,
      suggestions: ['Contactar WhatsApp', 'Ver productos', 'Intentar de nuevo'],
      requiresHuman: true,
      metadata: {
        error: true,
        errorMessage: error.message
      }
    };
  }

  /**
   * Obtener estadísticas del generador
   */
  getStats() {
    return {
      totalTemplates: Object.keys(this.responseTemplates).length,
      courtesyPhrasesCount: this.courtesyPhrases.opening.length + this.courtesyPhrases.closing.length,
      supportedIntents: Object.keys(this.responseTemplates),
      version: '1.0.0'
    };
  }
}