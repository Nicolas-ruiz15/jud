// lib/chatbot/intents.js - CLASIFICADOR PROFESIONAL DE INTENCIONES
import { query } from '../database';

export class IntentClassifier {
  constructor() {
    // Cache de intenciones
    this.intentCache = new Map();
    this.cacheTimeout = 15 * 60 * 1000; // 15 minutos

    // Definición completa de intenciones con patrones avanzados
    this.intents = {
      // SALUDOS Y CORTESÍA
      greeting: {
        name: 'greeting',
        description: 'Saludos iniciales y presentaciones',
        patterns: [
          /^(hola|hey|hi|hello|buenos?\s*(días?|tardes?|noches?))/i,
          /^(shalom|qué\s+tal|cómo\s+estás?|cómo\s+está)/i,
          /^(saludos|buen\s+día|buenas)/i
        ],
        keywords: ['hola', 'hi', 'hello', 'shalom', 'buenos', 'buenas', 'saludo'],
        confidence: 0.95,
        context: ['inicio', 'presentacion', 'cortesia'],
        priority: 'high'
      },

      farewell: {
        name: 'farewell',
        description: 'Despedidas y cierre de conversación',
        patterns: [
          /(adiós|chau|hasta\s+luego|nos\s+vemos|bye|goodbye)/i,
          /(gracias\s+por\s+todo|muchas\s+gracias|perfecto|excelente)/i,
          /(hasta\s+pronto|que\s+tengas?\s+buen|shalom)/i
        ],
        keywords: ['adiós', 'chau', 'bye', 'hasta', 'nos vemos', 'gracias'],
        confidence: 0.92,
        context: ['cierre', 'despedida', 'finalizacion'],
        priority: 'medium'
      },

      thanks: {
        name: 'thanks',
        description: 'Agradecimientos del usuario',
        patterns: [
          /^(gracias|muchas\s+gracias|te\s+agradezco)/i,
          /^(thanks|thank\s+you|excelente|perfecto)/i,
          /^(muy\s+bien|genial|fantástico)/i
        ],
        keywords: ['gracias', 'thanks', 'agradezco', 'excelente', 'perfecto'],
        confidence: 0.94,
        context: ['agradecimiento', 'satisfaccion'],
        priority: 'medium'
      },

      // BÚSQUEDA Y NAVEGACIÓN DE PRODUCTOS
      product_search: {
        name: 'product_search',
        description: 'Búsqueda específica de productos',
        patterns: [
          /busco\s+(.+)/i,
          /necesito\s+(.+)/i,
          /quiero\s+(ver|comprar)?\s*(.+)/i,
          /tienen\s+(.+)/i,
          /hay\s+(.+)/i,
          /mostrar?\s+(.+)/i,
          /dónde\s+(encuentro|está)\s+(.+)/i
        ],
        keywords: ['busco', 'necesito', 'quiero', 'tienen', 'hay', 'mostrar', 'ver'],
        confidence: 0.90,
        context: ['busqueda', 'producto', 'catalogo'],
        priority: 'high',
        extractEntities: true
      },

      category_browse: {
        name: 'category_browse',
        description: 'Navegación por categorías',
        patterns: [
          /(categorías?|tipos?|clases?)\s+(de\s+)?(.+)/i,
          /(qué|cuáles?)\s+(productos?|artículos?|tipos?)/i,
          /ver\s+(todo|todos?|toda)\s+(.+)/i,
          /explorar\s+(.+)/i
        ],
        keywords: ['categorias', 'tipos', 'clases', 'productos', 'explorar', 'ver todo'],
        confidence: 0.85,
        context: ['navegacion', 'categoria', 'explorar'],
        priority: 'medium'
      },

      product_comparison: {
        name: 'product_comparison',
        description: 'Comparación entre productos',
        patterns: [
          /(diferencia|diferencias)\s+entre\s+(.+)/i,
          /(comparar|vs|versus)\s+(.+)/i,
          /(cuál?\s+es\s+mejor|qué\s+recomienda)/i,
          /(pros\s+y\s+contras|ventajas?\s+y\s+desventajas?)/i
        ],
        keywords: ['diferencia', 'comparar', 'mejor', 'recomienda', 'versus', 'vs'],
        confidence: 0.88,
        context: ['comparacion', 'decision', 'evaluacion'],
        priority: 'medium'
      },

      // PRECIOS E INFORMACIÓN COMERCIAL
      price_inquiry: {
        name: 'price_inquiry',
        description: 'Consultas sobre precios',
        patterns: [
          /cuánto\s+(cuesta|vale|es|sale)/i,
          /precio\s+(de|del|para)\s*(.+)/i,
          /valor\s+(de|del)\s*(.+)/i,
          /\$\s*\d+/,
          /(presupuesto|cotiz)/i,
          /(caro|barato|económico)/i
        ],
        keywords: ['cuanto', 'precio', 'valor', 'cuesta', 'vale', 'presupuesto', 'cotizar'],
        confidence: 0.92,
        context: ['precio', 'costo', 'informacion'],
        priority: 'high'
      },

      availability_check: {
        name: 'availability_check',
        description: 'Consultas sobre disponibilidad y stock',
        patterns: [
          /hay\s+(disponible|stock|existencia)/i,
          /tienen?\s+(en\s+)?stock/i,
          /disponibilidad\s+(de|del)\s*(.+)/i,
          /cuándo\s+(llega|estará\s+disponible)/i,
          /(agotado|sin\s+stock|out\s+of\s+stock)/i,
          /en\s+existencia/i
        ],
        keywords: ['disponible', 'stock', 'existencia', 'agotado', 'cuando llega'],
        confidence: 0.90,
        context: ['disponibilidad', 'inventario', 'stock'],
        priority: 'high'
      },

      discount_inquiry: {
        name: 'discount_inquiry',
        description: 'Consultas sobre descuentos y ofertas',
        patterns: [
          /(descuento|oferta|promoción)/i,
          /(rebaja|liquidación|sale)/i,
          /(cupón|código\s+promocional)/i,
          /hay\s+(alguna\s+)?(oferta|descuento|promoción)/i
        ],
        keywords: ['descuento', 'oferta', 'promocion', 'rebaja', 'cupon', 'codigo'],
        confidence: 0.87,
        context: ['oferta', 'descuento', 'promocion'],
        priority: 'medium'
      },

      // PROCESO DE COMPRA
      purchase_intent: {
        name: 'purchase_intent',
        description: 'Intención de compra',
        patterns: [
          /cómo\s+(compro|comprar)/i,
          /dónde\s+(compro|comprar)/i,
          /quiero\s+comprar/i,
          /proceso\s+de\s+compra/i,
          /(agregar\s+al\s+carrito|añadir\s+al\s+carrito)/i,
          /lo\s+(compro|llevo)/i
        ],
        keywords: ['comprar', 'proceso', 'carrito', 'llevar', 'agregar'],
        confidence: 0.94,
        context: ['compra', 'adquisicion', 'proceso'],
        priority: 'high'
      },

      payment_inquiry: {
        name: 'payment_inquiry',
        description: 'Consultas sobre métodos de pago',
        patterns: [
          /(forma|método|forma)\s+de\s+pago/i,
          /(tarjeta|efectivo|transferencia|pse)/i,
          /cómo\s+(pago|puedo\s+pagar)/i,
          /(aceptan|reciben)\s+(.+)/i,
          /cuotas?\s+(sin\s+interés|con\s+tarjeta)/i
        ],
        keywords: ['pago', 'tarjeta', 'efectivo', 'transferencia', 'pse', 'cuotas'],
        confidence: 0.91,
        context: ['pago', 'metodo', 'financiacion'],
        priority: 'high'
      },

      // ENVÍOS Y LOGÍSTICA
      shipping_inquiry: {
        name: 'shipping_inquiry',
        description: 'Consultas sobre envíos y entregas',
        patterns: [
          /envío?s?\s*(a|hasta|nacional|local)?/i,
          /entrega\s*(a\s+domicilio|express|rápida)?/i,
          /(delivery|shipping)/i,
          /cuánto\s+tarda\s+(el\s+)?envío/i,
          /tiempo\s+de\s+entrega/i,
          /(transportadora|mensajería)/i,
          /envían\s+a\s+(.+)/i
        ],
        keywords: ['envio', 'entrega', 'delivery', 'transportadora', 'tarda', 'tiempo'],
        confidence: 0.90,
        context: ['envio', 'logistica', 'entrega'],
        priority: 'high'
      },

      shipping_tracking: {
        name: 'shipping_tracking',
        description: 'Rastreo de envíos',
        patterns: [
          /(rastrear|seguimiento|tracking)/i,
          /dónde\s+(está|va)\s+(mi\s+)?pedido/i,
          /número\s+de\s+seguimiento/i,
          /estado\s+(del\s+)?envío/i
        ],
        keywords: ['rastrear', 'seguimiento', 'tracking', 'pedido', 'estado'],
        confidence: 0.93,
        context: ['seguimiento', 'rastreo', 'estado'],
        priority: 'medium'
      },

      // SOPORTE Y CONTACTO
      contact_request: {
        name: 'contact_request',
        description: 'Solicitudes de contacto directo',
        patterns: [
          /(contacto|contactar)/i,
          /(whatsapp|teléfono|llamar)/i,
          /hablar\s+con\s+(alguien|asesor|vendedor)/i,
          /(asesor|especialista|ayuda\s+personalizada)/i,
          /número\s+de\s+(teléfono|whatsapp)/i
        ],
        keywords: ['contacto', 'whatsapp', 'telefono', 'asesor', 'hablar', 'llamar'],
        confidence: 0.93,
        context: ['contacto', 'soporte', 'asesor'],
        priority: 'high'
      },

      complaint: {
        name: 'complaint',
        description: 'Quejas y problemas',
        patterns: [
          /(queja|reclamo|problema)/i,
          /(malo|defectuoso|roto|dañado)/i,
          /no\s+(funciona|sirve|llegó)/i,
          /(devolver|cambio|garantía)/i,
          /(insatisfecho|molesto|enojado)/i
        ],
        keywords: ['queja', 'reclamo', 'problema', 'malo', 'devolver', 'garantia'],
        confidence: 0.89,
        context: ['problema', 'queja', 'soporte'],
        priority: 'high'
      },

      technical_support: {
        name: 'technical_support',
        description: 'Soporte técnico del sitio web',
        patterns: [
          /(no\s+funciona|error|problema)\s+(página|web|sitio)/i,
          /no\s+(puedo|logro)\s+(entrar|acceder|cargar)/i,
          /(lento|se\s+cuelga|no\s+carga)/i,
          /problema\s+(técnico|sistema)/i
        ],
        keywords: ['error', 'problema', 'no funciona', 'lento', 'tecnico', 'sistema'],
        confidence: 0.86,
        context: ['tecnico', 'web', 'sistema'],
        priority: 'medium'
      },

      // INFORMACIÓN GENERAL
      business_hours: {
        name: 'business_hours',
        description: 'Consultas sobre horarios',
        patterns: [
          /(horario|hora)s?\s+(de\s+)?(atención|servicio)/i,
          /a\s+qué\s+hora\s+(abren|cierran)/i,
          /(abierto|cerrado)\s+(hoy|mañana)/i,
          /cuándo\s+(atienden|están\s+disponibles)/i
        ],
        keywords: ['horarios', 'atencion', 'abren', 'cierran', 'abierto', 'disponible'],
        confidence: 0.91,
        context: ['horarios', 'atencion', 'disponibilidad'],
        priority: 'medium'
      },

      location_inquiry: {
        name: 'location_inquiry',
        description: 'Consultas sobre ubicación',
        patterns: [
          /dónde\s+(están|quedan|ubicados)/i,
          /(dirección|ubicación|sede)/i,
          /cómo\s+(llegar|llego)/i,
          /(tienda\s+física|local|establecimiento)/i
        ],
        keywords: ['donde', 'direccion', 'ubicacion', 'llegar', 'tienda', 'local'],
        confidence: 0.88,
        context: ['ubicacion', 'direccion', 'local'],
        priority: 'medium'
      },

      // INFORMACIÓN ESPECÍFICA DE PRODUCTOS JUDAICOS
      kashrut_inquiry: {
        name: 'kashrut_inquiry',
        description: 'Consultas sobre certificación kosher',
        patterns: [
          /(kosher|kasher|kashrut)/i,
          /(certificación|supervisión)\s+(rabínica|kosher)/i,
          /es\s+(kosher|kasher)/i,
          /(halál|permitido|prohibido)/i
        ],
        keywords: ['kosher', 'kasher', 'certificacion', 'rabinica', 'supervision'],
        confidence: 0.92,
        context: ['kashrut', 'certificacion', 'religion'],
        priority: 'high'
      },

      religious_guidance: {
        name: 'religious_guidance',
        description: 'Orientación religiosa sobre productos',
        patterns: [
          /cómo\s+(usar|utilizar|colocar)\s+(.+)/i,
          /(bendición|bracha|rezo)\s+(para|de)\s+(.+)/i,
          /(tradición|costumbre|halajá)/i,
          /qué\s+(significa|representa)\s+(.+)/i
        ],
        keywords: ['usar', 'bendicion', 'bracha', 'tradicion', 'costumbre', 'halaja'],
        confidence: 0.87,
        context: ['religion', 'tradicion', 'uso'],
        priority: 'high'
      },

      // INTENCIONES AVANZADAS
      recommendation_request: {
        name: 'recommendation_request',
        description: 'Solicitudes de recomendaciones',
        patterns: [
          /(recomienda|recomendación|sugerencia)/i,
          /qué\s+(es\s+)?mejor\s+(para|de)\s*(.+)/i,
          /cuál\s+(elijo|escojo|conviene)/i,
          /(consejo|opinión)\s+(sobre|de)\s*(.+)/i
        ],
        keywords: ['recomienda', 'mejor', 'elijo', 'consejo', 'opinion', 'sugerencia'],
        confidence: 0.85,
        context: ['recomendacion', 'consejo', 'decision'],
        priority: 'medium'
      },

      gift_inquiry: {
        name: 'gift_inquiry',
        description: 'Consultas sobre regalos',
        patterns: [
          /(regalo|obsequio|presente)/i,
          /(bar\s+mitzvah|bat\s+mitzvah|boda)/i,
          /para\s+(regalar|obsequiar)/i,
          /(cumpleaños|aniversario|celebración)/i
        ],
        keywords: ['regalo', 'presente', 'bar mitzvah', 'boda', 'cumpleanos'],
        confidence: 0.89,
        context: ['regalo', 'celebracion', 'ocasion'],
        priority: 'medium'
      },

      // INTENCIONES DE CONTEXTO
      affirmation: {
        name: 'affirmation',
        description: 'Confirmaciones y respuestas afirmativas',
        patterns: [
          /^(sí|si|yes|ok|okay|dale|perfecto)/i,
          /^(exacto|correcto|así\s+es|claro)/i,
          /^(por\s+supuesto|desde\s+luego)/i
        ],
        keywords: ['si', 'yes', 'ok', 'perfecto', 'exacto', 'correcto'],
        confidence: 0.95,
        context: ['confirmacion', 'afirmacion'],
        priority: 'high'
      },

      negation: {
        name: 'negation',
        description: 'Negaciones y respuestas negativas',
        patterns: [
          /^(no|nope|para\s+nada|para\s+nada)/i,
          /^(ninguno|ninguna|nada)/i,
          /^(incorrecto|equivocado)/i
        ],
        keywords: ['no', 'nope', 'ninguno', 'nada', 'incorrecto'],
        confidence: 0.94,
        context: ['negacion', 'rechazo'],
        priority: 'high'
      },

      clarification_request: {
        name: 'clarification_request',
        description: 'Solicitudes de aclaración',
        patterns: [
          /(no\s+entiendo|no\s+comprendo)/i,
          /(explica|explícame|aclárame)/i,
          /(qué\s+significa|qué\s+quiere\s+decir)/i,
          /(puedes\s+repetir|repite)/i
        ],
        keywords: ['no entiendo', 'explica', 'significa', 'repetir', 'aclara'],
        confidence: 0.91,
        context: ['aclaracion', 'explicacion'],
        priority: 'medium'
      },

      // INTENCIÓN GENÉRICA (FALLBACK)
      unknown: {
        name: 'unknown',
        description: 'Intención no identificada',
        patterns: [],
        keywords: [],
        confidence: 0.10,
        context: ['desconocido', 'generico'],
        priority: 'low'
      }
    };

    // Patrones especiales para extracción de entidades
    this.entityPatterns = {
      product: /(?:busco|necesito|quiero|hay|tienen)\s+(.+?)(?:\s+(?:por favor|pls|please))?$/i,
      quantity: /(\d+)\s*(unidades?|piezas?|docenas?|pares?)?/i,
      price_range: /entre\s+\$?(\d+(?:,\d{3})*)\s+y\s+\$?(\d+(?:,\d{3})*)/i,
      color: /(blanco|negro|azul|rojo|verde|amarillo|plata|dorado|marrón|café)/i,
      size: /(pequeño|mediano|grande|chico|xl|xxl|s|m|l)/i,
      material: /(lana|seda|algodón|cuero|plata|oro|madera|metal|cristal)/i
    };

    this.initialize();
  }

  /**
   * Inicialización del clasificador
   */
  async initialize() {
    try {
      console.log('🎯 Inicializando Intent Classifier...');
      await this.loadDatabaseIntents();
      console.log('✅ Intent Classifier inicializado');
    } catch (error) {
      console.error('❌ Error inicializando clasificador:', error);
    }
  }

  /**
   * Cargar intenciones adicionales desde la base de datos
   */
  async loadDatabaseIntents() {
    try {
      const dbIntents = await query(`
        SELECT 
          intent_name,
          intent_description,
          pattern_text,
          keywords,
          confidence_threshold,
          is_active,
          priority
        FROM chatbot_intents 
        WHERE is_active = 1
        ORDER BY priority DESC
      `);

      console.log(`📚 Cargadas ${dbIntents.length} intenciones de la BD`);

      // Procesar intenciones de BD
      dbIntents.forEach(intent => {
        const intentName = intent.intent_name;
        
        if (!this.intents[intentName]) {
          this.intents[intentName] = {
            name: intentName,
            description: intent.intent_description,
            patterns: [],
            keywords: [],
            confidence: intent.confidence_threshold || 0.8,
            context: [],
            priority: intent.priority || 'medium',
            dbSource: true
          };
        }

        // Agregar patrón si existe
        if (intent.pattern_text) {
          try {
            const pattern = new RegExp(intent.pattern_text, 'i');
            this.intents[intentName].patterns.push(pattern);
          } catch (regexError) {
            console.warn('⚠️ Patrón regex inválido:', intent.pattern_text);
          }
        }

        // Agregar keywords
        if (intent.keywords) {
          const keywords = intent.keywords.split(',').map(k => k.trim());
          this.intents[intentName].keywords.push(...keywords);
        }
      });

    } catch (error) {
      console.error('❌ Error cargando intenciones de BD:', error);
    }
  }

  /**
   * Clasificar intención principal del mensaje
   */
  async classify(message, userContext = {}) {
    try {
      const normalizedMessage = message.toLowerCase().trim();
      
      console.log('🎯 Clasificando intención:', normalizedMessage.substring(0, 50));

      // Verificar cache
      const cacheKey = `intent_${normalizedMessage}`;
      if (this.intentCache.has(cacheKey)) {
        const cached = this.intentCache.get(cacheKey);
        if (Date.now() - cached.timestamp < this.cacheTimeout) {
          console.log('📋 Usando clasificación desde cache');
          return cached.data;
        }
      }

      // Analizar todas las intenciones
      const intentScores = [];

      for (const [intentName, intentData] of Object.entries(this.intents)) {
        const score = this.calculateIntentScore(normalizedMessage, intentData, userContext);
        
        if (score > 0) {
          intentScores.push({
            name: intentName,
            score,
            confidence: score * intentData.confidence,
            data: intentData
          });
        }
      }

      // Ordenar por puntuación
      intentScores.sort((a, b) => b.confidence - a.confidence);

      // Seleccionar mejor intención
      let bestIntent = intentScores[0];
      
      if (!bestIntent || bestIntent.confidence < 0.3) {
        bestIntent = {
          name: 'unknown',
          score: 0.1,
          confidence: 0.1,
          data: this.intents.unknown
        };
      }

      // Extraer entidades
      const entities = this.extractEntities(message, bestIntent.name);

      // Aplicar filtros contextuales
      const contextualIntent = this.applyContextualFilters(bestIntent, userContext, entities);

      const result = {
        type: contextualIntent.name,
        confidence: contextualIntent.confidence,
        entities,
        alternatives: intentScores.slice(1, 3).map(i => ({
          type: i.name,
          confidence: i.confidence
        })),
        filters: this.extractFilters(message, entities),
        metadata: {
          originalMessage: message,
          processingTime: Date.now(),
          contextUsed: Object.keys(userContext).length > 0
        }
      };

      // Guardar en cache
      this.intentCache.set(cacheKey, {
        data: result,
        timestamp: Date.now()
      });

      console.log('🎯 Intención clasificada:', {
        type: result.type,
        confidence: result.confidence.toFixed(2),
        entities: Object.keys(result.entities)
      });

      return result;

    } catch (error) {
      console.error('❌ Error clasificando intención:', error);
      
      return {
        type: 'unknown',
        confidence: 0,
        entities: {},
        alternatives: [],
        filters: {},
        error: error.message
      };
    }
  }

  /**
   * Calcular puntuación de intención
   */
  calculateIntentScore(message, intentData, userContext) {
    let score = 0;

    // 1. Verificar patrones regex
    for (const pattern of intentData.patterns) {
      if (pattern.test(message)) {
        score += 1.0;
        break; // Solo una coincidencia de patrón
      }
    }

    // 2. Verificar keywords
    const keywordMatches = intentData.keywords.filter(keyword => 
      message.includes(keyword.toLowerCase())
    ).length;
    
    if (keywordMatches > 0) {
      score += (keywordMatches / intentData.keywords.length) * 0.8;
    }

    // 3. Bonus por contexto del usuario
    if (userContext.conversationStage && intentData.context) {
      if (intentData.context.includes(userContext.conversationStage)) {
        score += 0.3;
      }
    }

    // 4. Bonus por historial de intenciones
    if (userContext.intentHistory && userContext.intentHistory.length > 0) {
      const lastIntent = userContext.intentHistory[userContext.intentHistory.length - 1];
      
      // Lógica de transiciones probables
      const intentTransitions = {
        'greeting': ['product_search', 'category_browse', 'contact_request'],
        'product_search': ['price_inquiry', 'availability_check', 'purchase_intent'],
        'price_inquiry': ['purchase_intent', 'product_comparison', 'discount_inquiry'],
        'availability_check': ['purchase_intent', 'shipping_inquiry'],
        'purchase_intent': ['payment_inquiry', 'shipping_inquiry', 'contact_request']
      };

      if (intentTransitions[lastIntent]?.includes(intentData.name)) {
        score += 0.2;
      }
    }

    // 5. Penalización por intenciones muy generales si hay mejores opciones
    if (intentData.name === 'unknown' && score === 0) {
      score = 0.05; // Puntuación mínima para fallback
    }

    return Math.min(score, 1.0); // Normalizar a máximo 1.0
  }

  /**
   * Extraer entidades del mensaje
   */
  extractEntities(message, intentType) {
    const entities = {
      products: [],
      categories: [],
      quantities: [],
      prices: [],
      colors: [],
      sizes: [],
      materials: [],
      locations: [],
      dates: [],
      person_names: []
    };

    try {
      const normalizedMessage = message.toLowerCase();

      // Extraer productos específicos
      const productMatch = normalizedMessage.match(this.entityPatterns.product);
      if (productMatch) {
        const productText = productMatch[1].trim();
        entities.products = this.extractProductEntities(productText);
      }

      // Extraer cantidades
      const quantityMatches = normalizedMessage.match(this.entityPatterns.quantity);
      if (quantityMatches) {
        entities.quantities.push({
          number: parseInt(quantityMatches[1]),
          unit: quantityMatches[2] || 'unidad'
        });
      }

      // Extraer rangos de precio
      const priceMatch = normalizedMessage.match(this.entityPatterns.price_range);
      if (priceMatch) {
        entities.prices.push({
          min: parseInt(priceMatch[1].replace(',', '')),
          max: parseInt(priceMatch[2].replace(',', ''))
        });
      }

      // Extraer colores
      const colorMatch = normalizedMessage.match(this.entityPatterns.color);
      if (colorMatch) {
        entities.colors.push(colorMatch[1]);
      }

      // Extraer tallas/tamaños
      const sizeMatch = normalizedMessage.match(this.entityPatterns.size);
      if (sizeMatch) {
        entities.sizes.push(sizeMatch[1]);
      }

      // Extraer materiales
      const materialMatch = normalizedMessage.match(this.entityPatterns.material);
      if (materialMatch) {
        entities.materials.push(materialMatch[1]);
      }

      // Extraer ubicaciones (ciudades colombianas)
      const colombianCities = [
        'bogotá', 'medellín', 'cali', 'barranquilla', 'cartagena', 
        'bucaramanga', 'pereira', 'ibagué', 'cúcuta', 'manizales'
      ];
      
      for (const city of colombianCities) {
        if (normalizedMessage.includes(city)) {
          entities.locations.push(city);
        }
      }

      // Extraer fechas relativas
      const datePatterns = [
        /hoy/i, /mañana/i, /pasado\s+mañana/i,
        /esta\s+semana/i, /próxima\s+semana/i,
        /este\s+mes/i, /próximo\s+mes/i
      ];

      datePatterns.forEach(pattern => {
        const match = message.match(pattern);
        if (match) {
          entities.dates.push(match[0]);
        }
      });

    } catch (error) {
      console.error('❌ Error extrayendo entidades:', error);
    }

    return entities;
  }

  /**
   * Extraer entidades específicas de productos
   */
  extractProductEntities(productText) {
    const products = [];
    
    // Lista de productos conocidos
    const knownProducts = [
      'tefilin', 'tallit', 'mezuzah', 'libros', 'kipa', 'shofar', 
      'menorah', 'velas', 'sidur', 'chumash', 'tehilim', 'zohar',
      'torah', 'talmud', 'kipot', 'tzitzit', 'janukia'
    ];

    // Buscar productos en el texto
    for (const product of knownProducts) {
      if (productText.includes(product)) {
        products.push(product);
      }
    }

    // Si no encuentra productos específicos, usar el texto completo
    if (products.length === 0 && productText.length > 0) {
      products.push(productText);
    }

    return products;
  }

  /**
   * Extraer filtros adicionales del mensaje
   */
  extractFilters(message, entities) {
    const filters = {};

    // Filtros de precio
    if (entities.prices.length > 0) {
      filters.minPrice = entities.prices[0].min;
      filters.maxPrice = entities.prices[0].max;
    }

    // Filtros de disponibilidad
    if (message.toLowerCase().includes('disponible') || 
        message.toLowerCase().includes('en stock')) {
      filters.onlyAvailable = true;
    }

    // Filtros de características
    if (entities.colors.length > 0) {
      filters.color = entities.colors[0];
    }

    if (entities.sizes.length > 0) {
      filters.size = entities.sizes[0];
    }

    if (entities.materials.length > 0) {
      filters.material = entities.materials[0];
    }

    // Filtro de productos destacados
    if (message.toLowerCase().includes('mejor') ||
        message.toLowerCase().includes('recomenda') ||
        message.toLowerCase().includes('popular')) {
      filters.featured = true;
    }

    // Filtro de ofertas
    if (message.toLowerCase().includes('oferta') ||
        message.toLowerCase().includes('descuento') ||
        message.toLowerCase().includes('rebaja')) {
      filters.onSale = true;
    }

    return filters;
  }

  /**
   * Aplicar filtros contextuales
   */
  applyContextualFilters(intent, userContext, entities) {
    // Si el usuario ya está en una conversación sobre un producto específico
    if (userContext.currentProduct && entities.products.length === 0) {
      // Puede estar haciendo una pregunta sobre el producto actual
      if (['price_inquiry', 'availability_check', 'purchase_intent'].includes(intent.name)) {
        entities.products.push(userContext.currentProduct);
        intent.confidence += 0.1; // Bonus por contexto
      }
    }

    // Si el usuario está en etapa de evaluación
    if (userContext.conversationStage === 'evaluation') {
      if (intent.name === 'product_search') {
        // Podría ser comparación en lugar de búsqueda nueva
        intent.name = 'product_comparison';
        intent.confidence += 0.05;
      }
    }

    // Si es una respuesta corta después de mostrar productos
    if (userContext.lastBotAction === 'product_list' && 
        ['affirmation', 'negation'].includes(intent.name)) {
      // Podría ser selección de producto
      intent.confidence += 0.2;
    }

    return intent;
  }

  /**
   * Pre-cargar intenciones más comunes
   */
  async preloadIntents() {
    const commonMessages = [
      'hola', 'busco tefilin', 'cuanto cuesta', 'hay disponible',
      'como compro', 'envios', 'contacto', 'gracias'
    ];

    console.log('🔥 Pre-cargando intenciones comunes...');
    
    for (const message of commonMessages) {
      await this.classify(message);
    }

    console.log(`✅ Pre-cargadas intenciones para ${commonMessages.length} mensajes`);
  }

  /**
   * Obtener estadísticas del clasificador
   */
  getStats() {
    return {
      totalIntents: Object.keys(this.intents).length,
      cacheSize: this.intentCache.size,
      staticIntents: Object.values(this.intents).filter(i => !i.dbSource).length,
      dbIntents: Object.values(this.intents).filter(i => i.dbSource).length
    };
  }

  /**
   * Limpiar cache
   */
  clearCache() {
    this.intentCache.clear();
    console.log('🧹 Cache de intenciones limpiado');
  }

  /**
   * Agregar nueva intención dinámicamente
   */
  async addIntent(intentData) {
    try {
      const { name, description, patterns, keywords, confidence = 0.8 } = intentData;

      // Validar datos
      if (!name || !description) {
        throw new Error('Nombre y descripción son requeridos');
      }

      // Guardar en BD
      await query(`
        INSERT INTO chatbot_intents 
        (intent_name, intent_description, pattern_text, keywords, confidence_threshold, is_active)
        VALUES (?, ?, ?, ?, ?, 1)
        ON DUPLICATE KEY UPDATE
          intent_description = VALUES(intent_description),
          pattern_text = VALUES(pattern_text),
          keywords = VALUES(keywords),
          confidence_threshold = VALUES(confidence_threshold),
          updated_at = NOW()
      `, [
        name,
        description,
        patterns[0]?.source || '',
        keywords.join(', '),
        confidence
      ]);

      // Agregar a memoria
      this.intents[name] = {
        name,
        description,
        patterns: patterns || [],
        keywords: keywords || [],
        confidence,
        context: [],
        priority: 'medium',
        dbSource: true
      };

      console.log(`✅ Intención agregada: ${name}`);
      return true;

    } catch (error) {
      console.error('❌ Error agregando intención:', error);
      return false;
    }
  }

  /**
   * Evaluar precisión del clasificador
   */
  async evaluateAccuracy(testCases) {
    let correct = 0;
    const results = [];

    for (const testCase of testCases) {
      const result = await this.classify(testCase.message);
      const isCorrect = result.type === testCase.expectedIntent;
      
      if (isCorrect) correct++;
      
      results.push({
        message: testCase.message,
        expected: testCase.expectedIntent,
        predicted: result.type,
        confidence: result.confidence,
        correct: isCorrect
      });
    }

    const accuracy = correct / testCases.length;
    
    console.log(`📊 Precisión del clasificador: ${(accuracy * 100).toFixed(2)}%`);
    
    return {
      accuracy,
      totalCases: testCases.length,
      correctPredictions: correct,
      results
    };
  }
}