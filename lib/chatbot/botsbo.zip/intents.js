// lib/chatbot/intents.js - CLASIFICADOR PROFESIONAL COMPATIBLE CON TU SISTEMA

import { query } from '../database';

export class IntentClassifier {
  constructor() {
    this.intentCache = new Map();
    this.cacheTimeout = 15 * 60 * 1000;
    this.isInitialized = false; // AGREGADO: para compatibilidad

    // Definición completa de intenciones con patrones avanzados
    this.intents = {
      // SALUDOS Y CORTESÍA
      greeting: {
        name: 'greeting',
        description: 'Saludos iniciales y presentaciones',
        patterns: [
          /^(hola|hey|hi|hello|buenos?\s*(días?|tardes?|noches?))/i,
          /^(shalom|qué\s+tal|cómo\s+estás?|cómo\s+está)/i,
          /^(saludos|buen\s+día|buenas)/i
        ],
        keywords: ['hola', 'hi', 'hello', 'shalom', 'buenos', 'buenas', 'saludo'],
        confidence: 0.95,
        context: ['inicio', 'presentacion', 'cortesia'],
        priority: 'high'
      },

      farewell: {
        name: 'farewell',
        description: 'Despedidas y cierre de conversación',
        patterns: [
          /(adiós|chau|hasta\s+luego|nos\s+vemos|bye|goodbye)/i,
          /(gracias\s+por\s+todo|muchas\s+gracias|perfecto|excelente)/i,
          /(hasta\s+pronto|que\s+tengas?\s+buen|shalom)/i
        ],
        keywords: ['adiós', 'chau', 'bye', 'hasta', 'nos vemos', 'gracias'],
        confidence: 0.92,
        context: ['cierre', 'despedida', 'finalizacion'],
        priority: 'medium'
      },

      thanks: {
        name: 'thanks',
        description: 'Agradecimientos del usuario',
        patterns: [
          /^(gracias|muchas\s+gracias|te\s+agradezco)/i,
          /^(thanks|thank\s+you|excelente|perfecto)/i,
          /^(muy\s+bien|genial|fantástico)/i
        ],
        keywords: ['gracias', 'thanks', 'agradezco', 'excelente', 'perfecto'],
        confidence: 0.94,
        context: ['agradecimiento', 'satisfaccion'],
        priority: 'medium'
      },

      // BÚSQUEDA Y NAVEGACIÓN DE PRODUCTOS - MEJORADO PARA TU SISTEMA
      specific_product_inquiry: {
        name: 'specific_product_inquiry', // CAMBIADO: compatible con responses.js
        description: 'Búsqueda específica de productos',
        patterns: [
          /busco\s+(.+)/i,
          /necesito\s+(.+)/i,
          /quiero\s+(ver|comprar)?\s*(.+)/i,
          /tienen\s+(.+)/i,
          /hay\s+(.+)/i,
          /mostrar?\s+(.+)/i,
          /dónde\s+(encuentro|está)\s+(.+)/i,
          // AGREGADO: patrones específicos para productos judaicos
          /(emunah|torah|tefilin|tallit|mezuzah|kipa|tehilim|breslov)/i
        ],
        keywords: ['busco', 'necesito', 'quiero', 'tienen', 'hay', 'mostrar', 'ver', 'emunah', 'torah', 'tefilin'],
        confidence: 0.92, // AUMENTADO: para productos específicos
        context: ['busqueda', 'producto', 'catalogo'],
        priority: 'highest', // CAMBIADO: máxima prioridad
        extractEntities: true
      },

      // PRECIOS E INFORMACIÓN COMERCIAL
      price_inquiry: {
        name: 'price_inquiry',
        description: 'Consultas sobre precios',
        patterns: [
          /cuánto\s+(cuesta|vale|es|sale)/i,
          /precio\s+(de|del|para)\s*(.+)/i,
          /valor\s+(de|del)\s*(.+)/i,
          /\$\s*\d+/,
          /(presupuesto|cotiz)/i,
          /(caro|barato|económico)/i
        ],
        keywords: ['cuanto', 'precio', 'valor', 'cuesta', 'vale', 'presupuesto', 'cotizar'],
        confidence: 0.95, // AUMENTADO
        context: ['precio', 'costo', 'informacion'],
        priority: 'highest' // CAMBIADO
      },

      availability_check: {
        name: 'availability_check',
        description: 'Consultas sobre disponibilidad y stock',
        patterns: [
          /hay\s+(disponible|stock|existencia)/i,
          /tienen?\s+(en\s+)?stock/i,
          /disponibilidad\s+(de|del)\s*(.+)/i,
          /cuándo\s+(llega|estará\s+disponible)/i,
          /(agotado|sin\s+stock|out\s+of\s+stock)/i,
          /en\s+existencia/i
        ],
        keywords: ['disponible', 'stock', 'existencia', 'agotado', 'cuando llega'],
        confidence: 0.93, // AUMENTADO
        context: ['disponibilidad', 'inventario', 'stock'],
        priority: 'highest' // CAMBIADO
      },

      // PROCESO DE COMPRA
      purchase_intent: {
        name: 'purchase_intent',
        description: 'Intención de compra',
        patterns: [
          /cómo\s+(compro|comprar)/i,
          /dónde\s+(compro|comprar)/i,
          /quiero\s+comprar/i,
          /proceso\s+de\s+compra/i,
          /(agregar\s+al\s+carrito|añadir\s+al\s+carrito)/i,
          /lo\s+(compro|llevo)/i
        ],
        keywords: ['comprar', 'proceso', 'carrito', 'llevar', 'agregar'],
        confidence: 0.94,
        context: ['compra', 'adquisicion', 'proceso'],
        priority: 'highest' // CAMBIADO
      },

      payment_inquiry: {
        name: 'payment_inquiry',
        description: 'Consultas sobre métodos de pago',
        patterns: [
          /(forma|método|forma)\s+de\s+pago/i,
          /(tarjeta|efectivo|transferencia|pse)/i,
          /cómo\s+(pago|puedo\s+pagar)/i,
          /(aceptan|reciben)\s+(.+)/i,
          /cuotas?\s+(sin\s+interés|con\s+tarjeta)/i
        ],
        keywords: ['pago', 'tarjeta', 'efectivo', 'transferencia', 'pse', 'cuotas'],
        confidence: 0.91,
        context: ['pago', 'metodo', 'financiacion'],
        priority: 'high'
      },

      // ENVÍOS Y LOGÍSTICA
      shipping_inquiry: {
        name: 'shipping_inquiry',
        description: 'Consultas sobre envíos y entregas',
        patterns: [
          /envío?s?\s*(a|hasta|nacional|local)?/i,
          /entrega\s*(a\s+domicilio|express|rápida)?/i,
          /(delivery|shipping)/i,
          /cuánto\s+tarda\s+(el\s+)?envío/i,
          /tiempo\s+de\s+entrega/i,
          /(transportadora|mensajería)/i,
          /envían\s+a\s+(.+)/i
        ],
        keywords: ['envio', 'entrega', 'delivery', 'transportadora', 'tarda', 'tiempo'],
        confidence: 0.92, // AUMENTADO
        context: ['envio', 'logistica', 'entrega'],
        priority: 'highest' // CAMBIADO
      },

      // SOPORTE Y CONTACTO
      help_request: { // AGREGADO: faltaba en el anterior
        name: 'help_request',
        description: 'Solicitudes de ayuda general',
        patterns: [
          /ayuda/i,
          /no\s+(entiendo|comprendo)/i,
          /información/i,
          /qué\s+(hacen|venden|ofrecen|manejan)/i,
          /catálogo/i,
          /productos/i,
          /ver\s+productos/i
        ],
        keywords: ['ayuda', 'información', 'catálogo', 'productos', 'qué hacen'],
        confidence: 0.85,
        context: ['ayuda', 'soporte', 'informacion'],
        priority: 'medium'
      },

      contact_request: {
        name: 'contact_request',
        description: 'Solicitudes de contacto directo',
        patterns: [
          /(contacto|contactar)/i,
          /(whatsapp|teléfono|llamar)/i,
          /hablar\s+con\s+(alguien|asesor|vendedor)/i,
          /(asesor|especialista|ayuda\s+personalizada)/i,
          /número\s+de\s+(teléfono|whatsapp)/i
        ],
        keywords: ['contacto', 'whatsapp', 'telefono', 'asesor', 'hablar', 'llamar'],
        confidence: 0.93,
        context: ['contacto', 'soporte', 'asesor'],
        priority: 'high'
      },

      location_inquiry: {
        name: 'location_inquiry',
        description: 'Consultas sobre ubicación',
        patterns: [
          /dónde\s+(están|quedan|ubicados)/i,
          /(dirección|ubicación|sede)/i,
          /cómo\s+(llegar|llego)/i,
          /(tienda\s+física|local|establecimiento)/i
        ],
        keywords: ['donde', 'direccion', 'ubicacion', 'llegar', 'tienda', 'local'],
        confidence: 0.88,
        context: ['ubicacion', 'direccion', 'local'],
        priority: 'medium'
      },

      complaint: {
        name: 'complaint',
        description: 'Quejas y problemas',
        patterns: [
          /(queja|reclamo|problema)/i,
          /(malo|defectuoso|roto|dañado)/i,
          /no\s+(funciona|sirve|llegó)/i,
          /(devolver|cambio|garantía)/i,
          /(insatisfecho|molesto|enojado)/i
        ],
        keywords: ['queja', 'reclamo', 'problema', 'malo', 'devolver', 'garantia'],
        confidence: 0.89,
        context: ['problema', 'queja', 'soporte'],
        priority: 'highest', // CAMBIADO: alta prioridad
        requiresHuman: true // AGREGADO: para responses.js
      },

      // AGREGADO: Referencias contextuales (compatible con responses.js)
      product_reference: {
        name: 'product_reference',
        description: 'Referencias a productos mostrados anteriormente',
        patterns: [
          /^(el\s+)?[1-4]$/i,
          /^(el\s+)?(primero|segundo|tercero|cuarto)$/i,
          /^(ese|esa|este|esta|el último)$/i
        ],
        keywords: ['1', '2', '3', '4', 'primero', 'segundo', 'tercero', 'cuarto', 'ese', 'este', 'último'],
        confidence: 0.98,
        context: ['referencia', 'seleccion'],
        priority: 'highest'
      },

      // INFORMACIÓN ESPECÍFICA DE PRODUCTOS JUDAICOS
      kashrut_inquiry: {
        name: 'kashrut_inquiry',
        description: 'Consultas sobre certificación kosher',
        patterns: [
          /(kosher|kasher|kashrut)/i,
          /(certificación|supervisión)\s+(rabínica|kosher)/i,
          /es\s+(kosher|kasher)/i,
          /(halál|permitido|prohibido)/i
        ],
        keywords: ['kosher', 'kasher', 'certificacion', 'rabinica', 'supervision'],
        confidence: 0.92,
        context: ['kashrut', 'certificacion', 'religion'],
        priority: 'high'
      },

      religious_guidance: {
        name: 'religious_guidance',
        description: 'Orientación religiosa sobre productos',
        patterns: [
          /cómo\s+(usar|utilizar|colocar)\s+(.+)/i,
          /(bendición|bracha|rezo)\s+(para|de)\s+(.+)/i,
          /(tradición|costumbre|halajá)/i,
          /qué\s+(significa|representa)\s+(.+)/i
        ],
        keywords: ['usar', 'bendicion', 'bracha', 'tradicion', 'costumbre', 'halaja'],
        confidence: 0.87,
        context: ['religion', 'tradicion', 'uso'],
        priority: 'high'
      },

      // INTENCIONES AVANZADAS
      recommendation_request: {
        name: 'recommendation_request',
        description: 'Solicitudes de recomendaciones',
        patterns: [
          /(recomienda|recomendación|sugerencia)/i,
          /qué\s+(es\s+)?mejor\s+(para|de)\s*(.+)/i,
          /cuál\s+(elijo|escojo|conviene)/i,
          /(consejo|opinión)\s+(sobre|de)\s*(.+)/i
        ],
        keywords: ['recomienda', 'mejor', 'elijo', 'consejo', 'opinion', 'sugerencia'],
        confidence: 0.85,
        context: ['recomendacion', 'consejo', 'decision'],
        priority: 'medium'
      },

      gift_inquiry: {
        name: 'gift_inquiry',
        description: 'Consultas sobre regalos',
        patterns: [
          /(regalo|obsequio|presente)/i,
          /(bar\s+mitzvah|bat\s+mitzvah|boda)/i,
          /para\s+(regalar|obsequiar)/i,
          /(cumpleaños|aniversario|celebración)/i
        ],
        keywords: ['regalo', 'presente', 'bar mitzvah', 'boda', 'cumpleanos'],
        confidence: 0.89,
        context: ['regalo', 'celebracion', 'ocasion'],
        priority: 'medium'
      },

      // INTENCIONES DE CONTEXTO
      affirmation: {
        name: 'affirmation',
        description: 'Confirmaciones y respuestas afirmativas',
        patterns: [
          /^(sí|si|yes|ok|okay|dale|perfecto)/i,
          /^(exacto|correcto|así\s+es|claro)/i,
          /^(por\s+supuesto|desde\s+luego)/i
        ],
        keywords: ['si', 'yes', 'ok', 'perfecto', 'exacto', 'correcto'],
        confidence: 0.95,
        context: ['confirmacion', 'afirmacion'],
        priority: 'high'
      },

      negation: {
        name: 'negation',
        description: 'Negaciones y respuestas negativas',
        patterns: [
          /^(no|nope|para\s+nada)/i,
          /^(ninguno|ninguna|nada)/i,
          /^(incorrecto|equivocado)/i
        ],
        keywords: ['no', 'nope', 'ninguno', 'nada', 'incorrecto'],
        confidence: 0.94,
        context: ['negacion', 'rechazo'],
        priority: 'high'
      },

      // INTENCIÓN GENÉRICA (FALLBACK)
      unknown: {
        name: 'unknown',
        description: 'Intención no identificada',
        patterns: [],
        keywords: [],
        confidence: 0.10,
        context: ['desconocido', 'generico'],
        priority: 'low'
      }
    };

    // MEJORADO: Patrones para extracción de entidades específicas para tu sistema
    this.entityPatterns = {
      products: /(?:busco|necesito|quiero|precio de|cuánto cuesta|hay|venden|me interesa)\s+(.+?)(?:\s*[?.]|$)/i,
      breslov_books: /(emunah|jardín\s+de\s+la\s+paz|vivamos\s+con\s+emunah|shalom\s+arush)/i,
      religious_books: /(tehilim|sidur|torah|talmud|zohar|tanaj)/i,
      ritual_items: /(tefilin|tallit|mezuzah|kipa|shofar)/i,
      reference_number: /^(?:el\s+)?([1-4]|primero|segundo|tercero|cuarto)$/i,
      quantity: /(\d+)\s*(unidades?|piezas?|docenas?|pares?)?/i,
      price_range: /entre\s+\$?(\d+(?:,\d{3})*)\s+y\s+\$?(\d+(?:,\d{3})*)/i,
      cities: /(bogotá|medellín|cali|barranquilla|cartagena|bucaramanga)/i
    };
  }

  // AGREGADO: Método initialize para compatibilidad
  async initialize() {
    if (this.isInitialized) return true;

    try {
      console.log('Inicializando Intent Classifier completo...');
      await this.loadDatabaseIntents();
      this.isInitialized = true;
      console.log(`Intent Classifier inicializado con ${Object.keys(this.intents).length} intenciones`);
      return true;
    } catch (error) {
      console.error('Error inicializando classifier:', error);
      this.isInitialized = true; // Continuar con intenciones estáticas
      return true;
    }
  }

  async loadDatabaseIntents() {
    try {
      // Verificar si la tabla existe
      const tableExists = await query("SHOW TABLES LIKE 'chatbot_intents'");
      if (tableExists.length === 0) {
        console.log('Tabla chatbot_intents no existe, usando intenciones estáticas');
        return;
      }

      const dbIntents = await query(`
        SELECT 
          intent_name,
          intent_description,
          pattern_text,
          keywords,
          confidence_threshold,
          is_active,
          priority
        FROM chatbot_intents 
        WHERE is_active = 1
        ORDER BY priority DESC
      `);

      console.log(`Cargadas ${dbIntents.length} intenciones de la BD`);

      dbIntents.forEach(intent => {
        const intentName = intent.intent_name;
        
        if (!this.intents[intentName]) {
          this.intents[intentName] = {
            name: intentName,
            description: intent.intent_description,
            patterns: [],
            keywords: [],
            confidence: intent.confidence_threshold || 0.8,
            context: [],
            priority: intent.priority || 'medium',
            dbSource: true
          };
        }

        if (intent.pattern_text) {
          try {
            const pattern = new RegExp(intent.pattern_text, 'i');
            this.intents[intentName].patterns.push(pattern);
          } catch (regexError) {
            console.warn('Patrón regex inválido:', intent.pattern_text);
          }
        }

        if (intent.keywords) {
          const keywords = intent.keywords.split(',').map(k => k.trim());
          this.intents[intentName].keywords.push(...keywords);
        }
      });

    } catch (error) {
      console.error('Error cargando intenciones de BD:', error);
    }
  }

  // MEJORADO: Método classify compatible con el sistema integrado
  async classify(message, userContext = {}) {
    try {
      const normalizedMessage = message.toLowerCase().trim();
      console.log(`Clasificando: "${normalizedMessage}"`);

      // Cache check
      const cacheKey = `intent_${normalizedMessage}`;
      if (this.intentCache.has(cacheKey)) {
        const cached = this.intentCache.get(cacheKey);
        if (Date.now() - cached.timestamp < this.cacheTimeout) {
          console.log('Resultado desde cache');
          return cached.data;
        }
      }

      // Clasificación rápida para referencias contextuales
      if (this._isProductReference(normalizedMessage)) {
        console.log('Referencia de producto detectada');
        const result = {
          type: 'product_reference',
          confidence: 0.98,
          entities: { reference: this.extractReferenceNumber(normalizedMessage) },
          isQuick: true
        };
        
        this._cacheResult(cacheKey, result);
        return result;
      }

      // Clasificación principal mejorada
      const result = await this._fullClassify(normalizedMessage, userContext, message);
      this._cacheResult(cacheKey, result);
      
      return result;

    } catch (error) {
      console.error('Error en clasificación:', error);
      return {
        type: 'unknown',
        confidence: 0,
        entities: {},
        error: error.message
      };
    }
  }

  _isProductReference(message) {
    const patterns = [
      /^(el\s+)?[1-4]$/,
      /^(el\s+)?(primero|segundo|tercero|cuarto)$/i,
      /^(ese|esa|este|esta)$/i,
      /^(el\s+)?último$/i
    ];
    return patterns.some(pattern => pattern.test(message));
  }

  extractReferenceNumber(message) {
    const numberMap = {
      '1': 0, 'primero': 0,
      '2': 1, 'segundo': 1,
      '3': 2, 'tercero': 2,
      '4': 3, 'cuarto': 3
    };

    const cleanMessage = message.replace(/^(?:el\s+)?/, '').trim();
    
    if (numberMap.hasOwnProperty(cleanMessage)) {
      return numberMap[cleanMessage];
    }
    
    if (cleanMessage === 'último' || cleanMessage === 'ultima') {
      return -1;
    }
    
    return 0;
  }

  async _fullClassify(message, userContext, originalMessage) {
    const intentScores = [];

    // Evaluar todas las intenciones
    for (const [intentName, intentData] of Object.entries(this.intents)) {
      if (intentName === 'unknown') continue;

      const score = this._calculateIntentScore(message, intentData, userContext);
      
      if (score > 0) {
        intentScores.push({
          name: intentName,
          score,
          confidence: Math.min(score * intentData.confidence, 1.0),
          data: intentData
        });
      }
    }

    // Ordenar por confianza
    intentScores.sort((a, b) => b.confidence - a.confidence);

    let bestIntent = intentScores[0];
    
    if (!bestIntent || bestIntent.confidence < 0.3) {
      const specificTerms = this._containsSpecificTerms(message);
      if (specificTerms.length > 0) {
        bestIntent = {
          name: 'specific_product_inquiry',
          confidence: 0.7,
          data: this.intents.specific_product_inquiry
        };
      } else {
        bestIntent = {
          name: 'unknown',
          confidence: 0.1,
          data: this.intents.unknown
        };
      }
    }

    const result = {
      type: bestIntent.name,
      confidence: bestIntent.confidence,
      entities: this.extractEntities(originalMessage, bestIntent.name),
      alternatives: intentScores.slice(1, 3).map(i => ({
        type: i.name,
        confidence: i.confidence
      })),
      metadata: {
        processingMethod: 'full',
        totalIntentsAnalyzed: intentScores.length,
        specificTerms: this._containsSpecificTerms(message)
      }
    };

    console.log(`Clasificación: ${result.type} (${(result.confidence * 100).toFixed(1)}%)`);
    
    return result;
  }

  _containsSpecificTerms(message) {
    const specificTerms = [
      'libro', 'tefilin', 'tallit', 'mezuzah', 'kipa', 'copa', 'tehilim', 
      'torah', 'tanaj', 'breslov', 'jardín', 'emunah', 'shalom', 'arush',
      'sidur', 'talmud', 'zohar', 'kidush', 'shabat', 'vela', 'menorah'
    ];
    
    return specificTerms.filter(term => message.toLowerCase().includes(term));
  }

  _calculateIntentScore(message, intentData, userContext) {
    let score = 0;

    // Puntaje por patrones (más importante)
    for (const pattern of intentData.patterns) {
      if (pattern.test(message)) {
        score += 1.0;
        break;
      }
    }

    // Puntaje por palabras clave
    const keywordMatches = intentData.keywords.filter(keyword => 
      message.includes(keyword.toLowerCase())
    ).length;
    
    if (keywordMatches > 0) {
      score += Math.min(keywordMatches * 0.3, 0.8);
    }

    // Bonus por contexto conversacional
    if (userContext.lastIntent && this._areRelatedIntents(userContext.lastIntent, intentData.name)) {
      score += 0.2;
    }

    return Math.min(score, 1.5);
  }

  _areRelatedIntents(lastIntent, currentIntent) {
    const relatedPairs = {
      'greeting': ['help_request', 'specific_product_inquiry'],
      'specific_product_inquiry': ['price_inquiry', 'availability_check', 'purchase_intent'],
      'price_inquiry': ['availability_check', 'purchase_intent'],
      'availability_check': ['purchase_intent', 'shipping_inquiry'],
      'shipping_inquiry': ['purchase_intent', 'payment_inquiry'],
      'purchase_intent': ['payment_inquiry', 'location_inquiry'],
      'help_request': ['specific_product_inquiry', 'price_inquiry']
    };

    return relatedPairs[lastIntent]?.includes(currentIntent) || false;
  }

  // MEJORADO: Extracción de entidades compatible con tu sistema
  extractEntities(message, intentType) {
    const entities = {
      products: [],
      breslov_books: [],
      religious_books: [],
      ritual_items: [],
      cities: [],
      reference: null,
      quantities: [],
      prices: []
    };

    try {
      const normalizedMessage = message.toLowerCase();

      // Referencias numéricas
      if (intentType === 'product_reference') {
        entities.reference = this.extractReferenceNumber(normalizedMessage);
      }

      // Productos generales
      const productMatch = normalizedMessage.match(this.entityPatterns.products);
      if (productMatch) {
        const productText = productMatch[1].trim();
        if (productText.length > 2 && productText.length < 50) {
          entities.products.push(productText);
        }
      }

      // Libros Breslov específicos
      const breslovMatch = normalizedMessage.match(this.entityPatterns.breslov_books);
      if (breslovMatch) {
        entities.breslov_books.push(breslovMatch[0]);
      }

      // Libros religiosos
      const religiousMatch = normalizedMessage.match(this.entityPatterns.religious_books);
      if (religiousMatch) {
        entities.religious_books.push(religiousMatch[0]);
      }

      // Artículos rituales
      const ritualMatch = normalizedMessage.match(this.entityPatterns.ritual_items);
      if (ritualMatch) {
        entities.ritual_items.push(ritualMatch[0]);
      }

      // Ciudades
      const cityMatch = normalizedMessage.match(this.entityPatterns.cities);
      if (cityMatch) {
        entities.cities.push(cityMatch[1]);
      }

      // Cantidades
      const quantityMatch = normalizedMessage.match(this.entityPatterns.quantity);
      if (quantityMatch) {
        entities.quantities.push({
          number: parseInt(quantityMatch[1]),
          unit: quantityMatch[2] || 'unidad'
        });
      }

      // Rangos de precio
      const priceMatch = normalizedMessage.match(this.entityPatterns.price_range);
      if (priceMatch) {
        entities.prices.push({
          min: parseInt(priceMatch[1].replace(',', '')),
          max: parseInt(priceMatch[2].replace(',', ''))
        });
      }

      // Limpiar entidades vacías
      Object.keys(entities).forEach(key => {
        if (Array.isArray(entities[key]) && entities[key].length === 0) {
          delete entities[key];
        }
      });

      return entities;

    } catch (error) {
      console.error('Error extrayendo entidades:', error);
      return entities;
    }
  }

  _cacheResult(cacheKey, result) {
    this.intentCache.set(cacheKey, {
      data: result,
      timestamp: Date.now()
    });
  }

  clearCache() {
    this.intentCache.clear();
    console.log('Cache de intenciones limpiado');
  }

  // Método para limpiar cache expirado automáticamente
  cleanupExpiredCache() {
    const now = Date.now();
    for (const [key, value] of this.intentCache.entries()) {
      if (now - value.timestamp > this.cacheTimeout) {
        this.intentCache.delete(key);
      }
    }
  }

  // Método para obtener estadísticas del clasificador
  getStats() {
    return {
      totalIntents: Object.keys(this.intents).length,
      cacheSize: this.intentCache.size,
      isInitialized: this.isInitialized,
      cacheTimeout: this.cacheTimeout,
      intentsByPriority: this._getIntentsByPriority()
    };
  }

  _getIntentsByPriority() {
    const priorities = { highest: [], high: [], medium: [], low: [] };
    Object.values(this.intents).forEach(intent => {
      const priority = intent.priority || 'medium';
      if (priorities[priority]) {
        priorities[priority].push(intent.name);
      }
    });
    return priorities;
  }

  // Método para entrenar el clasificador con nuevos ejemplos
  async trainFromExamples(examples) {
    if (!Array.isArray(examples)) {
      throw new Error('Los ejemplos deben ser un array');
    }

    console.log(`Entrenando con ${examples.length} ejemplos`);

    for (const example of examples) {
      const { text, intent, confidence } = example;
      
      if (!text || !intent) {
        console.warn('Ejemplo inválido:', example);
        continue;
      }

      // Clasificar el ejemplo
      const result = await this.classify(text);
      
      // Si la clasificación no coincide, ajustar
      if (result.type !== intent && confidence > 0.8) {
        await this._adjustIntent(text, intent, result);
      }
    }

    console.log('Entrenamiento completado');
  }

  async _adjustIntent(text, correctIntent, currentResult) {
    try {
      // Agregar el patrón al intent correcto si no existe
      if (this.intents[correctIntent]) {
        const pattern = this._generatePatternFromText(text);
        if (pattern && !this.intents[correctIntent].patterns.some(p => p.source === pattern.source)) {
          this.intents[correctIntent].patterns.push(pattern);
        }

        // Extraer y agregar nuevas palabras clave
        const keywords = this._extractKeywordsFromText(text);
        keywords.forEach(keyword => {
          if (!this.intents[correctIntent].keywords.includes(keyword)) {
            this.intents[correctIntent].keywords.push(keyword);
          }
        });

        console.log(`Ajustado intent ${correctIntent} con: "${text}"`);
      }
    } catch (error) {
      console.error('Error ajustando intent:', error);
    }
  }

  _generatePatternFromText(text) {
    try {
      // Crear un patrón básico escapando caracteres especiales
      const escapedText = text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      return new RegExp(escapedText, 'i');
    } catch (error) {
      console.error('Error generando patrón:', error);
      return null;
    }
  }

  _extractKeywordsFromText(text) {
    const stopWords = ['el', 'la', 'de', 'que', 'y', 'a', 'en', 'un', 'es', 'se', 'no', 'te', 'lo', 'le', 'da', 'su', 'por', 'son', 'con', 'para', 'al', 'del', 'los', 'las', 'una', 'su', 'me', 'si', 'yo', 'mi', 'tu', 'como', 'pero', 'muy', 'mas', 'bien'];
    
    return text.toLowerCase()
      .split(/\s+/)
      .filter(word => word.length > 2)
      .filter(word => !stopWords.includes(word))
      .filter(word => /^[a-záéíóúñü]+$/i.test(word));
  }

  // Método para validar la configuración del clasificador
  validateConfiguration() {
    const errors = [];
    const warnings = [];

    // Validar estructura de intents
    Object.entries(this.intents).forEach(([name, intent]) => {
      if (!intent.name) {
        errors.push(`Intent ${name} sin nombre`);
      }
      
      if (!intent.patterns || !Array.isArray(intent.patterns)) {
        errors.push(`Intent ${name} sin patrones válidos`);
      }
      
      if (!intent.keywords || !Array.isArray(intent.keywords)) {
        warnings.push(`Intent ${name} sin palabras clave`);
      }
      
      if (typeof intent.confidence !== 'number' || intent.confidence < 0 || intent.confidence > 1) {
        errors.push(`Intent ${name} con confianza inválida`);
      }
    });

    // Validar patrones de entidades
    Object.entries(this.entityPatterns).forEach(([name, pattern]) => {
      if (!(pattern instanceof RegExp)) {
        errors.push(`Patrón de entidad ${name} no es una expresión regular`);
      }
    });

    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      summary: {
        totalIntents: Object.keys(this.intents).length,
        totalEntityPatterns: Object.keys(this.entityPatterns).length,
        errorsCount: errors.length,
        warningsCount: warnings.length
      }
    };
  }

  // Método para exportar configuración
  exportConfiguration() {
    return {
      version: '1.0.0',
      timestamp: new Date().toISOString(),
      intents: this.intents,
      entityPatterns: Object.fromEntries(
        Object.entries(this.entityPatterns).map(([key, pattern]) => [
          key, 
          pattern.source
        ])
      ),
      settings: {
        cacheTimeout: this.cacheTimeout,
        isInitialized: this.isInitialized
      }
    };
  }

  // Método para importar configuración
  async importConfiguration(config) {
    try {
      if (!config.version || !config.intents) {
        throw new Error('Configuración inválida');
      }

      // Importar intents
      this.intents = { ...config.intents };

      // Importar patrones de entidades
      if (config.entityPatterns) {
        Object.entries(config.entityPatterns).forEach(([key, patternSource]) => {
          try {
            this.entityPatterns[key] = new RegExp(patternSource, 'i');
          } catch (error) {
            console.warn(`Error importando patrón ${key}:`, error);
          }
        });
      }

      // Aplicar configuraciones
      if (config.settings) {
        this.cacheTimeout = config.settings.cacheTimeout || this.cacheTimeout;
      }

      // Limpiar cache
      this.clearCache();

      console.log('Configuración importada exitosamente');
      return true;
    } catch (error) {
      console.error('Error importando configuración:', error);
      return false;
    }
  }

  // Método para análisis de texto avanzado
  analyzeText(text) {
    const analysis = {
      originalText: text,
      normalizedText: text.toLowerCase().trim(),
      length: text.length,
      wordCount: text.split(/\s+/).length,
      hasNumbers: /\d/.test(text),
      hasSpecialChars: /[!@#$%^&*(),.?":{}|<>]/.test(text),
      possibleIntents: [],
      entities: this.extractEntities(text, 'generic'),
      sentiment: this._analyzeSentiment(text)
    };

    // Analizar posibles intents sin clasificar completamente
    Object.entries(this.intents).forEach(([name, intent]) => {
      const score = this._calculateIntentScore(analysis.normalizedText, intent, {});
      if (score > 0.2) {
        analysis.possibleIntents.push({
          intent: name,
          score,
          confidence: score * intent.confidence
        });
      }
    });

    analysis.possibleIntents.sort((a, b) => b.confidence - a.confidence);

    return analysis;
  }

  _analyzeSentiment(text) {
    const positiveWords = ['bien', 'bueno', 'excelente', 'perfecto', 'genial', 'gracias', 'fantástico'];
    const negativeWords = ['malo', 'terrible', 'problema', 'error', 'falla', 'reclamo', 'queja'];
    
    const textLower = text.toLowerCase();
    const positiveCount = positiveWords.filter(word => textLower.includes(word)).length;
    const negativeCount = negativeWords.filter(word => textLower.includes(word)).length;
    
    if (positiveCount > negativeCount) return 'positive';
    if (negativeCount > positiveCount) return 'negative';
    return 'neutral';
  }

  // Método para obtener sugerencias de mejora
  getSuggestions(recentClassifications = []) {
    const suggestions = [];

    // Analizar clasificaciones recientes
    const intentFrequency = {};
    const lowConfidenceCount = recentClassifications.filter(c => c.confidence < 0.6).length;

    recentClassifications.forEach(classification => {
      intentFrequency[classification.type] = (intentFrequency[classification.type] || 0) + 1;
    });

    // Sugerencias basadas en el análisis
    if (lowConfidenceCount > recentClassifications.length * 0.3) {
      suggestions.push({
        type: 'training',
        priority: 'high',
        message: 'Alto porcentaje de clasificaciones con baja confianza. Considera entrenar con más ejemplos.'
      });
    }

    const mostFrequentIntent = Object.keys(intentFrequency)
      .reduce((a, b) => intentFrequency[a] > intentFrequency[b] ? a : b, null);

    if (mostFrequentIntent && intentFrequency[mostFrequentIntent] > recentClassifications.length * 0.5) {
      suggestions.push({
        type: 'intent_optimization',
        priority: 'medium',
        message: `El intent '${mostFrequentIntent}' es muy frecuente. Considera crear sub-intents más específicos.`
      });
    }

    return suggestions;
  }

  // Método para debugging
  debug(message) {
    const debugInfo = {
      timestamp: new Date().toISOString(),
      message,
      normalizedMessage: message.toLowerCase().trim(),
      cacheStatus: this.intentCache.has(`intent_${message.toLowerCase().trim()}`),
      analysis: this.analyzeText(message)
    };

    console.log('=== DEBUG INTENT CLASSIFIER ===');
    console.log('Mensaje original:', debugInfo.message);
    console.log('Mensaje normalizado:', debugInfo.normalizedMessage);
    console.log('En cache:', debugInfo.cacheStatus);
    console.log('Análisis completo:', debugInfo.analysis);
    console.log('==========================');

    return debugInfo;
  }
}

// Función helper para crear instancia singleton
let classifierInstance = null;

export function getIntentClassifier() {
  if (!classifierInstance) {
    classifierInstance = new IntentClassifier();
  }
  return classifierInstance;
}

// Función helper para clasificación rápida
export async function quickClassify(message, context = {}) {
  const classifier = getIntentClassifier();
  await classifier.initialize();
  return await classifier.classify(message, context);
}

// Exportar por defecto
export default IntentClassifier;