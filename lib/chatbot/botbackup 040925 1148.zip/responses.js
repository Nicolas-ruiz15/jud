import { query } from '../database';

export class ResponseGeneratorProfessional {
  constructor() {
    this.conversationContext = new Map();
    this.lastShownProducts = new Map();
    
    this.responseTemplates = {
      
      price_inquiry: {
        single_product: (product) => {
          const price = new Intl.NumberFormat('es-CO').format(product.display_price);
          const isOnSale = product.sale_price && product.sale_price > 0;
          
          return `**${product.name}**
💰 **$${price}**${isOnSale ? ` (¡Descuento!)` : ''}
✅ ${product.stock_status === 'in_stock' ? 'DISPONIBLE' : 'Por encargo (3-5 días)'}

🚚 Envío: Bogotá $18k | Nacional $23k | GRATIS +$250k

🛒 **COMPRAR:**
https://www.judaicabreslovcolombia.com/producto/${product.slug || product.id}

WhatsApp: https://wa.me/573009291156?text=${encodeURIComponent(`Consulta: ${product.name}`)}

¿Alguna otra duda?`;
        },

        multiple_products: (products, sessionId) => {
          // Guardar productos para referencias posteriores
          this.lastShownProducts.set(sessionId, products.slice(0, 4));
          
          let response = `**Productos encontrados:**\n\n`;
          
          products.slice(0, 4).forEach((product, index) => {
            const price = new Intl.NumberFormat('es-CO').format(product.display_price);
            const status = product.stock_status === 'in_stock' ? '✅' : '⏳';
            
            response += `**${index + 1}.** ${product.name}\n`;
            response += `   💰 ${price} ${status}\n`;
            response += `   🛒 https://www.judaicabreslovcolombia.com/producto/${product.slug || product.id}\n\n`;
          });

          response += `¿Cuál te interesa? (puedes decir "el 1", "el segundo", etc.)`;
          return response;
        },

        general_price_range: () => `**Nuestros productos:**
• Literatura Breslov auténtica
• Artículos religiosos kosher  
• Copas Kidush y Shabat
• Productos rituales tradicionales

🚚 Envío GRATIS +$250k
📞 WhatsApp: https://wa.me/573009291156

¿Qué producto específico buscas?`
      },

      availability_check: {
        single_product: (product) => {
          const stockIcon = product.stock_status === 'in_stock' ? '✅' : '⏳';
          const stockText = product.stock_status === 'in_stock' ? 'DISPONIBLE' : 'Por encargo (3-5 días)';

          return `**${product.name}**
${stockIcon} ${stockText}
💰 ${new Intl.NumberFormat('es-CO').format(product.display_price)}

${product.stock_status === 'in_stock' ? 
  '🚀 Envío inmediato disponible' : 
  '📅 3-5 días hábiles'
}

🛒 **COMPRAR:**
https://www.judaicabreslovcolombia.com/producto/${product.slug || product.id}

¿Procedes con la compra?`;
        },

        general_availability: () => `**Estado actual:**
✅ 78% productos disponibles inmediato
⏳ 15% disponibles por encargo  
🔄 7% en restock

WhatsApp: https://wa.me/573009291156
Catálogo: https://www.judaicabreslovcolombia.com

¿Qué producto necesitas verificar?`
      },

      shipping_inquiry: {
        general_info: () => {
          return `**Envíos a toda Colombia:**

🏢 **Bogotá:** $18,000 (24-48h)
🏙️ **Ciudades principales:** $23,000 (2-3 días)
🌎 **Nacional:** $23,000 (3-4 días)
🆓 **GRATIS:** Compras +$250,000

✅ Seguro incluido
📱 Seguimiento SMS

¿A qué ciudad necesitas envío?`;
        }
      },

      specific_product_inquiry: {
        with_products: (products, searchTerm, sessionId) => {
          this.lastShownProducts.set(sessionId, products.slice(0, 4));
          
          if (products.length === 1) {
            const product = products[0];
            const price = new Intl.NumberFormat('es-CO').format(product.display_price);
            const isOnSale = product.sale_price && product.sale_price > 0;
            
            return `**${product.name}**
💰 ${price}${isOnSale ? ' 🔥' : ''}
${product.stock_status === 'in_stock' ? '✅ DISPONIBLE' : '⏳ Por encargo (3-5 días)'}

📖 **Descripción:**
${product.short_description || product.description?.substring(0, 120) + '...' || 'Producto de calidad kosher certificada'}

🛒 **COMPRAR:**
https://www.judaicabreslovcolombia.com/producto/${product.slug || product.id}

WhatsApp: https://wa.me/573009291156?text=Quiero%20${encodeURIComponent(product.name)}

¿Necesitas más información?`;
          } else {
            let response = `**${products.length} productos encontrados para "${searchTerm}":**\n\n`;
            
            products.slice(0, 4).forEach((product, index) => {
              const price = new Intl.NumberFormat('es-CO').format(product.display_price);
              const status = product.stock_status === 'in_stock' ? '✅' : '⏳';
              const isOnSale = product.sale_price && product.sale_price > 0;
              
              response += `**${index + 1}. ${product.name}**\n`;
              response += `   💰 ${price}${isOnSale ? ' 🔥' : ''} ${status}\n`;
              response += `   🛒 https://www.judaicabreslovcolombia.com/producto/${product.slug || product.id}\n\n`;
            });

            response += `**¿Cuál te interesa?** Puedes decir "el 1", "el segundo", etc.`;
            return response;
          }
        },

        without_products: (searchTerm) => {
          return `No encontré productos específicos para "${searchTerm}".

**Nuestro catálogo incluye:**
• Literatura Breslov (Emunah, Jardín de la Paz)
• Artículos Shabat (copas, velas, candelabros)
• Rituales kosher (tefilín, tallit, mezuzah)

📱 **WhatsApp directo:** https://wa.me/573009291156?text=Busco%20${encodeURIComponent(searchTerm)}
🌐 **Catálogo completo:** https://www.judaicabreslovcolombia.com

¿Puedes ser más específico?`;
        }
      },

      purchase_intent: {
        template: () => `**¿Cómo comprar?**

**Opción 1:** Tienda online
🌐 https://www.judaicabreslovcolombia.com

**Opción 2:** WhatsApp personalizado
📱 https://wa.me/573009291156?text=Quiero%20comprar

💳 **Pagos:** Todas las tarjetas | PSE | Efectivo
🆓 Envío gratis +$250k

¿Prefieres online o asesoría personalizada?`
      },

      product_reference: {
        template: (productIndex, products) => {
          if (!products || productIndex >= products.length || productIndex < 0) {
            return `No encuentro esa referencia. 

¿Puedes ser más específico o usar WhatsApp?
📱 https://wa.me/573009291156`;
          }

          if (productIndex === -1) {
            productIndex = products.length - 1;
          }

          const product = products[productIndex];
          const price = new Intl.NumberFormat('es-CO').format(product.display_price);
          const isOnSale = product.sale_price && product.sale_price > 0;
          
          return `**${product.name}**
💰 ${price}${isOnSale ? ' 🔥' : ''}
${product.stock_status === 'in_stock' ? '✅ DISPONIBLE' : '⏳ Por encargo (3-5 días)'}

📖 **Detalles:**
${product.short_description || product.description?.substring(0, 120) + '...' || 'Producto de calidad kosher certificada'}

🛒 **COMPRAR:**
https://www.judaicabreslovcolombia.com/producto/${product.slug || product.id}

📱 **WhatsApp:** https://wa.me/573009291156?text=Quiero%20${encodeURIComponent(product.name)}

¿Necesitas más información?`;
        }
      },

      greeting: {
        templates: [
          `**¡Shalom! Judaica Breslov Colombia**

Especialistas en literatura Breslov y artículos kosher.

**Consultas populares:**
• "precio de emunah"
• "copas kidush disponibles"
• "libros breslov"

📱 WhatsApp: https://wa.me/573009291156

¿En qué te ayudo?`,

          `**Bienvenido a Judaica Breslov Colombia**

**Productos destacados:**
• Literatura auténtica del Rabí Najmán
• Artículos rituales kosher certificados
• Productos para Shabat y festividades

🚚 **Envío gratis** en compras +$250,000

¿Qué necesitas?`
        ]
      },

      help_request: {
        template: () => `**¿Cómo puedo ayudarte?**

**Puedes preguntarme:**
• "precio de [producto]"
• "hay [artículo] disponible?"
• "envío a [ciudad]"
• "libros de breslov"

**Categorías principales:**
📚 Literatura Breslov
🕯️ Artículos Shabat
📿 Rituales kosher
💎 Joyería judaica

📱 WhatsApp: https://wa.me/573009291156
🌐 https://www.judaicabreslovcolombia.com

¿Qué buscas específicamente?`
      },

      unknown: {
        template: () => `No logré entender tu consulta.

**Ejemplos de preguntas:**
• "precio de copa kidush"
• "hay tefilín disponibles?"
• "libros de shalom arush"
• "envío a medellín"

📱 **WhatsApp directo:** https://wa.me/573009291156
🌐 **Catálogo:** https://www.judaicabreslovcolombia.com

¿Puedes reformular tu pregunta?`
      }
    };
  }

  async generate(context) {
    try {
      const { intent, searchResults, userContext, sessionId, originalMessage } = context;

      console.log(`📝 Generando respuesta para: ${intent.type}`);

      // Verificar referencias a productos anteriores
      const referenceResponse = this.handleProductReference(originalMessage, sessionId);
      if (referenceResponse) {
        return referenceResponse;
      }

      const response = await this._generateSpecificResponse(intent, searchResults, userContext, sessionId);
      const suggestions = this._generateContextualSuggestions(intent.type, searchResults);

      return {
        text: response.text,
        suggestions: suggestions,
        requiresHuman: response.requiresHuman || false,
        metadata: {
          intent: intent.type,
          confidence: intent.confidence,
          hasProducts: searchResults?.length > 0,
          responseType: response.type
        }
      };

    } catch (error) {
      console.error('❌ Error generando respuesta:', error);
      return this._generateErrorResponse(error);
    }
  }

  handleProductReference(message, sessionId) {
    const lastProducts = this.lastShownProducts.get(sessionId);
    if (!lastProducts || lastProducts.length === 0) {
      return null;
    }

    const lowerMessage = message.toLowerCase();
    let productIndex = -1;

    // Detectar referencias numéricas y ordinales
    if (lowerMessage.includes('el 1') || lowerMessage.includes('primero') || lowerMessage === '1') {
      productIndex = 0;
    } else if (lowerMessage.includes('el 2') || lowerMessage.includes('segundo') || lowerMessage === '2') {
      productIndex = 1;
    } else if (lowerMessage.includes('el 3') || lowerMessage.includes('tercero') || lowerMessage === '3') {
      productIndex = 2;
    } else if (lowerMessage.includes('el 4') || lowerMessage.includes('cuarto') || lowerMessage === '4') {
      productIndex = 3;
    } else if (lowerMessage.includes('último') || lowerMessage.includes('el último')) {
      productIndex = lastProducts.length - 1;
    }

    if (productIndex >= 0) {
      return {
        text: this.responseTemplates.product_reference.template(productIndex, lastProducts),
        requiresHuman: false,
        suggestions: ['Más información', 'WhatsApp directo', 'Ver otros productos'],
        type: 'product_reference'
      };
    }

    return null;
  }

  async _generateSpecificResponse(intent, searchResults, userContext, sessionId) {
    const intentType = intent.type;
    const templates = this.responseTemplates[intentType];

    switch (intentType) {
      case 'price_inquiry':
        return this._generatePriceResponse(searchResults, intent.entities, sessionId);

      case 'availability_check':
        return this._generateAvailabilityResponse(searchResults, intent.entities);

      case 'shipping_inquiry':
        return {
          text: templates.general_info(),
          requiresHuman: false,
          type: 'shipping_info'
        };

      case 'specific_product_inquiry':
        return this._generateProductResponse(searchResults, intent.entities, sessionId);

      case 'purchase_intent':
        return {
          text: templates.template(),
          requiresHuman: false,
          type: 'purchase_guide'
        };

      case 'product_reference':
        const lastProducts = this.lastShownProducts.get(sessionId);
        if (lastProducts && lastProducts.length > 0) {
          const referenceIndex = intent.entities?.reference ?? 0;
          return {
            text: templates.template(referenceIndex, lastProducts),
            requiresHuman: false,
            type: 'product_reference'
          };
        } else {
          return {
            text: `No tienes productos previos para referenciar. 

¿Qué producto específico buscas?

📱 WhatsApp: https://wa.me/573009291156`,
            requiresHuman: false,
            type: 'no_context'
          };
        }

      case 'greeting':
        return {
          text: this._getRandomTemplate(templates.templates),
          requiresHuman: false,
          type: 'greeting'
        };

      case 'help_request':
        return {
          text: templates.template(),
          requiresHuman: false,
          type: 'help'
        };

      default:
        return {
          text: this.responseTemplates.unknown.template(),
          requiresHuman: false,
          type: 'unknown'
        };
    }
  }

  async _generatePriceResponse(products, entities, sessionId) {
    const templates = this.responseTemplates.price_inquiry;

    if (products && products.length > 0) {
      this.lastShownProducts.set(sessionId, products.slice(0, 4));
      
      if (products.length === 1) {
        return {
          text: templates.single_product(products[0]),
          requiresHuman: false,
          type: 'price_single'
        };
      } else {
        return {
          text: templates.multiple_products(products, sessionId),
          requiresHuman: false,
          type: 'price_multiple'
        };
      }
    } else {
      return {
        text: templates.general_price_range(),
        requiresHuman: false,
        type: 'price_general'
      };
    }
  }

  async _generateAvailabilityResponse(products, entities) {
    const templates = this.responseTemplates.availability_check;

    if (products && products.length > 0) {
      return {
        text: templates.single_product(products[0]),
        requiresHuman: false,
        type: 'availability_specific'
      };
    } else {
      return {
        text: templates.general_availability(),
        requiresHuman: false,
        type: 'availability_general'
      };
    }
  }

  _generateProductResponse(products, entities, sessionId) {
    const templates = this.responseTemplates.specific_product_inquiry;
    const searchTerm = entities?.products?.[0] || 
                     entities?.breslov_books?.[0] || 
                     entities?.religious_books?.[0] || 
                     'producto solicitado';

    if (products && products.length > 0) {
      return {
        text: templates.with_products(products, searchTerm, sessionId),
        requiresHuman: false,
        type: 'product_with_results'
      };
    } else {
      return {
        text: templates.without_products(searchTerm),
        requiresHuman: false,
        type: 'product_no_results'
      };
    }
  }

  _getRandomTemplate(templates) {
    if (!templates || templates.length === 0) {
      return 'Gracias por contactar Judaica Breslov Colombia. ¿En qué más te ayudo?';
    }
    const randomIndex = Math.floor(Math.random() * templates.length);
    return templates[randomIndex];
  }

  _generateContextualSuggestions(intentType, products) {
    const baseSuggestions = {
      'price_inquiry': ['Ver disponibilidad', 'Calcular envío', 'WhatsApp'],
      'availability_check': ['Ver precio', 'Proceso compra', 'WhatsApp'],
      'shipping_inquiry': ['Ver productos', 'Métodos pago', 'WhatsApp'],
      'specific_product_inquiry': ['Ver precio', 'Disponibilidad', 'WhatsApp'],
      'purchase_intent': ['Métodos pago', 'Calcular envío', 'WhatsApp'],
      'greeting': ['Ver productos', 'Consultar precio', 'WhatsApp'],
      'help_request': ['Literatura Breslov', 'Artículos Shabat', 'WhatsApp']
    };
    
    return baseSuggestions[intentType] || ['WhatsApp directo', 'Ver catálogo'];
  }

  _generateErrorResponse(error) {
    return {
      text: `Error temporal del sistema.

📱 **WhatsApp directo:** https://wa.me/573009291156?text=Error%20técnico
🌐 **Web:** https://www.judaicabreslovcolombia.com

¿Puedes reformular tu consulta?`,
      requiresHuman: true,
      suggestions: ['WhatsApp directo', 'Reintentar', 'Ver tienda'],
      type: 'error'
    };
  }
}