// lib/chatbot/chatbotInstance.js - VERSIÓN CORREGIDA

import { AdvancedMultiEngineChatbot } from './engine.js';

console.log("🤖 Inicializando instancia única del Chatbot...");

class ChatbotSingleton {
  constructor() {
    this.chatbot = null;
    this.isInitializing = false;
    this.isInitialized = false;
    this.initPromise = null;
    this.initError = null;
  }

  async getInstance() {
    // Si ya está inicializado, devolver la instancia
    if (this.isInitialized && this.chatbot) {
      return this.chatbot;
    }

    // Si hay un error previo de inicialización, intentar de nuevo
    if (this.initError) {
      console.log("⚠️ Error previo detectado, reintentando inicialización...");
      this.initError = null;
      this.isInitialized = false;
      this.isInitializing = false;
      this.initPromise = null;
    }

    // Si ya está inicializando, esperar a que termine
    if (this.isInitializing && this.initPromise) {
      console.log("⏳ Esperando inicialización en curso...");
      return await this.initPromise;
    }

    // Inicializar por primera vez
    return await this.initialize();
  }

  async initialize() {
    this.isInitializing = true;
    
    this.initPromise = new Promise(async (resolve, reject) => {
      try {
        console.log("🚀 Creando nueva instancia del motor...");
        
        this.chatbot = new AdvancedMultiEngineChatbot();
        
        console.log("⚙️ Inicializando motor del chatbot...");
        const success = await this.chatbot.initialize();
        
        if (success) {
          this.isInitialized = true;
          this.isInitializing = false;
          console.log("✅✅✅ Instancia única del Chatbot INICIALIZADA Y LISTA ✅✅✅");
          resolve(this.chatbot);
        } else {
          throw new Error("Inicialización del motor falló");
        }
        
      } catch (error) {
        console.error("🔥🔥🔥 FALLO CRÍTICO al inicializar la instancia única del Chatbot 🔥🔥🔥");
        console.error("Error detallado:", error);
        
        this.isInitialized = false;
        this.isInitializing = false;
        this.initError = error;
        this.chatbot = null;
        
        reject(error);
      }
    });

    return await this.initPromise;
  }

  // Método para verificar estado
  getStatus() {
    return {
      isInitialized: this.isInitialized,
      isInitializing: this.isInitializing,
      hasError: !!this.initError,
      error: this.initError?.message || null
    };
  }

  // Método para reinicializar en caso de error
  async reinitialize() {
    console.log("🔄 Reinicializando chatbot...");
    this.chatbot = null;
    this.isInitialized = false;
    this.isInitializing = false;
    this.initPromise = null;
    this.initError = null;
    
    return await this.getInstance();
  }
}

// Crear la instancia singleton
const chatbotSingleton = new ChatbotSingleton();

// Función helper para obtener la instancia (usada en APIs)
export async function getChatbotInstance() {
  try {
    return await chatbotSingleton.getInstance();
  } catch (error) {
    console.error("❌ Error obteniendo instancia del chatbot:", error);
    throw error;
  }
}

// Función para verificar estado (usada para debugging)
export function getChatbotStatus() {
  return chatbotSingleton.getStatus();
}

// Función para reinicializar (usada para recovery)
export async function reinitializeChatbot() {
  return await chatbotSingleton.reinitialize();
}

// Export por defecto para compatibilidad (DEPRECATED - usar getChatbotInstance)
export default {
  async processMessage(...args) {
    const instance = await getChatbotInstance();
    return await instance.processMessage(...args);
  },
  
  async getSystemInfo() {
    const instance = await getChatbotInstance();
    return instance.getSystemInfo();
  },
  
  getStatus: getChatbotStatus
};