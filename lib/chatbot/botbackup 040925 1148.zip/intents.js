// lib/chatbot/intents.js - CLASIFICADOR MEJORADO

import { query } from '../database';

export class IntentClassifier {
  constructor() {
    this.intentCache = new Map();
    this.cacheTimeout = 15 * 60 * 1000;
    this.isInitialized = false;

    // Definición completa de intenciones MEJORADAS
    this.intents = {
      // SALUDOS Y CORTESÍA
      greeting: {
        name: 'greeting',
        description: 'Saludos iniciales y presentaciones',
        patterns: [
          /^(hola|hey|hi|hello|buenos?\s*(días?|tardes?|noches?))/i,
          /^(shalom|qué\s+tal|cómo\s+estás?|cómo\s+está)/i,
          /^(saludos|buen\s+día|buenas)/i
        ],
        keywords: ['hola', 'hi', 'hello', 'shalom', 'buenos', 'buenas', 'saludo'],
        confidence: 0.95,
        context: ['inicio', 'presentacion', 'cortesia'],
        priority: 'high'
      },

      farewell: {
        name: 'farewell',
        description: 'Despedidas y cierre de conversación',
        patterns: [
          /^(adiós|chau|chao|hasta\s+luego|nos\s+vemos|bye|goodbye)$/i,
          /(gracias\s+por\s+todo|muchas\s+gracias\s+por|perfecto\s*!?|excelente\s*!?)$/i,
          /^(hasta\s+pronto|que\s+tengas?\s+buen|shalom)$/i
        ],
        keywords: ['adiós', 'chau', 'chao', 'bye', 'hasta', 'nos vemos'],
        confidence: 0.95,
        context: ['cierre', 'despedida', 'finalizacion'],
        priority: 'high'
      },

      thanks: {
        name: 'thanks',
        description: 'Agradecimientos del usuario',
        patterns: [
          /^(gracias|muchas\s+gracias|te\s+agradezco)$/i,
          /^(thanks|thank\s+you|gracia)$/i,  // Agregado "gracia" común
          /^(muy\s+bien|genial|fantástico)$/i
        ],
        keywords: ['gracias', 'thanks', 'agradezco', 'gracia'],
        confidence: 0.98,
        context: ['agradecimiento', 'satisfaccion'],
        priority: 'high'
      },

      // BÚSQUEDA Y NAVEGACIÓN DE PRODUCTOS - MEJORADO
      specific_product_inquiry: {
        name: 'specific_product_inquiry',
        description: 'Búsqueda específica de productos',
        patterns: [
          // Patrones mejorados y más flexibles
          /(?:busco|buscando|necesito|requiero|quiero)\s+(.+)/i,
          /(?:tienes?|tienen)\s+(.+?)(?:\?|$)/i,  // CORREGIDO: captura "tienes sidur"
          /quiero\s+(?:ver|comprar|adquirir)\s+(.+)/i,
          /(?:hay|venden|manejan)\s+(.+?)(?:\?|$)/i,
          /(?:mostrar?|enseñar|ver)\s+(.+)/i,
          /dónde\s+(?:encuentro|está|consigo)\s+(.+)/i,
          // Patrones específicos para productos judaicos
          /(tefilin|tallit|mezuzah|kipa|tehilim|breslov|emunah|torah|sidur)/i,
          /libros?\s+(?:de\s+)?(.+)/i,
          /(?:precio\s+de|cuánto\s+(?:cuesta|vale))\s+(.+)/i,
          // NUEVO: Patrón simple de respaldo para términos específicos
          /^(sidur|tefilin|tallit|menorah|candelabro|torah|tanaj|kitzur)(?:\s+(.+))?$/i
        ],
        keywords: ['busco', 'necesito', 'quiero', 'tienen', 'tienes', 'hay', 'mostrar', 'ver', 'libro', 'libros'],
        confidence: 0.92,
        context: ['busqueda', 'producto', 'catalogo'],
        priority: 'highest',
        extractEntities: true
      },

      // PRECIOS E INFORMACIÓN COMERCIAL
      price_inquiry: {
        name: 'price_inquiry',
        description: 'Consultas sobre precios',
        patterns: [
          /(?:cuánto|cuanto)\s+(?:cuesta|vale|es|sale)\s*(.+)?/i,
          /precio\s+(?:de|del|para)\s*(.+)/i,
          /(?:valor|costo)\s+(?:de|del)\s*(.+)/i,
          /\$\s*\d+/,
          /(?:presupuesto|cotiz)/i,
          /(?:caro|barato|económico)/i,
          /a\s+(?:cuánto|cuanto)\s+(?:está|sale)\s*(.+)?/i
        ],
        keywords: ['cuanto', 'precio', 'valor', 'cuesta', 'vale', 'presupuesto', 'cotizar', 'costo'],
        confidence: 0.95,
        context: ['precio', 'costo', 'informacion'],
        priority: 'highest'
      },

      availability_check: {
        name: 'availability_check',
        description: 'Consultas sobre disponibilidad y stock',
        patterns: [
          /(?:hay|tiene[ns]?)\s+(?:disponible|stock|existencia)?\s*(.+)?/i,
          /(?:disponible|disponibilidad)\s+(?:de|del)?\s*(.+)?/i,
          /cuándo\s+(?:llega|estará\s+disponible)\s*(.+)?/i,
          /(?:agotado|sin\s+stock|out\s+of\s+stock)/i,
          /en\s+existencia\s*(.+)?/i
        ],
        keywords: ['disponible', 'stock', 'existencia', 'agotado', 'cuando llega', 'hay', 'tiene', 'tienen'],
        confidence: 0.93,
        context: ['disponibilidad', 'inventario', 'stock'],
        priority: 'highest'
      },

      // PROCESO DE COMPRA
      purchase_intent: {
        name: 'purchase_intent',
        description: 'Intención de compra',
        patterns: [
          /cómo\s+(?:compro|comprar)/i,
          /dónde\s+(?:compro|comprar)/i,
          /quiero\s+comprar/i,
          /proceso\s+de\s+compra/i,
          /(?:agregar\s+al\s+carrito|añadir\s+al\s+carrito)/i,
          /lo\s+(?:compro|llevo)/i
        ],
        keywords: ['comprar', 'proceso', 'carrito', 'llevar', 'agregar'],
        confidence: 0.94,
        context: ['compra', 'adquisicion', 'proceso'],
        priority: 'highest'
      },

      payment_inquiry: {
        name: 'payment_inquiry',
        description: 'Consultas sobre métodos de pago',
        patterns: [
          /(?:forma|método|forma)\s+de\s+pago/i,
          /(?:tarjeta|efectivo|transferencia|pse)/i,
          /cómo\s+(?:pago|puedo\s+pagar)/i,
          /(?:aceptan|reciben)\s+(.+)/i,
          /cuotas?\s+(?:sin\s+interés|con\s+tarjeta)/i
        ],
        keywords: ['pago', 'tarjeta', 'efectivo', 'transferencia', 'pse', 'cuotas'],
        confidence: 0.91,
        context: ['pago', 'metodo', 'financiacion'],
        priority: 'high'
      },

      // ENVÍOS Y LOGÍSTICA - MEJORADO
      shipping_inquiry: {
        name: 'shipping_inquiry',
        description: 'Consultas sobre envíos y entregas',
        patterns: [
          /envío?s?\s*(?:a|hasta|nacional|local)?/i,
          /entrega\s*(?:a\s+domicilio|express|rápida)?/i,
          /(?:delivery|shipping)/i,
          /cuánto\s+tarda\s+(?:el\s+)?envío/i,
          /tiempo\s+de\s+entrega/i,
          /(?:transportadora|mensajería)/i,
          /envían\s+a\s+(.+)/i,
          /hacen\s+envios?\s+a\s+(.+)/i  // AGREGADO: patrón específico de la conversación
        ],
        keywords: ['envio', 'entrega', 'delivery', 'transportadora', 'tarda', 'tiempo', 'hacen'],
        confidence: 0.92,
        context: ['envio', 'logistica', 'entrega'],
        priority: 'highest'
      },

      // SOPORTE Y CONTACTO
      help_request: {
        name: 'help_request',
        description: 'Solicitudes de ayuda general',
        patterns: [
          /ayuda/i,
          /no\s+(?:entiendo|comprendo)/i,
          /información/i,
          /qué\s+(?:hacen|venden|ofrecen|manejan)/i,
          /catálogo/i,
          /productos/i,
          /ver\s+productos/i,
          /que\s+categorias\s+tienes/i,  // AGREGADO de conversación
          /que\s+me\s+ofreces/i  // AGREGADO de conversación
        ],
        keywords: ['ayuda', 'información', 'catálogo', 'productos', 'qué hacen', 'categorias', 'ofreces'],
        confidence: 0.85,
        context: ['ayuda', 'soporte', 'informacion'],
        priority: 'medium'
      },

      contact_request: {
        name: 'contact_request',
        description: 'Solicitudes de contacto directo',
        patterns: [
          /(?:contacto|contactar)/i,
          /(?:whatsapp|teléfono|llamar)/i,
          /hablar\s+con\s+(?:alguien|asesor|vendedor|persona)/i,
          /(?:asesor|especialista|ayuda\s+personalizada)/i,
          /número\s+de\s+(?:teléfono|whatsapp)/i,
          // AGREGADO: patrones específicos de la conversación
          /quiero\s+hablar\s+con\s+(?:una\s+)?persona/i,
          /(?:puedo|necesito)\s+(?:chatear|hablar)\s+con\s+(?:un\s+)?(?:agente|asesor|persona)/i,
          /^whatsapp$/i,  // Comando simple
          /atención\s+(?:al\s+)?cliente/i
        ],
        keywords: ['contacto', 'whatsapp', 'telefono', 'asesor', 'hablar', 'llamar', 'agente', 'persona', 'chatear'],
        confidence: 0.95,
        context: ['contacto', 'soporte', 'asesor'],
        priority: 'high'
      },

      location_inquiry: {
        name: 'location_inquiry',
        description: 'Consultas sobre ubicación',
        patterns: [
          /dónde\s+(?:están|quedan|ubicados)/i,
          /(?:dirección|ubicación|sede)/i,
          /cómo\s+(?:llegar|llego)/i,
          /(?:tienda\s+física|local|establecimiento)/i
        ],
        keywords: ['donde', 'direccion', 'ubicacion', 'llegar', 'tienda', 'local'],
        confidence: 0.88,
        context: ['ubicacion', 'direccion', 'local'],
        priority: 'medium'
      },

      complaint: {
        name: 'complaint',
        description: 'Quejas y problemas',
        patterns: [
          /(?:queja|reclamo|problema)/i,
          /(?:malo|defectuoso|roto|dañado)/i,
          /no\s+(?:funciona|sirve|llegó)/i,
          /(?:devolver|cambio|garantía)/i,
          /(?:insatisfecho|molesto|enojado)/i
        ],
        keywords: ['queja', 'reclamo', 'problema', 'malo', 'devolver', 'garantia'],
        confidence: 0.89,
        context: ['problema', 'queja', 'soporte'],
        priority: 'highest',
        requiresHuman: true
      },

      // REFERENCIAS CONTEXTUALES Y RESPUESTAS CORTAS
      product_reference: {
        name: 'product_reference',
        description: 'Referencias a productos mostrados anteriormente',
        patterns: [
          /^(?:el\s+)?[1-4]$/i,
          /^(?:el\s+)?(?:primero|segundo|tercero|cuarto)$/i,
          /^(?:ese|esa|este|esta|el\s+último)$/i
        ],
        keywords: ['1', '2', '3', '4', 'primero', 'segundo', 'tercero', 'cuarto', 'ese', 'este', 'último'],
        confidence: 0.98,
        context: ['referencia', 'seleccion'],
        priority: 'highest'
      },

      // RESPUESTAS CONTEXTUALES A ENVÍOS
      shipping_context_response: {
        name: 'shipping_context_response', 
        description: 'Respuestas contextuales sobre ciudades para envío',
        patterns: [
          /^(bogotá|bogota|medellín|medellin|cali|barranquilla|cartagena|bucaramanga)$/i,
          /^(b\/quilla|bga|ctg)$/i
        ],
        keywords: ['bogota', 'medellin', 'cali', 'barranquilla', 'cartagena', 'bucaramanga'],
        confidence: 0.95,
        context: ['ciudad', 'envio', 'contextual'],
        priority: 'highest',
        requiresContext: true
      },

      // COMANDOS DE SISTEMA
      system_commands: {
        name: 'system_commands',
        description: 'Comandos para ver información del sistema',
        patterns: [
          /^ver\s+(precio|precios|catalogo|catálogo|productos|categoria|categorias)$/i,
          /^(precio|precios|catalogo|catálogo)$/i,
          /^mostrar\s+(productos|precios|catalogo)$/i
        ],
        keywords: ['ver precio', 'ver catalogo', 'precio', 'catalogo', 'mostrar'],
        confidence: 0.92,
        context: ['sistema', 'navegacion'],
        priority: 'high'
      },

      // INFORMACIÓN ESPECÍFICA DE PRODUCTOS JUDAICOS
      kashrut_inquiry: {
        name: 'kashrut_inquiry',
        description: 'Consultas sobre certificación kosher',
        patterns: [
          /(?:kosher|kasher|kashrut)/i,
          /(?:certificación|supervisión)\s+(?:rabínica|kosher)/i,
          /es\s+(?:kosher|kasher)/i,
          /(?:halál|permitido|prohibido)/i
        ],
        keywords: ['kosher', 'kasher', 'certificacion', 'rabinica', 'supervision'],
        confidence: 0.92,
        context: ['kashrut', 'certificacion', 'religion'],
        priority: 'high'
      },

      religious_guidance: {
        name: 'religious_guidance',
        description: 'Orientación religiosa sobre productos',
        patterns: [
          /cómo\s+(?:usar|utilizar|colocar)\s+(.+)/i,
          /(?:bendición|bracha|rezo)\s+(?:para|de)\s+(.+)/i,
          /(?:tradición|costumbre|halajá)/i,
          /qué\s+(?:significa|representa)\s+(.+)/i
        ],
        keywords: ['usar', 'bendicion', 'bracha', 'tradicion', 'costumbre', 'halaja'],
        confidence: 0.87,
        context: ['religion', 'tradicion', 'uso'],
        priority: 'high'
      },

      // INTENCIONES AVANZADAS
      recommendation_request: {
        name: 'recommendation_request',
        description: 'Solicitudes de recomendaciones',
        patterns: [
          /(?:recomienda|recomendación|sugerencia)/i,
          /qué\s+(?:es\s+)?mejor\s+(?:para|de)\s*(.+)/i,
          /cuál\s+(?:elijo|escojo|conviene)/i,
          /(?:consejo|opinión)\s+(?:sobre|de)\s*(.+)/i,
          // AGREGADO: patrones específicos de la conversación
          /que\s+me\s+(?:recomiendas|sugieres|aconsejas)/i,
          /qué\s+(?:producto|libro|artículo)\s+(?:recomiendas|me\s+recomiendas)/i,
          /dame\s+(?:una\s+)?(?:recomendación|sugerencia)/i
        ],
        keywords: ['recomienda', 'mejor', 'elijo', 'consejo', 'opinion', 'sugerencia', 'que me recomiendas'],
        confidence: 0.90,
        context: ['recomendacion', 'consejo', 'decision'],
        priority: 'medium'
      },

      // NUEVA INTENCIÓN: Seguimiento de pedidos
      order_tracking: {
        name: 'order_tracking',
        description: 'Consultas sobre pedidos y seguimiento',
        patterns: [
          /(?:preguntar|consultar)\s+por\s+(?:un\s+|mi\s+)?pedido/i,
          /seguimiento\s+(?:de|del)\s+pedido/i,
          /(?:estado|estatus)\s+(?:de|del)\s+pedido/i,
          /dónde\s+(?:está|quedó)\s+mi\s+pedido/i,
          /cuándo\s+(?:llega|llegará)\s+mi\s+pedido/i,
          /número\s+de\s+(?:pedido|orden|seguimiento)/i,
          /mi\s+(?:compra|orden|pedido)/i
        ],
        keywords: ['pedido', 'seguimiento', 'estado', 'orden', 'compra', 'llega', 'cuando'],
        confidence: 0.93,
        context: ['pedido', 'seguimiento', 'orden'],
        priority: 'high'
      },

      gift_inquiry: {
        name: 'gift_inquiry',
        description: 'Consultas sobre regalos',
        patterns: [
          /(?:regalo|obsequio|presente)/i,
          /(?:bar\s+mitzvah|bat\s+mitzvah|boda)/i,
          /para\s+(?:regalar|obsequiar)/i,
          /(?:cumpleaños|aniversario|celebración)/i
        ],
        keywords: ['regalo', 'presente', 'bar mitzvah', 'boda', 'cumpleanos'],
        confidence: 0.89,
        context: ['regalo', 'celebracion', 'ocasion'],
        priority: 'medium'
      },

      // INTENCIONES DE CONTEXTO
      affirmation: {
        name: 'affirmation',
        description: 'Confirmaciones y respuestas afirmativas',
        patterns: [
          /^(?:sí|si|yes|ok|okay|dale|perfecto)$/i,
          /^(?:exacto|correcto|así\s+es|claro)$/i,
          /^(?:por\s+supuesto|desde\s+luego)$/i
        ],
        keywords: ['si', 'yes', 'ok', 'perfecto', 'exacto', 'correcto'],
        confidence: 0.95,
        context: ['confirmacion', 'afirmacion'],
        priority: 'high'
      },

      negation: {
        name: 'negation',
        description: 'Negaciones y respuestas negativas',
        patterns: [
          /^(?:no|nope|para\s+nada)$/i,
          /^(?:ninguno|ninguna|nada)$/i,
          /^(?:incorrecto|equivocado)$/i
        ],
        keywords: ['no', 'nope', 'ninguno', 'nada', 'incorrecto'],
        confidence: 0.94,
        context: ['negacion', 'rechazo'],
        priority: 'high'
      },

      // INTENCIÓN GENÉRICA (FALLBACK)
      unknown: {
        name: 'unknown',
        description: 'Intención no identificada',
        patterns: [],
        keywords: [],
        confidence: 0.10,
        context: ['desconocido', 'generico'],
        priority: 'low'
      }
    };

    // Patrones para extracción de entidades MEJORADOS
    this.entityPatterns = {
      // Patrón principal más robusto y flexible
      products: [
        // Patrón específico para "tienes X?"
        /(?:tienes?|tienen)\s+(.+?)(?:\?|$)/i,
        // Patrón para "precio de/del X"
        /(?:precio\s+de|precio\s+del)\s+(.+)/i,
        // Patrón para "cosas/artículos para X"
        /(?:cosas|artículos|productos|elementos)\s+(?:para|de)\s+(.+)/i,
        // Patrón para búsquedas directas
        /(?:busco|necesito|quiero|cuánto\s+cuesta|hay|venden|me\s+interesa|mostrar|ver)\s+(?:ver|comprar|un|una|el|la)?\s*(.+?)(?:\s*[?.]|$)/i,
        // Patrón para libros
        /libros?\s+(?:de\s+)?(.+)/i,
        // Patrón simple de respaldo - términos específicos solos
        /^(sidur|tefilin|tallit|menorah|candelabro|torah|tanaj|kitzur|shabbat|judaismo|jumash|rashi)(?:\s+(.+))?$/i,
        // Patrón de respaldo general
        /(.+)/i
      ],
      
      // Patrones específicos mejorados
      breslov_books: /(emunah|jardín\s+de\s+la\s+(?:paz|fe)|vivamos\s+con\s+emunah|shalom\s+arush|breslov)/i,
      religious_books: /(tehilim|sidur|torah|talmud|zohar|tanaj|salmos|jumash|rashi)/i,
      ritual_items: /(tefilin|tallit|mezuzah|kipa|shofar)/i,
      reference_number: /^(?:el\s+)?([1-4]|primero|segundo|tercero|cuarto)$/i,
      quantity: /(\d+)\s*(?:unidades?|piezas?|docenas?|pares?)?/i,
      price_range: /entre\s+\$?(\d+(?:,\d{3})*)\s+y\s+\$?(\d+(?:,\d{3})*)/i,
      cities: /(bogotá|bogota|medellín|medellin|cali|barranquilla|cartagena|bucaramanga)/i,
      
      // AGREGADO: Patrones específicos para casos problemáticos identificados
      garden_of_faith: /(en\s+el\s+)?jardín\s+de\s+la\s+fe/i,
      shabbat_items: /(?:artículos?\s+(?:para\s+)?|cosas?\s+(?:para\s+)?|productos?\s+(?:para\s+)?)shabbat/i,
      jumash_with_commentary: /(jumash|chumash)\s+(?:con\s+)?(?:rashi|rashí)/i,
      tzitzit: /(tzit\s+tzit|tzitzit|zizit)/i
    };
  }

  async initialize() {
    if (this.isInitialized) return true;

    try {
      console.log('Inicializando Intent Classifier MEJORADO...');
      await this.loadDatabaseIntents();
      this.isInitialized = true;
      console.log(`Intent Classifier MEJORADO inicializado con ${Object.keys(this.intents).length} intenciones`);
      return true;
    } catch (error) {
      console.error('Error inicializando classifier:', error);
      this.isInitialized = true;
      return true;
    }
  }

  async loadDatabaseIntents() {
    try {
      const tableExists = await query("SHOW TABLES LIKE 'chatbot_intents'");
      if (tableExists.length === 0) {
        console.log('Tabla chatbot_intents no existe, usando intenciones estáticas');
        return;
      }

      const dbIntents = await query(`
        SELECT 
          intent_name,
          intent_description,
          pattern_text,
          keywords,
          confidence_threshold,
          is_active,
          priority
        FROM chatbot_intents 
        WHERE is_active = 1
        ORDER BY priority DESC
      `);

      console.log(`Cargadas ${dbIntents.length} intenciones de la BD`);

      dbIntents.forEach(intent => {
        const intentName = intent.intent_name;
        
        if (!this.intents[intentName]) {
          this.intents[intentName] = {
            name: intentName,
            description: intent.intent_description,
            patterns: [],
            keywords: [],
            confidence: intent.confidence_threshold || 0.8,
            context: [],
            priority: intent.priority || 'medium',
            dbSource: true
          };
        }

        if (intent.pattern_text) {
          try {
            const pattern = new RegExp(intent.pattern_text, 'i');
            this.intents[intentName].patterns.push(pattern);
          } catch (regexError) {
            console.warn('Patrón regex inválido:', intent.pattern_text);
          }
        }

        if (intent.keywords) {
          const keywords = intent.keywords.split(',').map(k => k.trim());
          this.intents[intentName].keywords.push(...keywords);
        }
      });

    } catch (error) {
      console.error('Error cargando intenciones de BD:', error);
    }
  }

  // Clasificación principal MEJORADA con mejor contexto
  async classify(message, userContext = {}) {
    try {
      const normalizedMessage = message.toLowerCase().trim();
      console.log(`🎯 Clasificando MENSAJE MEJORADO V2: "${normalizedMessage}"`);

      // Cache check
      const cacheKey = `intent_${normalizedMessage}_${userContext.lastIntent || ''}`;
      if (this.intentCache.has(cacheKey)) {
        const cached = this.intentCache.get(cacheKey);
        if (Date.now() - cached.timestamp < this.cacheTimeout) {
          console.log('✅ Resultado desde cache contextual');
          return cached.data;
        }
      }

      // NUEVO: Manejo de contexto conversacional mejorado
      if (userContext.lastIntent && this._shouldUseContextualClassification(normalizedMessage, userContext)) {
        const contextualResult = this._classifyWithContext(normalizedMessage, userContext);
        if (contextualResult) {
          this._cacheResult(cacheKey, contextualResult);
          console.log(`🔗 RESULTADO CONTEXTUAL: ${contextualResult.type} (${(contextualResult.confidence * 100).toFixed(1)}%)`);
          return contextualResult;
        }
      }

      // Clasificación rápida para referencias contextuales
      if (this._isProductReference(normalizedMessage)) {
        console.log('📋 Referencia de producto detectada');
        const result = {
          type: 'product_reference',
          confidence: 0.98,
          entities: { reference: this.extractReferenceNumber(normalizedMessage) },
          isQuick: true
        };
        
        this._cacheResult(cacheKey, result);
        return result;
      }

      // Clasificación principal mejorada
      const result = await this._fullClassifyImproved(normalizedMessage, userContext, message);
      this._cacheResult(cacheKey, result);
      
      console.log(`🎯 RESULTADO FINAL MEJORADO V2: ${result.type} (${(result.confidence * 100).toFixed(1)}%)`);
      
      return result;

    } catch (error) {
      console.error('Error en clasificación:', error);
      return {
        type: 'unknown',
        confidence: 0,
        entities: {},
        error: error.message
      };
    }
  }

  // NUEVO: Método para clasificación contextual
  _shouldUseContextualClassification(message, userContext) {
    // Patrones que sugieren respuesta contextual
    const contextualPatterns = [
      /^(bogotá|bogota|medellín|medellin|cali|barranquilla|cartagena|bucaramanga)$/i,
      /^(sí|si|no|ok|okay|perfecto)$/i,
      /^(ver\s+precio|ver\s+catalogo|precio|catalogo)$/i,
      /^(whatsapp)$/i
    ];
    
    return contextualPatterns.some(pattern => pattern.test(message)) && userContext.lastIntent;
  }

  _classifyWithContext(message, userContext) {
    const normalizedMessage = message.toLowerCase().trim();
    
    // Si la pregunta anterior fue sobre envíos y la respuesta es una ciudad
    if (userContext.lastIntent === 'shipping_inquiry' && 
        /^(bogotá|bogota|medellín|medellin|cali|barranquilla|cartagena|bucaramanga)$/i.test(normalizedMessage)) {
      
      return {
        type: 'shipping_context_response',
        confidence: 0.95,
        entities: { 
          city: normalizedMessage.replace(/^(medellin)$/i, 'medellín').replace(/^(bogota)$/i, 'bogotá')
        },
        contextual: true,
        basedOnContext: userContext.lastIntent
      };
    }

    // Si es un comando simple que requiere contexto
    if (/^(whatsapp)$/i.test(normalizedMessage)) {
      return {
        type: 'contact_request',
        confidence: 0.90,
        entities: { platform: 'whatsapp' },
        contextual: true
      };
    }

    // Si es un comando de ver precio/catálogo
    if (/^(ver\s+precio|precio|ver\s+catalogo|catalogo|ver\s+catálogo|catálogo)$/i.test(normalizedMessage)) {
      return {
        type: 'system_commands',
        confidence: 0.90,
        entities: { command: normalizedMessage },
        contextual: true
      };
    }

    return null;
  }

  _isProductReference(message) {
    const patterns = [
      /^(?:el\s+)?[1-4]$/,
      /^(?:el\s+)?(?:primero|segundo|tercero|cuarto)$/i,
      /^(?:ese|esa|este|esta)$/i,
      /^(?:el\s+)?último$/i
    ];
    return patterns.some(pattern => pattern.test(message));
  }

  extractReferenceNumber(message) {
    const numberMap = {
      '1': 0, 'primero': 0,
      '2': 1, 'segundo': 1,
      '3': 2, 'tercero': 2,
      '4': 3, 'cuarto': 3
    };

    const cleanMessage = message.replace(/^(?:el\s+)?/, '').trim();
    
    if (numberMap.hasOwnProperty(cleanMessage)) {
      return numberMap[cleanMessage];
    }
    
    if (cleanMessage === 'último' || cleanMessage === 'ultima') {
      return -1;
    }
    
    return 0;
  }

  // Clasificación principal MEJORADA
  async _fullClassifyImproved(message, userContext, originalMessage) {
    const intentScores = [];

    // Evaluar todas las intenciones con mejor scoring
    for (const [intentName, intentData] of Object.entries(this.intents)) {
      if (intentName === 'unknown') continue;

      const score = this._calculateIntentScoreImproved(message, intentData, userContext);
      
      if (score > 0) {
        intentScores.push({
          name: intentName,
          score,
          confidence: Math.min(score * intentData.confidence, 1.0),
          data: intentData
        });
      }
    }

    // Ordenar por confianza
    intentScores.sort((a, b) => b.confidence - a.confidence);

    let bestIntent = intentScores[0];
    
    console.log(`📊 TOP 3 INTENTS MEJORADO: ${intentScores.slice(0, 3).map(i => `${i.name}(${(i.confidence*100).toFixed(1)}%)`).join(', ')}`);
    
    if (!bestIntent || bestIntent.confidence < 0.3) {
      const specificTerms = this._containsSpecificTerms(message);
      if (specificTerms.length > 0) {
        console.log(`🔍 TÉRMINOS ESPECÍFICOS DETECTADOS: ${specificTerms.join(', ')}`);
        bestIntent = {
          name: 'specific_product_inquiry',
          confidence: 0.7,
          data: this.intents.specific_product_inquiry
        };
      } else {
        bestIntent = {
          name: 'unknown',
          confidence: 0.1,
          data: this.intents.unknown
        };
      }
    }

    const result = {
      type: bestIntent.name,
      confidence: bestIntent.confidence,
      entities: this.extractEntitiesImproved(originalMessage, bestIntent.name),
      alternatives: intentScores.slice(1, 3).map(i => ({
        type: i.name,
        confidence: i.confidence
      })),
      metadata: {
        processingMethod: 'full_improved_v2',
        totalIntentsAnalyzed: intentScores.length,
        specificTerms: this._containsSpecificTerms(message)
      }
    };

    return result;
  }

  _containsSpecificTerms(message) {
    const specificTerms = [
      // Objetos rituales
      'tefilin', 'tallit', 'mezuzah', 'kipa', 'shofar', 'menorah',
      // Libros y textos (AMPLIADO)
      'libro', 'libros', 'tehilim', 'torah', 'tanaj', 'sidur', 'talmud', 'zohar',
      'jumash', 'chumash', 'rashi', 'rashí', 'artscroll', 'kehot',
      // Breslov específicos
      'breslov', 'emunah', 'jardín', 'jardin', 'shalom', 'arush', 'najmán', 'najman',
      // Objetos ceremoniales (AMPLIADO)
      'copa', 'copas', 'kidush', 'vela', 'velas', 'candelabro', 'candelabros',
      'atril', 'mezuzah', 'tefilin', 'tzitzit', 'zizit', 'tzit',
      // Términos comerciales
      'precio', 'comprar', 'vender', 'disponible', 'stock',
      // Específicos de judaísmo (AMPLIADO)
      'shabbat', 'shabat', 'kosher', 'kasher', 'kitzur', 'halaja', 'halajá',
      'pesaj', 'januca', 'sucot', 'rosh', 'yom', 'kippur',
      // Términos de soporte y contacto (NUEVO)
      'whatsapp', 'contacto', 'asesor', 'agente', 'persona', 'catalogo', 'catálogo',
      // Ciudades (NUEVO)
      'bogotá', 'bogota', 'medellín', 'medellin', 'cali', 'barranquilla', 'cartagena', 'bucaramanga'
    ];
    
    return specificTerms.filter(term => message.toLowerCase().includes(term));
  }
  

  // Cálculo de score MEJORADO
  _calculateIntentScoreImproved(message, intentData, userContext) {
    let score = 0;

    // Puntaje por patrones (más importante y preciso)
    for (const pattern of intentData.patterns) {
      if (pattern.test(message)) {
        score += 2.0;  // Aumentado para dar más peso a coincidencias exactas
        console.log(`✅ PATRÓN MEJORADO COINCIDIÓ: ${pattern.source.substring(0, 50)}... para ${intentData.name}`);
        break; // Solo contar una coincidencia de patrón
      }
    }

    // Puntaje por palabras clave (mejorado)
    const keywordMatches = intentData.keywords.filter(keyword => 
      message.includes(keyword.toLowerCase())
    ).length;
    
    if (keywordMatches > 0) {
      score += Math.min(keywordMatches * 0.5, 1.2);  // Aumentado peso por keyword
      console.log(`📝 KEYWORDS MEJORADAS ENCONTRADAS: ${keywordMatches} para ${intentData.name}`);
    }

    // Bonus por contexto conversacional
    if (userContext.lastIntent && this._areRelatedIntents(userContext.lastIntent, intentData.name)) {
      score += 0.4;  // Aumentado
      console.log(`🔗 CONTEXTO MEJORADO RELACIONADO: ${userContext.lastIntent} -> ${intentData.name}`);
    }

    // Bonus por prioridad del intent
    const priorityBonus = {
      'highest': 0.2,
      'high': 0.1,
      'medium': 0.05,
      'low': 0
    };
    score += priorityBonus[intentData.priority] || 0;

    if (score > 0) {
      console.log(`📈 SCORE MEJORADO FINAL para ${intentData.name}: ${score.toFixed(2)}`);
    }

    return Math.min(score, 2.5);  // Límite máximo aumentado
  }

  _areRelatedIntents(lastIntent, currentIntent) {
    const relatedPairs = {
      'greeting': ['help_request', 'specific_product_inquiry'],
      'specific_product_inquiry': ['price_inquiry', 'availability_check', 'purchase_intent'],
      'price_inquiry': ['availability_check', 'purchase_intent'],
      'availability_check': ['purchase_intent', 'shipping_inquiry'],
      'shipping_inquiry': ['purchase_intent', 'payment_inquiry'],
      'purchase_intent': ['payment_inquiry', 'location_inquiry'],
      'help_request': ['specific_product_inquiry', 'price_inquiry'],
      'thanks': ['farewell'], // Añadido: agradecimiento seguido de despedida
      'farewell': ['thanks']   // Y viceversa
    };

    return relatedPairs[lastIntent]?.includes(currentIntent) || false;
  }

  // Extracción de entidades MEJORADA y más robusta
  extractEntitiesImproved(message, intentType) {
    const entities = {
      products: [],
      breslov_books: [],
      religious_books: [],
      ritual_items: [],
      cities: [],
      reference: null,
      quantities: [],
      prices: []
    };

    try {
      const normalizedMessage = message.toLowerCase();
      console.log(`📦 EXTRAYENDO ENTIDADES MEJORADAS de: "${normalizedMessage}"`);

      // Referencias numéricas
      if (intentType === 'product_reference') {
        entities.reference = this.extractReferenceNumber(normalizedMessage);
        console.log(`🔢 REFERENCIA EXTRAÍDA: ${entities.reference}`);
      }

      // Extracción de productos MEJORADA con múltiples patrones
      let productFound = false;
      
      for (const pattern of this.entityPatterns.products) {
        const productMatch = normalizedMessage.match(pattern);
        if (productMatch && productMatch[1]) {
          let productText = productMatch[1].trim();
          
          // Limpiar texto extraído de manera más inteligente
          productText = productText
            .replace(/\b(?:un|una|el|la|los|las|de|del|para|por|con|sin|\?)\b/g, '')
            .replace(/\s+/g, ' ')
            .trim();
          
          if (productText && productText.length > 1 && productText.length < 100) {
            // Evitar duplicados
            if (!entities.products.includes(productText)) {
              entities.products.push(productText);
              productFound = true;
              console.log(`✅ PRODUCTO MEJORADO EXTRAÍDO: "${productText}" con patrón: ${pattern.source.substring(0, 40)}...`);
            }
          }
        }
        
        if (productFound) break; // Salir al encontrar el primero válido
      }

      // FALLBACK mejorado: si no encuentra productos con patrones, usar términos específicos
      if (!productFound) {
        const specificTerms = this._containsSpecificTerms(normalizedMessage);
        if (specificTerms.length > 0) {
          entities.products.push(...specificTerms);
          console.log(`🔄 FALLBACK MEJORADO - TÉRMINOS CLAVE EXTRAÍDOS: ${specificTerms.join(', ')}`);
        }
      }

      // Casos especiales identificados en la conversación
      if (normalizedMessage.includes('jardin de la fe') || normalizedMessage.includes('jardín de la fe')) {
        entities.products.push('jardín de la fe');
        entities.breslov_books.push('jardín de la fe');
        console.log(`📚 LIBRO ESPECIAL IDENTIFICADO: jardín de la fe`);
      }

      if (normalizedMessage.includes('articulos') && normalizedMessage.includes('shabbat')) {
        entities.products.push('articulos para shabbat');
        console.log(`🕯️ ARTÍCULOS SHABBAT IDENTIFICADOS`);
      }

      // Libros Breslov específicos
      const breslovMatch = normalizedMessage.match(this.entityPatterns.breslov_books);
      if (breslovMatch && !entities.breslov_books.includes(breslovMatch[0])) {
        entities.breslov_books.push(breslovMatch[0]);
        console.log(`📚 LIBRO BRESLOV: ${breslovMatch[0]}`);
      }

      // Libros religiosos
      const religiousMatch = normalizedMessage.match(this.entityPatterns.religious_books);
      if (religiousMatch && !entities.religious_books.includes(religiousMatch[0])) {
        entities.religious_books.push(religiousMatch[0]);
        console.log(`📖 LIBRO RELIGIOSO: ${religiousMatch[0]}`);
      }

      // Artículos rituales
      const ritualMatch = normalizedMessage.match(this.entityPatterns.ritual_items);
      if (ritualMatch && !entities.ritual_items.includes(ritualMatch[0])) {
        entities.ritual_items.push(ritualMatch[0]);
        console.log(`🕯️ ARTÍCULO RITUAL: ${ritualMatch[0]}`);
      }

      // Ciudades (para envíos)
      const cityMatch = normalizedMessage.match(this.entityPatterns.cities);
      if (cityMatch) {
        entities.cities.push(cityMatch[1]);
        console.log(`🏙️ CIUDAD IDENTIFICADA: ${cityMatch[1]}`);
      }

      // Cantidades
      const quantityMatch = normalizedMessage.match(this.entityPatterns.quantity);
      if (quantityMatch) {
        entities.quantities.push({
          number: parseInt(quantityMatch[1]),
          unit: quantityMatch[2] || 'unidad'
        });
      }

      // Rangos de precio
      const priceMatch = normalizedMessage.match(this.entityPatterns.price_range);
      if (priceMatch) {
        entities.prices.push({
          min: parseInt(priceMatch[1].replace(',', '')),
          max: parseInt(priceMatch[2].replace(',', ''))
        });
      }

      // Limpiar entidades vacías
      Object.keys(entities).forEach(key => {
        if (Array.isArray(entities[key]) && entities[key].length === 0) {
          delete entities[key];
        }
      });

      console.log(`📦 ENTIDADES FINALES MEJORADAS EXTRAÍDAS:`, entities);
      
      return entities;

    } catch (error) {
      console.error('Error extrayendo entidades mejoradas:', error);
      return entities;
    }
  }

  _cacheResult(cacheKey, result) {
    this.intentCache.set(cacheKey, {
      data: result,
      timestamp: Date.now()
    });
  }

  clearCache() {
    this.intentCache.clear();
    console.log('Cache de intenciones limpiado');
  }

  // Método para limpiar cache expirado automáticamente
  cleanupExpiredCache() {
    const now = Date.now();
    for (const [key, value] of this.intentCache.entries()) {
      if (now - value.timestamp > this.cacheTimeout) {
        this.intentCache.delete(key);
      }
    }
  }

  getStats() {
    return {
      totalIntents: Object.keys(this.intents).length,
      cacheSize: this.intentCache.size,
      isInitialized: this.isInitialized,
      cacheTimeout: this.cacheTimeout,
      intentsByPriority: this._getIntentsByPriority(),
      version: 'v2.0_improved'
    };
  }

  _getIntentsByPriority() {
    const priorities = { highest: [], high: [], medium: [], low: [] };
    Object.values(this.intents).forEach(intent => {
      const priority = intent.priority || 'medium';
      if (priorities[priority]) {
        priorities[priority].push(intent.name);
      }
    });
    return priorities;
  }

  // NUEVO: Método de diagnóstico mejorado para debugging
  async diagnoseMessage(message) {
    console.log('=== DIAGNÓSTICO COMPLETO MEJORADO ===');
    console.log(`Mensaje: "${message}"`);
    
    const normalizedMessage = message.toLowerCase().trim();
    console.log(`Normalizado: "${normalizedMessage}"`);
    
    // Probar todos los patrones con más detalle
    for (const [intentName, intentData] of Object.entries(this.intents)) {
      if (intentName === 'unknown') continue;
      
      const score = this._calculateIntentScoreImproved(normalizedMessage, intentData, {});
      if (score > 0) {
        console.log(`${intentName}: ${score.toFixed(2)} (confianza: ${(score * intentData.confidence).toFixed(2)})`);
        
        // Mostrar qué patrones coinciden
        for (const pattern of intentData.patterns) {
          if (pattern.test(normalizedMessage)) {
            console.log(`  ✅ Patrón: ${pattern.source.substring(0, 50)}...`);
          }
        }
      }
    }
    
    // Entidades con más detalle
    const entities = this.extractEntitiesImproved(message, 'diagnostic');
    console.log('Entidades extraídas:', JSON.stringify(entities, null, 2));
    
    // Términos específicos
    const specificTerms = this._containsSpecificTerms(normalizedMessage);
    console.log('Términos específicos:', specificTerms);
    
    console.log('=== FIN DIAGNÓSTICO MEJORADO ===');
  }
}

// Función helper para crear instancia singleton
let classifierInstance = null;

export function getIntentClassifier() {
  if (!classifierInstance) {
    classifierInstance = new IntentClassifier();
  }
  return classifierInstance;
}

// Función helper para clasificación rápida
export async function quickClassify(message, context = {}) {
  const classifier = getIntentClassifier();
  await classifier.initialize();
  return await classifier.classify(message, context);
}

// Exportar por defecto
export default IntentClassifier;