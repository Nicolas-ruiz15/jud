// lib/chatbot/synonyms.js - GESTOR EXPANDIDO DE SINÓNIMOS JUDAICA BRESLOV COLOMBIA
import { query } from '../database';

export class SynonymManager {
  constructor() {
    // Cache de sinónimos para optimización
    this.synonymCache = new Map();
    this.cacheTimeout = 10 * 60 * 1000; // 10 minutos
    
    // Estado de inicialización
    this.isInitialized = false;
    
    // Sinónimos estáticos base expandidos (siempre disponibles)
    this.staticSynonyms = {
      
      // ===== OBJETOS RITUALES =====
      'tefilin': {
        primary: 'tefilin',
        variations: ['tefilín', 'tefillin', 'tfilin', 'tefelin', 'phylacteries', 'filacterias', 'tefilim'],
        related: ['cajas de rezo', 'correas', 'retzuot', 'batim', 'parshiot', 'sofer', 'pergamino', 'klaf'],
        types: ['rashi', 'rabeinu tam', 'ashkenazi', 'sefaradi', 'sefardi', 'breslov'],
        qualities: ['mehudar', 'kosher', 'simple', 'premium', 'certificado', 'artesanal', 'israelí'],
        context: ['rezo', 'oración', 'plegaria', 'mitzvah', 'religioso', 'judaico', 'ritual', 'mañana'],
        sizes: ['grande', 'pequeño', 'adulto', 'bar mitzvah'],
        materials: ['cuero', 'pergamino', 'natural']
      },

      'tallit': {
        primary: 'tallit',
        variations: ['talit', 'tallitot', 'talitot', 'tallis', 'talis', 'tzitzit', 'tzitzis', 'tzittzit'],
        related: ['manto de oración', 'prayer shawl', 'manto', 'faja', 'cordon'],
        types: ['gadol', 'katan', 'grande', 'pequeño', 'camisa', 'manto'],
        qualities: ['kosher', 'mehudar', 'premium', 'simple', 'artesanal', 'israelí', 'certificado'],
        context: ['rezo', 'sinagoga', 'shabat', 'festividades', 'oración', 'plegaria', 'ritual'],
        materials: ['lana', 'seda', 'algodón', 'acrílico', 'lino', 'hilo'],
        colors: ['blanco', 'azul', 'negro', 'tradicional'],
        sizes: ['adulto', 'niño', 'grande', 'mediano', 'pequeño']
      },

      'mezuzah': {
        primary: 'mezuzah',
        variations: ['mezuza', 'mezuzot', 'mezuzá', 'mezuza'],
        related: ['pergamino', 'klaf', 'estuche', 'caja', 'sofer', 'rollo', 'escriba', 'shema'],
        types: ['decorativa', 'simple', 'sefaradi', 'ashkenazi', 'artística', 'tradicional'],
        qualities: ['kosher', 'mehudar', 'artesanal', 'certificado', '100% kosher', 'israelí'],
        context: ['puerta', 'hogar', 'casa', 'bendición', 'protección', 'entrada', 'marco'],
        materials: ['plata', 'madera', 'metal', 'cristal', 'cerámica', 'bronce', 'aluminio'],
        sizes: ['10cm', '12cm', '15cm', 'grande', 'mediano', 'pequeño']
      },

      'kipa': {
        primary: 'kipa',
        variations: ['kipá', 'kipot', 'yarmulke', 'yarmulka', 'kippah', 'kippa', 'solideo'],
        related: ['gorro judío', 'cobertura', 'cabeza', 'respeto'],
        types: ['tejida', 'bordada', 'serigrafiada', 'personalizada', 'ceremonial', 'diaria'],
        qualities: ['artesanal', 'personalizada', 'ceremonial', 'diaria', 'elegante', 'simple'],
        context: ['cabeza', 'usar', 'llevar', 'respeto', 'tradición', 'sinagoga', 'rezo'],
        materials: ['satén', 'terciopelo', 'cuero', 'tela', 'algodón', 'seda'],
        sizes: ['adulto', 'niño', 'grande', 'mediano', 'pequeño'],
        colors: ['negro', 'blanco', 'azul', 'dorado', 'plateado', 'colorido']
      },

      'menorah': {
        primary: 'menorah',
        variations: ['menorá', 'candelabro', 'janukia', 'jánuká', 'hanukkah'],
        related: ['velas', 'luz', 'llama', 'aceite', 'candles', 'luminaria'],
        types: ['shabat', 'januca', '7 brazos', '9 brazos', 'eléctrica', 'tradicional'],
        qualities: ['elegante', 'artesanal', 'decorativa', 'ceremonial', 'premium', 'simple'],
        context: ['shabat', 'januca', 'festividad', 'ceremonia', 'luz', 'bendición', 'ritual'],
        materials: ['acero inoxidable', 'bronce', 'plata', 'madera', 'metal', 'cristal'],
        sizes: ['grande', 'mediano', 'pequeño', 'familiar', 'personal']
      },

      'shofar': {
        primary: 'shofar',
        variations: ['cuerno', 'trompeta', 'bocina'],
        related: ['toque', 'sonido', 'llamado', 'despertar'],
        types: ['carnero', 'antílope', 'kudu', 'tradicional', 'grande', 'pequeño'],
        qualities: ['kosher', 'natural', 'pulido', 'artesanal', 'certificado'],
        context: ['rosh hashana', 'festividad', 'toque', 'sonido', 'llamado', 'despertar', 'año nuevo'],
        sizes: ['grande', 'mediano', 'pequeño', '30cm', '40cm', '50cm']
      },

      // ===== LIBROS Y TEXTOS SAGRADOS =====
      'libros': {
        primary: 'libros',
        variations: ['libro', 'sefer', 'sfarim', 'sefarim', 'texto', 'textos', 'literatura'],
        related: ['lectura', 'estudio', 'enseñanza', 'sabiduría', 'conocimiento', 'aprendizaje'],
        types: ['religioso', 'espiritual', 'educativo', 'infantil', 'adulto', 'académico'],
        qualities: ['hebreo', 'español', 'bilingüe', 'comentarios', 'traducido', 'original'],
        context: ['estudio', 'lectura', 'aprendizaje', 'judaísmo', 'religión', 'biblioteca', 'librería'],
        formats: ['tapa dura', 'tapa blanda', 'digital', 'grande', 'pequeño', 'bolsillo']
      },

      'torah': {
        primary: 'torah',
        variations: ['torá', 'tora', 'pentateuco', 'cinco libros', 'sefer torah'],
        related: ['rollo', 'pergamino', 'sofer', 'escritura', 'ley', 'mandamientos'],
        types: ['completa', 'parcial', 'comentada', 'con rashi', 'interlineal', 'bilingüe'],
        qualities: ['sagrada', 'original', 'traducida', 'comentada', 'ilustrada'],
        context: ['estudio', 'lectura', 'sinagoga', 'ceremonia', 'bar mitzvah', 'bat mitzvah'],
        commentaries: ['rashi', 'ramban', 'ibn ezra', 'sforno', 'rashbam']
      },

      'tanaj': {
        primary: 'tanaj',
        variations: ['tanakh', 'biblia hebrea', 'biblia judía', 'escrituras', 'biblia original'],
        related: ['torah', 'neviim', 'ketuvim', 'profetas', 'escritos', 'salmos'],
        types: ['completo', 'parcial', 'comentado', 'bilingüe', 'hebreo-español'],
        qualities: ['original', 'traducido', 'comentado', 'ilustrado', 'académico'],
        context: ['estudio', 'lectura', 'referencia', 'consulta', 'investigación']
      },

      'talmud': {
        primary: 'talmud',
        variations: ['guemara', 'gemara', 'mishna', 'mishnah'],
        related: ['comentarios', 'discusión', 'interpretación', 'halajá', 'ley judía'],
        types: ['babilónico', 'jerusalén', 'completo', 'parcial', 'resumido'],
        qualities: ['traducido', 'comentado', 'académico', 'avanzado'],
        context: ['estudio avanzado', 'yeshiva', 'academia', 'rabinos', 'interpretación']
      },

      'sidur': {
        primary: 'sidur',
        variations: ['sidurim', 'libro de rezos', 'libro de oraciones', 'plegarias'],
        related: ['oraciones', 'rezos', 'plegarias', 'bendiciones', 'liturgia'],
        types: ['semanal', 'shabat', 'diario', 'festividades', 'ashkenazi', 'sefaradi'],
        qualities: ['completo', 'abreviado', 'bilingüe', 'fonético', 'ilustrado'],
        context: ['rezo', 'oración', 'sinagoga', 'hogar', 'viaje', 'bolsillo']
      },

      'tehilim': {
        primary: 'tehilim',
        variations: ['salmos', 'psalms', 'alabanzas', 'david hamelej'],
        related: ['david', 'rey david', 'poesía', 'cantos', 'alabanza', 'súplica'],
        types: ['completo', 'seleccionado', 'comentado', 'hebreo', 'español'],
        qualities: ['inspirador', 'espiritual', 'reconfortante', 'sagrado'],
        context: ['oración', 'meditación', 'angustia', 'alegría', 'celebración', 'duelo']
      },

      'majzorim': {
        primary: 'majzorim',
        variations: ['majzor', 'libro de festividades', 'rezo de fiestas'],
        related: ['festividades', 'fiestas', 'celebraciones', 'ceremonias'],
        types: ['rosh hashana', 'yom kipur', 'pesaj', 'sukot', 'shavuot'],
        context: ['festividades', 'fiestas judías', 'ceremonias especiales']
      },

      'zohar': {
        primary: 'zohar',
        variations: ['sefer zohar', 'libro del esplendor', 'esplendor'],
        related: ['cabala', 'kabala', 'misticismo', 'shimon bar iojai', 'secretos'],
        types: ['completo', 'resumido', 'comentado', 'traducido'],
        qualities: ['místico', 'espiritual', 'profundo', 'sagrado'],
        context: ['cabala', 'misticismo', 'estudio avanzado', 'espiritualidad']
      },

      // ===== BRESLOV Y MAESTROS =====
      'breslov': {
        primary: 'breslov',
        variations: ['breslev', 'breslau', 'bresloer'],
        related: ['rabi najman', 'rabino najman', 'shalom arush', 'jasidismo', 'jasídico'],
        types: ['enseñanzas', 'libros', 'música', 'meditación', 'tikun'],
        qualities: ['auténtico', 'inspirador', 'espiritual', 'transformador'],
        context: ['movimiento', 'jasidismo', 'espiritualidad', 'alegría', 'esperanza', 'fe']
      },

      'shalom_arush': {
        primary: 'shalom arush',
        variations: ['rabino arush', 'rab arush', 'shalom arush', 'arush'],
        related: ['breslov', 'enseñanzas', 'libros', 'conferencias', 'israel'],
        types: ['libros', 'audio', 'conferencias', 'enseñanzas'],
        qualities: ['contemporáneo', 'inspirador', 'práctico', 'espiritual'],
        context: ['maestro', 'rabino', 'breslov', 'enseñanzas', 'espiritualidad']
      },

      'najman': {
        primary: 'rabi najman',
        variations: ['rabino najman', 'najman de breslov', 'nachman', 'nahman'],
        related: ['breslov', 'fundador', 'enseñanzas', 'cuentos', 'historias'],
        types: ['biografía', 'enseñanzas', 'cuentos', 'plegarias'],
        qualities: ['santo', 'sabio', 'inspirador', 'revolucionario'],
        context: ['fundador', 'maestro', 'breslov', 'jasidismo', 'espiritualidad']
      },

      // ===== FESTIVIDADES =====
      'shabat': {
        primary: 'shabat',
        variations: ['shabbat', 'sábado', 'día de descanso'],
        related: ['velas', 'kidush', 'jalá', 'havdalá', 'candelabros', 'copa'],
        types: ['entrada', 'salida', 'ceremonia', 'cena', 'almuerzo'],
        qualities: ['sagrado', 'especial', 'familiar', 'tradicional', 'ceremonial'],
        context: ['descanso', 'familia', 'oración', 'cena', 'celebración', 'tradición'],
        items: ['velas', 'copa kidush', 'jalá', 'mantel', 'candelabros']
      },

      'rosh_hashana': {
        primary: 'rosh hashana',
        variations: ['año nuevo judío', 'rosh hashaná', 'cabeza del año'],
        related: ['shofar', 'manzana', 'miel', 'dulce', 'renovación', 'teshuvá'],
        types: ['ceremonia', 'celebración', 'rezo', 'cena'],
        context: ['año nuevo', 'reflexión', 'renovación', 'perdón', 'esperanza']
      },

      'yom_kipur': {
        primary: 'yom kipur',
        variations: ['día del perdón', 'día de expiación'],
        related: ['ayuno', 'perdón', 'teshuvá', 'rezo', 'arrepentimiento'],
        types: ['ayuno', 'rezo', 'ceremonia', 'reflexión'],
        context: ['perdón', 'ayuno', 'reflexión', 'arrepentimiento', 'purificación']
      },

      'pesaj': {
        primary: 'pesaj',
        variations: ['pascua judía', 'pascua', 'pesach'],
        related: ['seder', 'hagadá', 'matzá', 'libertad', 'éxodo', 'esclavitud'],
        types: ['seder', 'ceremonia', 'cena', 'celebración'],
        context: ['libertad', 'éxodo', 'familia', 'tradición', 'historia']
      },

      'januca': {
        primary: 'januca',
        variations: ['janucá', 'hanukkah', 'festa de las luces', 'dedicación'],
        related: ['menorah', 'velas', 'luz', 'milagro', 'aceite', 'janukia'],
        types: ['ceremonia', 'celebración', 'encendido'],
        context: ['luz', 'milagro', 'dedicación', 'templo', 'resistencia']
      },

      'purim': {
        primary: 'purim',
        variations: ['festa de purim', 'meguilá'],
        related: ['ester', 'mardoqueo', 'hamán', 'meguilá', 'disfraces'],
        types: ['lectura', 'celebración', 'festa', 'disfraces'],
        context: ['salvación', 'alegría', 'celebración', 'milagro', 'ester']
      },

      'sukot': {
        primary: 'sukot',
        variations: ['festa de los tabernáculos', 'cabañas', 'sukkah'],
        related: ['etrog', 'lulav', 'cabaña', 'sukkah', 'cuatro especies'],
        types: ['construcción', 'ceremonia', 'celebración'],
        context: ['cosecha', 'naturaleza', 'temporalidad', 'protección', 'desierto']
      },

      // ===== VELAS Y ILUMINACIÓN =====
      'velas': {
        primary: 'velas',
        variations: ['vela', 'candela', 'nerot', 'luz', 'llama'],
        related: ['candelabro', 'menorah', 'luz', 'bendición', 'ceremonia'],
        types: ['shabat', 'havdalá', 'januca', 'yahrzeit', 'memorial'],
        qualities: ['kosher', 'cera', 'parafina', 'larga duración', 'sin goteo'],
        context: ['ceremonia', 'bendición', 'luz', 'festividad', 'memoria'],
        colors: ['blanco', 'azul', 'multicolor', 'natural'],
        sizes: ['corta', 'larga', 'mediana', 'gruesa', 'fina']
      },

      'kidush': {
        primary: 'kidush',
        variations: ['copa de kidush', 'copa', 'cáliz', 'kiddush'],
        related: ['vino', 'bendición', 'shabat', 'festividad', 'santificación'],
        types: ['copa', 'cáliz', 'recipiente'],
        qualities: ['plata', 'metal', 'cristal', 'elegante', 'ceremonial'],
        context: ['bendición', 'vino', 'shabat', 'festividad', 'ceremonia'],
        materials: ['plata', 'vidrio', 'metal', 'cristal', 'cerámica']
      },

      // ===== VINOS Y ALIMENTOS KOSHER =====
      'vino': {
        primary: 'vino',
        variations: ['vinos', 'wine', 'mosto'],
        related: ['kosher', 'kidush', 'ceremonia', 'bendición', 'festividad'],
        types: ['tinto', 'blanco', 'dulce', 'seco', 'espumoso', 'reserva'],
        qualities: ['kosher', 'mevushal', 'certificado', 'importado', 'nacional'],
        context: ['kidush', 'shabat', 'festividad', 'ceremonia', 'bendición'],
        brands: ['manischewitz', 'carmel', 'golan', 'castel'],
        supervision: ['vaad hakashrut', 'certificado', 'supervisado']
      },

      'kosher': {
        primary: 'kosher',
        variations: ['kasher', 'kashrut', 'apto', 'permitido'],
        related: ['halal', 'supervisión', 'certificación', 'rabínico', 'kashrut'],
        types: ['carne', 'lácteo', 'parve', 'pesaj', 'regular'],
        qualities: ['certificado', 'supervisado', 'verificado', 'auténtico'],
        context: ['alimentación', 'leyes', 'religión', 'tradicional', 'permitido']
      },

      // ===== JOYERÍA Y ACCESORIOS =====
      'joyeria': {
        primary: 'joyería',
        variations: ['joyas', 'accesorios', 'adornos', 'ornamentos'],
        related: ['collar', 'pulsera', 'anillo', 'colgante', 'pendientes'],
        types: ['religiosa', 'ceremonial', 'decorativa', 'simbólica'],
        qualities: ['plata', 'oro', 'artesanal', 'elegante', 'fina'],
        context: ['regalo', 'ceremonia', 'celebración', 'identidad', 'tradición'],
        symbols: ['estrella david', 'jai', 'hamsa', 'jerusalén', 'torah']
      },

      'hamsa': {
        primary: 'hamsa',
        variations: ['mano de fátima', 'mano', 'jamsa'],
        related: ['protección', 'amuleto', 'bendición', 'suerte'],
        types: ['colgante', 'decorativo', 'pared', 'llavero'],
        qualities: ['protector', 'decorativo', 'simbólico', 'tradicional'],
        context: ['protección', 'hogar', 'familia', 'bendición', 'suerte']
      },

      // ===== TÉRMINOS DE COMPRA Y SERVICIO =====
      'buscar': {
        primary: 'buscar',
        variations: ['busco', 'buscando', 'encontrar', 'ver', 'mostrar', 'enseñar', 'localizar'],
        related: ['necesito', 'quiero', 'deseo', 'me interesa', 'requiero'],
        context: ['producto', 'información', 'ayuda', 'catálogo', 'inventario']
      },

      'comprar': {
        primary: 'comprar',
        variations: ['compro', 'comprando', 'adquirir', 'conseguir', 'obtener', 'pedir'],
        related: ['precio', 'costo', 'valor', 'pagar', 'método de pago', 'pedido'],
        context: ['proceso', 'forma', 'cómo', 'dónde', 'online', 'tienda']
      },

      'precio': {
        primary: 'precio',
        variations: ['costo', 'valor', 'tarifa', 'monto', 'importe'],
        related: ['pesos', 'dólares', 'económico', 'barato', 'caro', 'descuento'],
        context: ['consulta', 'información', 'comparación', 'presupuesto']
      },

      'envio': {
        primary: 'envío',
        variations: ['envíos', 'entrega', 'despacho', 'shipping', 'transporte'],
        related: ['gratis', 'rápido', 'colombia', 'bogotá', 'domicilio'],
        types: ['express', 'normal', 'gratis', 'rápido', 'nacional'],
        context: ['entrega', 'domicilio', 'colombia', 'tiempo', 'costo']
      },

      // ===== TÉRMINOS GEOGRÁFICOS Y COMUNIDAD =====
      'colombia': {
        primary: 'colombia',
        variations: ['colombiano', 'colombiana', 'nacional'],
        related: ['bogotá', 'medellín', 'barranquilla', 'cali', 'país'],
        context: ['envío', 'comunidad', 'local', 'nacional', 'tienda']
      },

      'bogota': {
        primary: 'bogotá',
        variations: ['bogota', 'capital', 'distrito'],
        related: ['colombia', 'comunidad judía', 'sinagoga', 'centro'],
        context: ['envío', 'entrega', 'comunidad', 'local', 'tienda']
      },

      'comunidad': {
        primary: 'comunidad',
        variations: ['comunidad judía', 'judíos', 'hebreos', 'israelitas'],
        related: ['sinagoga', 'tradición', 'cultura', 'religión', 'identidad'],
        types: ['sefaradi', 'ashkenazi', 'breslov', 'jabad', 'ortodoxa'],
        context: ['tradición', 'cultura', 'religión', 'identidad', 'pertenencia']
      },

      'sefardi': {
        primary: 'sefaradí',
        variations: ['sefardí', 'sefardita', 'sefardim', 'sefarad'],
        related: ['españa', 'tradición', 'costumbres', 'ritus'],
        context: ['tradición', 'costumbres', 'comunidad', 'origen', 'cultura']
      },

      'ashkenazi': {
        primary: 'ashkenazi',
        variations: ['ashkenazí', 'ashkenazim'],
        related: ['europa', 'tradición', 'costumbres', 'ritus'],
        context: ['tradición', 'costumbres', 'comunidad', 'origen', 'cultura']
      },

      // ===== TÉRMINOS DE CORTESÍA Y COMUNICACIÓN =====
      'hola': {
        primary: 'hola',
        variations: ['hola', 'buenos días', 'buenas tardes', 'buenas noches', 'saludos'],
        related: ['shalom', 'paz', 'bienvenido', 'saludo'],
        context: ['saludo', 'cortesía', 'inicio', 'bienvenida']
      },

      'shalom': {
        primary: 'shalom',
        variations: ['paz', 'saludo', 'despedida'],
        related: ['hola', 'adiós', 'paz', 'tranquilidad'],
        context: ['saludo', 'despedida', 'paz', 'bendición']
      },

      'gracias': {
        primary: 'gracias',
        variations: ['muchas gracias', 'agradezco', 'agradecimiento'],
        related: ['todá', 'toda raba', 'bendición'],
        context: ['agradecimiento', 'cortesía', 'reconocimiento']
      },

      'ayuda': {
        primary: 'ayuda',
        variations: ['ayudar', 'asistencia', 'soporte', 'apoyo'],
        related: ['consulta', 'pregunta', 'información', 'asesoría'],
        context: ['servicio', 'atención', 'soporte', 'consulta']
      },

      // ===== TÉRMINOS ESPECÍFICOS ADICIONALES =====
      'mehudar': {
        primary: 'mehudar',
        variations: ['mehudarim', 'hermoseado', 'embellecido', 'premium'],
        related: ['calidad', 'belleza', 'especial', 'selecto', 'fino'],
        context: ['calidad superior', 'ceremonial', 'especial', 'selecto']
      },

      'sofer': {
        primary: 'sofer',
        variations: ['sofrim', 'escriba', 'escritor'],
        related: ['pergamino', 'klaf', 'escritura', 'torah', 'mezuzah', 'tefilin'],
        context: ['escritura sagrada', 'artesano', 'tradicional', 'experto']
      },

      'klaf': {
        primary: 'klaf',
        variations: ['pergamino', 'cuero', 'piel'],
        related: ['sofer', 'escritura', 'torah', 'mezuzah', 'tefilin'],
        context: ['material sagrado', 'escritura', 'tradicional', 'kosher']
      },

      'tzedaka': {
        primary: 'tzedaká',
        variations: ['tzedaka', 'caridad', 'justicia', 'donación'],
        related: ['caja', 'recipiente', 'donación', 'ayuda', 'solidaridad'],
        context: ['caridad', 'donación', 'ayuda', 'justicia', 'mitzvah']
      },

      'netilat': {
        primary: 'netilat yadaim',
        variations: ['lavado de manos', 'netilat', 'purificación'],
        related: ['jarra', 'recipiente', 'agua', 'purificación', 'ritual'],
        context: ['purificación', 'ritual', 'limpieza', 'bendición']
      },

      'havdala': {
        primary: 'havdalá',
        variations: ['havdala', 'separación', 'distinción'],
        related: ['vela', 'copa', 'especias', 'ceremonia', 'shabat'],
        context: ['ceremonia', 'separación', 'final shabat', 'distinción']
      },

      'jala': {
        primary: 'jalá',
        variations: ['jala', 'pan trenzado', 'pan sabbath'],
        related: ['pan', 'trenzado', 'sabbath', 'bendición', 'cena'],
        context: ['sabbath', 'pan ceremonial', 'bendición', 'cena']
      },

      // ===== INFANTILES Y EDUCACIÓN =====
      'infantil': {
        primary: 'infantil',
        variations: ['niños', 'niño', 'niña', 'pequeños', 'bebé'],
        related: ['educativo', 'didáctico', 'enseñanza', 'aprendizaje'],
        context: ['educación', 'enseñanza', 'niños', 'familia', 'tradición']
      },

      'educativo': {
        primary: 'educativo',
        variations: ['didáctico', 'enseñanza', 'aprendizaje', 'pedagógico'],
        related: ['niños', 'escuela', 'casa', 'familia', 'tradición'],
        context: ['educación', 'enseñanza', 'aprendizaje', 'formación']
      },

      // ===== TÉRMINOS DE FESTIVIDADES ESPECÍFICAS =====
      'meguilat': {
        primary: 'meguilat ester',
        variations: ['meguilá', 'libro de ester', 'rollo de ester'],
        related: ['ester', 'purim', 'lectura', 'rollo', 'pergamino'],
        context: ['purim', 'lectura', 'festividad', 'historia', 'salvación']
      },

      'etrog': {
        primary: 'etrog',
        variations: ['cidra', 'fruto cítrico'],
        related: ['sukot', 'cuatro especies', 'lulav', 'hadás', 'aravá'],
        context: ['sukot', 'festividad', 'ritual', 'bendición']
      },

      'lulav': {
        primary: 'lulav',
        variations: ['rama de palmera', 'palma'],
        related: ['sukot', 'cuatro especies', 'etrog', 'hadás', 'aravá'],
        context: ['sukot', 'festividad', 'ritual', 'bendición']
      }
    };

    // Sinónimos cargados desde BD
    this.synonyms = { ...this.staticSynonyms };
  }

  /**
   * Inicialización del manager - CORREGIDA
   */
  async initialize() {
    if (this.isInitialized) {
      return true;
    }

    try {
      console.log('🔄 Inicializando Synonym Manager...');
      await this.loadDatabaseSynonyms();
      this.isInitialized = true;
      console.log('✅ Synonym Manager inicializado');
      return true;
    } catch (error) {
      console.error('❌ Error inicializando sinónimos:', error);
      // Usar solo sinónimos estáticos si falla la BD
      this.synonyms = { ...this.staticSynonyms };
      this.isInitialized = true;
      console.log('⚠️ Usando solo sinónimos estáticos');
      return true;
    }
  }

  /**
   * Cargar sinónimos desde la base de datos - CORREGIDO
   */
  async loadDatabaseSynonyms() {
    try {
      // Verificar si la tabla existe
      const tableExists = await query("SHOW TABLES LIKE 'product_synonyms'");
      if (tableExists.length === 0) {
        console.log('⚠️ Tabla product_synonyms no existe, usando sinónimos estáticos');
        return;
      }

      const dbSynonyms = await query(`
        SELECT 
          ps.base_term,
          ps.synonym,
          ps.language,
          ps.context,
          ps.priority,
          ps.is_active
        FROM product_synonyms ps
        WHERE ps.is_active = 1
        ORDER BY ps.priority DESC, ps.base_term ASC
      `);

      console.log(`📚 Cargados ${dbSynonyms.length} sinónimos de la BD`);

      // Procesar sinónimos de BD
      const processedSynonyms = {};
      
      dbSynonyms.forEach(syn => {
        const term = syn.base_term.toLowerCase();
        
        if (!processedSynonyms[term]) {
          processedSynonyms[term] = {
            primary: term,
            variations: [],
            related: [],
            context: [],
            dbSource: true
          };
        }

        // Agregar sinónimo
        const synonymTerm = syn.synonym.toLowerCase();
        if (!processedSynonyms[term].variations.includes(synonymTerm)) {
          processedSynonyms[term].variations.push(synonymTerm);
        }

        // Agregar contexto si existe
        if (syn.context && !processedSynonyms[term].context.includes(syn.context)) {
          processedSynonyms[term].context.push(syn.context);
        }
      });

      // Merge con sinónimos estáticos
      this.synonyms = { ...this.staticSynonyms, ...processedSynonyms };
      
      console.log(`🔗 Total sinónimos disponibles: ${Object.keys(this.synonyms).length}`);

    } catch (error) {
      console.error('❌ Error cargando sinónimos de BD:', error);
      throw error;
    }
  }

  /**
   * Expandir sinónimos en un texto - CORREGIDO
   */
  async expandSynonyms(text) {
    try {
      // Asegurar inicialización
      if (!this.isInitialized) {
        await this.initialize();
      }

      if (!text || typeof text !== 'string') {
        return '';
      }

      const words = text.toLowerCase().split(/\s+/);
      const expandedTerms = new Set();
      
      // Agregar términos originales
      words.forEach(word => {
        if (word.trim()) {
          expandedTerms.add(word.trim());
        }
      });
      
      // Buscar sinónimos para cada palabra y frases compuestas
      for (let i = 0; i < words.length; i++) {
        const word = words[i].trim();
        if (!word) continue;
        
        // Buscar palabra individual
        const synonymData = await this.getSynonymsForTerm(word);
        if (synonymData) {
          // Agregar variaciones más relevantes
          synonymData.variations?.slice(0, 3).forEach(syn => expandedTerms.add(syn));
          synonymData.related?.slice(0, 2).forEach(rel => expandedTerms.add(rel));
        }

        // Buscar frases compuestas (2 palabras)
        if (i < words.length - 1) {
          const phrase = `${word} ${words[i + 1]}`;
          const phraseData = await this.getSynonymsForTerm(phrase);
          if (phraseData) {
            phraseData.variations?.slice(0, 2).forEach(syn => expandedTerms.add(syn));
          }
        }
      }

      return Array.from(expandedTerms).join(' ');

    } catch (error) {
      console.error('❌ Error expandiendo sinónimos:', error);
      return text || '';
    }
  }

  /**
   * Obtener sinónimos específicos para un término - CORREGIDO
   */
  async getSynonymsForTerm(term) {
    try {
      if (!term || typeof term !== 'string') {
        return null;
      }

      const normalizedTerm = term.toLowerCase().trim();
      if (!normalizedTerm) {
        return null;
      }
      
      // Verificar cache
      const cacheKey = `synonym_${normalizedTerm}`;
      if (this.synonymCache.has(cacheKey)) {
        const cached = this.synonymCache.get(cacheKey);
        if (Date.now() - cached.timestamp < this.cacheTimeout) {
          return cached.data;
        }
      }

      // Buscar sinónimo exacto
      let synonymData = this.synonyms[normalizedTerm];

      // Si no se encuentra exacto, buscar coincidencias parciales
      if (!synonymData) {
        for (const [key, data] of Object.entries(this.synonyms)) {
          if (key.includes(normalizedTerm) || normalizedTerm.includes(key)) {
            synonymData = data;
            break;
          }
          
          if (data.variations?.some(v => v.includes(normalizedTerm) || normalizedTerm.includes(v))) {
            synonymData = data;
            break;
          }
        }
      }

      // Guardar en cache
      this.synonymCache.set(cacheKey, {
        data: synonymData,
        timestamp: Date.now()
      });

      return synonymData;

    } catch (error) {
      console.error('❌ Error obteniendo sinónimos para término:', error);
      return null;
    }
  }

  /**
   * Obtener sinónimos específicos de productos - CORREGIDO
   */
  async getProductSynonyms(productTerm) {
    try {
      if (!productTerm || typeof productTerm !== 'string') {
        return [productTerm || ''];
      }

      const synonymData = await this.getSynonymsForTerm(productTerm);
      
      if (synonymData) {
        return [
          synonymData.primary,
          ...synonymData.variations || [],
          ...synonymData.related?.slice(0, 3) || [],
          ...synonymData.types?.slice(0, 2) || []
        ].filter(Boolean);
      }

      // Fallback: buscar en BD si está disponible
      try {
        const tableExists = await query("SHOW TABLES LIKE 'product_synonyms'");
        if (tableExists.length > 0) {
          const dbResults = await query(`
            SELECT DISTINCT synonym 
            FROM product_synonyms ps
            WHERE (
              LOWER(ps.base_term) LIKE ? OR 
              LOWER(ps.synonym) LIKE ?
            ) AND ps.is_active = 1
            LIMIT 15
          `, [`%${productTerm.toLowerCase()}%`, `%${productTerm.toLowerCase()}%`]);

          if (dbResults.length > 0) {
            return [productTerm, ...dbResults.map(r => r.synonym)];
          }
        }
      } catch (dbError) {
        console.log('⚠️ Error en búsqueda de sinónimos de BD:', dbError.message);
      }

      return [productTerm];

    } catch (error) {
      console.error('❌ Error en getProductSynonyms:', error);
      return [productTerm || ''];
    }
  }

  /**
   * Detectar categorías mencionadas en el texto - EXPANDIDO
   */
  async detectCategories(text) {
    try {
      if (!text || typeof text !== 'string') {
        return [];
      }

      const categories = [];
      const normalizedText = text.toLowerCase();

      const categoryMap = {
        'libros': ['libro', 'libros', 'sefer', 'sfarim', 'texto', 'lectura', 'estudio', 'torah', 'tanaj', 'talmud', 'sidur', 'tehilim'],
        'tefilin': ['tefilin', 'tefilín', 'phylacteries', 'filacterias', 'rezo', 'cajas de rezo'],
        'tallitot': ['tallit', 'talit', 'manto', 'tzitzit', 'prayer shawl', 'tzitzis'],
        'mezuzot': ['mezuzah', 'mezuza', 'pergamino', 'puerta', 'hogar', 'klaf', 'rollo'],
        'kipot': ['kipa', 'kipá', 'yarmulke', 'gorro', 'cabeza', 'solideo'],
        'velas': ['vela', 'velas', 'candela', 'nerot', 'shabat', 'luz', 'havdala'],
        'vinos': ['vino', 'vinos', 'kosher', 'kidush', 'manischewitz', 'ceremonial'],
        'menorah': ['menorah', 'menorá', 'candelabro', 'januca', 'luz', 'brazos'],
        'joyeria': ['joyería', 'joyas', 'collar', 'pulsera', 'anillo', 'colgante'],
        'breslov': ['breslov', 'breslev', 'najman', 'shalom arush', 'jasídico'],
        'festividades': ['shabat', 'pesaj', 'januca', 'purim', 'rosh hashana', 'sukot'],
        'infantil': ['infantil', 'niños', 'educativo', 'didáctico', 'pequeños']
      };

      for (const [category, keywords] of Object.entries(categoryMap)) {
        if (keywords.some(keyword => normalizedText.includes(keyword))) {
          categories.push(category);
        }
      }

      return categories;

    } catch (error) {
      console.error('❌ Error detectando categorías:', error);
      return [];
    }
  }

  /**
   * Detectar productos específicos mencionados - EXPANDIDO
   */
  async detectProducts(text) {
    try {
      if (!text || typeof text !== 'string') {
        return [];
      }

      const products = [];
      const normalizedText = text.toLowerCase();

      for (const [product, data] of Object.entries(this.synonyms)) {
        if (normalizedText.includes(product)) {
          products.push(product);
          continue;
        }

        if (data.variations?.some(variation => normalizedText.includes(variation))) {
          products.push(product);
          continue;
        }

        if (data.related?.some(related => normalizedText.includes(related))) {
          products.push(product);
          continue;
        }

        if (data.types?.some(type => normalizedText.includes(type))) {
          products.push(product);
        }
      }

      return [...new Set(products)];

    } catch (error) {
      console.error('❌ Error detectando productos:', error);
      return [];
    }
  }

  /**
   * Detectar intención del usuario - NUEVA FUNCIÓN
   */
  async detectIntent(text) {
    try {
      if (!text || typeof text !== 'string') {
        return 'unknown';
      }

      const normalizedText = text.toLowerCase();

      // Intenciones de compra
      const buyIntents = ['comprar', 'compro', 'adquirir', 'conseguir', 'precio', 'costo', 'cuanto'];
      if (buyIntents.some(intent => normalizedText.includes(intent))) {
        return 'buy';
      }

      // Intenciones de búsqueda
      const searchIntents = ['buscar', 'busco', 'encontrar', 'ver', 'mostrar', 'hay'];
      if (searchIntents.some(intent => normalizedText.includes(intent))) {
        return 'search';
      }

      // Intenciones de información
      const infoIntents = ['que es', 'para que', 'como', 'cuando', 'donde', 'explicar'];
      if (infoIntents.some(intent => normalizedText.includes(intent))) {
        return 'info';
      }

      // Intenciones de saludo
      const greetIntents = ['hola', 'buenos', 'buenas', 'shalom', 'saludos'];
      if (greetIntents.some(intent => normalizedText.includes(intent))) {
        return 'greeting';
      }

      // Intenciones de agradecimiento
      const thankIntents = ['gracias', 'agradezco', 'muchas gracias'];
      if (thankIntents.some(intent => normalizedText.includes(intent))) {
        return 'thanks';
      }

      return 'general';

    } catch (error) {
      console.error('❌ Error detectando intención:', error);
      return 'unknown';
    }
  }

  /**
   * Agregar nuevos sinónimos dinámicamente - CORREGIDO
   */
  async addSynonym(baseTerm, synonymTerm, context = 'general') {
    try {
      if (!baseTerm || !synonymTerm) {
        console.warn('⚠️ Términos base y sinónimo son requeridos');
        return false;
      }

      // Verificar si la tabla existe antes de insertar
      const tableExists = await query("SHOW TABLES LIKE 'product_synonyms'");
      if (tableExists.length === 0) {
        console.warn('⚠️ Tabla product_synonyms no existe, agregando solo a memoria');
        
        // Agregar solo a memoria
        const normalizedProduct = baseTerm.toLowerCase();
        if (!this.synonyms[normalizedProduct]) {
          this.synonyms[normalizedProduct] = {
            primary: normalizedProduct,
            variations: [],
            related: [],
            context: []
          };
        }

        if (!this.synonyms[normalizedProduct].variations.includes(synonymTerm)) {
          this.synonyms[normalizedProduct].variations.push(synonymTerm);
        }

        console.log(`✅ Sinónimo agregado en memoria: ${baseTerm} -> ${synonymTerm}`);
        return true;
      }

      await query(`
        INSERT INTO product_synonyms 
        (base_term, synonym, language, context, priority, is_active)
        VALUES (?, ?, 'es', ?, 5, 1)
        ON DUPLICATE KEY UPDATE
          synonym = VALUES(synonym),
          updated_at = NOW()
      `, [baseTerm, synonymTerm, context]);

      // Actualizar cache local
      const normalizedProduct = baseTerm.toLowerCase();
      if (!this.synonyms[normalizedProduct]) {
        this.synonyms[normalizedProduct] = {
          primary: normalizedProduct,
          variations: [],
          related: [],
          context: []
        };
      }

      if (!this.synonyms[normalizedProduct].variations.includes(synonymTerm)) {
        this.synonyms[normalizedProduct].variations.push(synonymTerm);
      }

      console.log(`✅ Sinónimo agregado: ${baseTerm} -> ${synonymTerm}`);
      return true;

    } catch (error) {
      console.error('❌ Error agregando sinónimo:', error);
      return false;
    }
  }

  /**
   * Pre-cargar sinónimos más comunes - EXPANDIDO
   */
  async preloadCommonSynonyms() {
    const commonTerms = [
      'tefilin', 'tallit', 'mezuzah', 'libros', 'kipa', 'menorah', 'velas',
      'precio', 'comprar', 'kosher', 'gracias', 'hola', 'shalom',
      'breslov', 'najman', 'shalom arush', 'sidur', 'tehilim', 'torah',
      'shabat', 'januca', 'pesaj', 'vino', 'colombia', 'bogota'
    ];

    console.log('🔥 Pre-cargando sinónimos comunes...');
    
    let loadedCount = 0;
    for (const term of commonTerms) {
      try {
        await this.getSynonymsForTerm(term);
        loadedCount++;
      } catch (error) {
        console.warn(`⚠️ Error pre-cargando sinónimo para ${term}:`, error.message);
      }
    }

    console.log(`✅ Pre-cargados sinónimos para ${loadedCount}/${commonTerms.length} términos`);
  }

  /**
   * Limpiar cache de sinónimos
   */
  clearCache() {
    this.synonymCache.clear();
    console.log('🧹 Cache de sinónimos limpiado');
  }

  /**
   * Obtener estadísticas del manager - EXPANDIDO
   */
  getStats() {
    return {
      totalSynonyms: Object.keys(this.synonyms).length,
      cacheSize: this.synonymCache.size,
      staticSynonyms: Object.keys(this.staticSynonyms).length,
      dbSynonyms: Object.keys(this.synonyms).length - Object.keys(this.staticSynonyms).length,
      isInitialized: this.isInitialized,
      categories: {
        objects: ['tefilin', 'tallit', 'mezuzah', 'kipa', 'menorah', 'shofar'].length,
        books: ['libros', 'torah', 'tanaj', 'talmud', 'sidur', 'tehilim'].length,
        festivals: ['shabat', 'rosh_hashana', 'yom_kipur', 'pesaj', 'januca', 'purim', 'sukot'].length,
        community: ['breslov', 'colombia', 'bogota', 'sefardi', 'ashkenazi'].length
      }
    };
  }

  /**
   * Buscar sinónimos similares - CORREGIDO
   */
  findSimilarSynonyms(term, threshold = 0.7) {
    try {
      if (!term || typeof term !== 'string') {
        return [];
      }

      const similar = [];
      const normalizedTerm = term.toLowerCase();

      for (const [key, data] of Object.entries(this.synonyms)) {
        const similarity = this.calculateSimilarity(normalizedTerm, key);
        
        if (similarity >= threshold) {
          similar.push({
            term: key,
            similarity,
            data,
            category: this.getCategoryForTerm(key)
          });
        }
      }

      return similar.sort((a, b) => b.similarity - a.similarity);

    } catch (error) {
      console.error('❌ Error buscando sinónimos similares:', error);
      return [];
    }
  }

  /**
   * Obtener categoría para un término - NUEVA FUNCIÓN
   */
  getCategoryForTerm(term) {
    const categories = {
      'objetos_rituales': ['tefilin', 'tallit', 'mezuzah', 'kipa', 'menorah', 'shofar'],
      'libros': ['libros', 'torah', 'tanaj', 'talmud', 'sidur', 'tehilim', 'zohar'],
      'festividades': ['shabat', 'rosh_hashana', 'yom_kipur', 'pesaj', 'januca', 'purim', 'sukot'],
      'breslov': ['breslov', 'najman', 'shalom_arush'],
      'velas_luz': ['velas', 'menorah', 'kidush', 'havdala'],
      'comunidad': ['colombia', 'bogota', 'sefardi', 'ashkenazi', 'comunidad'],
      'comercial': ['buscar', 'comprar', 'precio', 'envio']
    };

    for (const [category, terms] of Object.entries(categories)) {
      if (terms.includes(term)) {
        return category;
      }
    }

    return 'general';
  }

  /**
   * Calcular similitud entre dos strings
   */
  calculateSimilarity(str1, str2) {
    try {
      if (!str1 || !str2) return 0;
      
      const longer = str1.length > str2.length ? str1 : str2;
      const shorter = str1.length > str2.length ? str2 : str1;
      
      if (longer.length === 0) return 1.0;
      
      const distance = this.levenshteinDistance(longer, shorter);
      return (longer.length - distance) / longer.length;
    } catch (error) {
      console.error('❌ Error calculando similitud:', error);
      return 0;
    }
  }

  /**
   * Calcular distancia de Levenshtein
   */
  levenshteinDistance(str1, str2) {
    try {
      if (!str1 || !str2) return Math.max(str1?.length || 0, str2?.length || 0);

      const matrix = [];

      for (let i = 0; i <= str2.length; i++) {
        matrix[i] = [i];
      }

      for (let j = 0; j <= str1.length; j++) {
        matrix[0][j] = j;
      }

      for (let i = 1; i <= str2.length; i++) {
        for (let j = 1; j <= str1.length; j++) {
          if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
            matrix[i][j] = matrix[i - 1][j - 1];
          } else {
            matrix[i][j] = Math.min(
              matrix[i - 1][j - 1] + 1,
              matrix[i][j - 1] + 1,
              matrix[i - 1][j] + 1
            );
          }
        }
      }

      return matrix[str2.length][str1.length];
    } catch (error) {
      console.error('❌ Error calculando distancia Levenshtein:', error);
      return 999; // Valor alto en caso de error
    }
  }
}