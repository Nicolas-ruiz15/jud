// lib/chatbot/nlp-utils-advanced.js - SISTEMA NLP PROFESIONAL COMPLETO
export class AdvancedNLPUtils {
  constructor() {
    // Palabras vacías multiidioma expandidas
    this.stopWords = {
      spanish: new Set([
        'el', 'la', 'de', 'que', 'y', 'a', 'en', 'un', 'es', 'se', 'no', 'te', 'lo', 'le',
        'da', 'su', 'por', 'son', 'con', 'para', 'al', 'del', 'los', 'las', 'una', 'sobre',
        'todo', 'también', 'tras', 'otro', 'algún', 'alguna', 'hasta', 'había', 'sido',
        'está', 'estoy', 'estar', 'tiene', 'tener', 'hace', 'hacer', 'puede', 'poder',
        'dijo', 'decir', 'cada', 'donde', 'muy', 'sin', 'vez', 'mucho', 'saber', 'qué',
        'cómo', 'cuál', 'cuándo', 'dónde', 'por qué', 'porque', 'ya', 'sí', 'así', 'aquí',
        'ahí', 'allí', 'ese', 'esa', 'esto', 'esta', 'esos', 'esas', 'mi', 'tu', 'nos',
        'me', 'más', 'pero', 'o', 'si', 'había', 'han', 'he', 'has', 'hemos', 'habían',
        'ser', 'estar', 'tener', 'hacer', 'poder', 'ir', 'ver', 'dar', 'saber', 'querer',
        'llegar', 'pasar', 'deber', 'poner', 'parecer', 'quedar', 'creer', 'hablar', 'llevar',
        'dejar', 'seguir', 'encontrar', 'llamar', 'venir', 'pensar', 'salir', 'volver', 'tomar'
      ]),
      english: new Set([
        'the', 'of', 'and', 'to', 'a', 'in', 'is', 'you', 'that', 'it', 'he', 'was', 'for',
        'on', 'are', 'as', 'with', 'his', 'they', 'i', 'at', 'be', 'this', 'have', 'from',
        'or', 'one', 'had', 'by', 'word', 'but', 'not', 'what', 'all', 'were', 'we', 'when',
        'your', 'can', 'said', 'there', 'each', 'which', 'she', 'do', 'how', 'their', 'if',
        'will', 'up', 'other', 'about', 'out', 'many', 'then', 'them', 'these', 'so', 'some',
        'her', 'would', 'make', 'like', 'into', 'him', 'time', 'has', 'two', 'more', 'very',
        'after', 'words', 'long', 'than', 'first', 'been', 'call', 'who', 'its', 'now', 'find'
      ]),
      hebrew: new Set([
        'של', 'את', 'על', 'אל', 'מן', 'כל', 'לא', 'או', 'אם', 'כי', 'זה', 'זו', 'זאת',
        'הוא', 'היא', 'הם', 'הן', 'אני', 'אתה', 'את', 'אנחנו', 'אתם', 'אתן', 'יש', 'אין',
        'היה', 'הייתה', 'היו', 'יהיה', 'תהיה', 'יהיו', 'עם', 'בין', 'אחר', 'לפני', 'אחרי',
        'תחת', 'מעל', 'ליד', 'נגד', 'בתוך', 'מחוץ', 'כמו', 'בלי', 'למען', 'אלא'
      ])
    };

    // Mapeo completo de caracteres especiales y acentos
    this.accentMap = {
      // Acentos españoles
      'á': 'a', 'à': 'a', 'ä': 'a', 'â': 'a', 'ā': 'a', 'ă': 'a', 'ą': 'a',
      'é': 'e', 'è': 'e', 'ë': 'e', 'ê': 'e', 'ē': 'e', 'ĕ': 'e', 'ė': 'e', 'ę': 'e',
      'í': 'i', 'ì': 'i', 'ï': 'i', 'î': 'i', 'ī': 'i', 'ĭ': 'i', 'į': 'i',
      'ó': 'o', 'ò': 'o', 'ö': 'o', 'ô': 'o', 'ō': 'o', 'ŏ': 'o', 'ő': 'o',
      'ú': 'u', 'ù': 'u', 'ü': 'u', 'û': 'u', 'ū': 'u', 'ŭ': 'u', 'ů': 'u', 'ű': 'u', 'ų': 'u',
      'ñ': 'n', 'ç': 'c',
      // Caracteres hebreos comunes con equivalentes
      'ב': 'b', 'ג': 'g', 'ד': 'd', 'כ': 'k', 'ל': 'l', 'מ': 'm', 'נ': 'n',
      'פ': 'p', 'ר': 'r', 'ש': 's', 'ת': 't'
    };

    // Términos judaicos expandido y especializado
    this.jewishTerms = {
      // Objetos religiosos
      religious_objects: {
        'tefilin': ['tefelin', 'tefelín', 'tefilín', 'phylacteries', 'filacterias'],
        'tallit': ['talit', 'talis', 'tallis', 'prayer_shawl', 'manto_de_oracion'],
        'mezuzah': ['mezusa', 'mezuza', 'mezuzot', 'doorpost_scroll'],
        'kipa': ['kippa', 'yarmulka', 'yarmulke', 'kipot', 'solideo'],
        'shofar': ['shofhar', 'shophar', 'cuerno', 'horn'],
        'menorah': ['menora', 'janukia', 'chanukia', 'candelabro'],
        'etrog': ['cidra', 'citron'],
        'lulav': ['rama_palmera', 'palm_branch'],
        'sukkah': ['suca', 'cabana', 'booth']
      },
      
      // Libros sagrados
      sacred_books: {
        'torah': ['tora', 'pentateuco', 'five_books'],
        'tanaj': ['tanakh', 'biblia_hebrea', 'hebrew_bible'],
        'talmud': ['gemara', 'mishna'],
        'zohar': ['cabala', 'kabbalah'],
        'sidur': ['libro_oraciones', 'prayer_book'],
        'chumash': ['jumash', 'pentateuco_comentado'],
        'tehilim': ['salmos', 'psalms'],
        'machzor': ['libro_festividades'],
        'haggadah': ['hagada', 'relato_pesaj']
      },

      // Festividades
      holidays: {
        'rosh_hashana': ['año_nuevo_judio', 'rosh_hashanah'],
        'yom_kippur': ['dia_perdon', 'day_atonement'],
        'sukkot': ['fiesta_cabañas', 'feast_tabernacles'],
        'pesaj': ['pascua_judia', 'passover'],
        'shavuot': ['pentecostes', 'feast_weeks'],
        'januka': ['chanuka', 'hanukkah', 'fiesta_luces'],
        'purim': ['carnaval_judio'],
        'tu_bishvat': ['año_nuevo_arboles'],
        'lag_baomer': [],
        'tisha_bav': ['nueve_av']
      },

      // Corrientes judías
      movements: {
        'breslov': ['breslev', 'najman', 'nachman'],
        'lubavitch': ['jabad', 'chabad', 'rebbe'],
        'sefaradi': ['sefardí', 'sephardic'],
        'ashkenazi': ['ashkenazí', 'ashkenazic'],
        'ortodoxo': ['orthodox', 'haredi'],
        'conservador': ['conservative', 'masorti'],
        'reformista': ['reform', 'progressive']
      },

      // Términos rituales
      rituals: {
        'kashrut': ['kasher', 'kosher', 'alimentacion_judia'],
        'brit_mila': ['circuncision', 'brit_milah'],
        'bar_mitzvah': ['bar_mitzva'],
        'bat_mitzvah': ['bat_mitzva'],
        'shabbat': ['sabado', 'sabbath'],
        'havdalah': ['separacion'],
        'kiddush': ['santificacion'],
        'mishpaja': ['familia_judia', 'pureza_familiar']
      },

      // Vida diaria
      daily_life: {
        'minyan': ['quorum_oracion', 'prayer_quorum'],
        'synagogue': ['sinagoga', 'beit_knesset'],
        'rabbi': ['rabino', 'rav'],
        'community': ['comunidad', 'kehila'],
        'study': ['estudio', 'chavruta', 'beit_midrash']
      }
    };

    // Contracciones y abreviaciones expandidas
    this.contractions = {
      // Español
      'al': 'a el', 'del': 'de el', 'nel': 'en el', 'pal': 'para el', 'pol': 'por el',
      // Judío específico
      'rh': 'rosh hashana', 'yk': 'yom kippur', 'bm': 'bar mitzvah', 'bh': 'bet hamikdash'
    };

    // Jerga y abreviaciones de redes sociales expandida
    this.slangMap = {
      // Internet slang
      'q': 'que', 'xq': 'porque', 'pq': 'porque', 'x': 'por', 'bn': 'bien',
      'bno': 'bueno', 'tbn': 'también', 'tmb': 'también', 'dnd': 'donde',
      'cdo': 'cuando', 'cm': 'como', 'xa': 'para', 'pa': 'para', 'k': 'que',
      'aki': 'aquí', 'ai': 'ahí', 'lla': 'ya', 'xfa': 'por favor', 'pf': 'por favor',
      'porfis': 'por favor', 'info': 'información', 'fav': 'favorito',
      
      // Judaica específica
      'pte': 'presente', 'env': 'envío', 'prod': 'producto', 'lib': 'libro',
      'ofrt': 'oferta', 'dscto': 'descuento', 'prec': 'precio', 'stock': 'existencia',
      'disp': 'disponible', 'agot': 'agotado', 'nov': 'novedad', 'rec': 'reciente'
    };

    // Correcciones ortográficas especializadas
    this.spellCorrections = {
      // Productos judaicos
      'tefelin': 'tefilin', 'tefelín': 'tefilin', 'tefilín': 'tefilin',
      'phylacteries': 'tefilin', 'filacterias': 'tefilin',
      'talit': 'tallit', 'talis': 'tallit', 'tallis': 'tallit',
      'mezusa': 'mezuzah', 'mezuza': 'mezuzah', 'mezuzot': 'mezuzah',
      'kippa': 'kipa', 'yarmulka': 'kipa', 'yarmulke': 'kipa',
      'shofhar': 'shofar', 'shophar': 'shofar',
      'menora': 'menorah', 'janukia': 'menorah', 'chanukia': 'menorah',
      
      // Libros
      'tora': 'torah', 'tanakh': 'tanaj', 'jumash': 'chumash',
      'salmos': 'tehilim', 'hagada': 'haggadah',
      
      // Festividades
      'januca': 'januka', 'chanuca': 'januka', 'hanukkah': 'januka',
      'pascua': 'pesaj', 'passover': 'pesaj',
      
      // Errores comunes
      'ace': 'hace', 'ase': 'hace', 'asia': 'hacia', 'aver': 'a ver',
      'aber': 'a ver', 'haber': 'a ver', 'porke': 'porque', 'xke': 'porque',
      'aora': 'ahora', 'mui': 'muy', 'tanbien': 'también',
      'envio': 'envío', 'envios': 'envíos', 'presio': 'precio',
      'precios': 'precios', 'rapido': 'rápido', 'catologo': 'catálogo'
    };

    // Emojis expandido con contexto judaico
    this.emojiMap = {
      // Emociones básicas
      '😊': 'feliz', '😄': 'feliz', '🙂': 'feliz', '😍': 'amor', '❤️': 'amor',
      '💕': 'amor', '😢': 'triste', '😭': 'triste', '😡': 'enojado', '😠': 'enojado',
      '👍': 'bueno', '👎': 'malo', '🤔': 'pensando', '😕': 'confundido',
      '😟': 'preocupado', '🙏': 'gracias', '👏': 'aplausos', '🎉': 'celebración',
      
      // Judaico específico
      '🕯️': 'velas', '📚': 'libros', '🏠': 'hogar', '⭐': 'estrella_david',
      '🎯': 'objetivo', '💯': 'excelente', '🚀': 'rápido', '💝': 'regalo',
      '🔥': 'increíble', '✨': 'especial', '🌟': 'destacado'
    };

    // Patrones avanzados de reconocimiento
    this.patterns = {
      // URLs y contactos
      url: /https?:\/\/[^\s]+/gi,
      email: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/gi,
      phone: /(\+?57\s?)?[0-9]{3}[\s-]?[0-9]{3}[\s-]?[0-9]{4}/gi,
      whatsapp: /(?:whatsapp|wa|wsp)[\s:]*(\+?[0-9\s-]+)/gi,
      
      // Comerciales
      currency: /\$[0-9,.]+(\.?\d{2})?/gi,
      percentage: /\d+(\.\d+)?%/gi,
      price_range: /\$?[0-9,.]+-\$?[0-9,.]+/gi,
      
      // Sociales
      hashtag: /#[a-zA-ZÀ-ÿ0-9_]+/gi,
      mention: /@[a-zA-Z0-9_]+/gi,
      
      // Fechas y tiempo
      date: /\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}/gi,
      time: /\d{1,2}:\d{2}(\s?(am|pm))?/gi,
      
      // Judaico específico
      hebrew_text: /[\u0590-\u05FF]+/g,
      jewish_year: /\d{4}[\s-]?\d{4}|57\d{2}/g,
      
      // Productos
      product_code: /[A-Z]{2,}\d{3,}/gi,
      isbn: /ISBN[\s-]?(?:\d{1,5}[\s-]?\d{1,7}[\s-]?\d{1,6}[\s-]?\d)/gi
    };

    // Intenciones de usuario expandidas
    this.intentPatterns = {
      // Comerciales
      purchase: /quiero|comprar|adquirir|necesito|busco|precio|costo|cuanto|vender/i,
      inquiry: /información|detalles|especificaciones|características|descripción/i,
      availability: /disponible|stock|existencia|agotado|cuando llega|hay/i,
      shipping: /envío|enviar|entrega|domicilio|transporte|llegada/i,
      payment: /pago|pagar|tarjeta|efectivo|transferencia|cuotas/i,
      
      // Soporte
      complaint: /problema|queja|reclamo|mal|defectuoso|error|falla/i,
      compliment: /excelente|bueno|gracias|perfecto|recomiendo|felicitar/i,
      support: /ayuda|soporte|apoyo|asistencia|problema técnico/i,
      
      // Religiosos
      religious_query: /kasher|kosher|halal|ritual|ley|religioso|tradición/i,
      community: /comunidad|synagogue|sinagoga|rabbi|rabino|grupo/i,
      learning: /aprender|estudiar|enseñar|clase|curso|conocimiento/i,
      
      // Temporales
      urgency: /urgente|rápido|ya|ahora|pronto|inmediato/i,
      future: /después|luego|próximo|futuro|planear/i
    };

    // Análisis de sentimientos avanzado
    this.sentimentWords = {
      very_positive: {
        words: ['excelente', 'fantástico', 'increíble', 'maravilloso', 'espectacular', 
                'extraordinario', 'perfecto', 'genial', 'brillante', 'sobresaliente'],
        weight: 2.0
      },
      positive: {
        words: ['bueno', 'bien', 'buena', 'bonito', 'hermoso', 'agradable', 
                'satisfecho', 'contento', 'feliz', 'recomiendo', 'me gusta'],
        weight: 1.0
      },
      neutral_positive: {
        words: ['ok', 'regular', 'normal', 'aceptable', 'está bien'],
        weight: 0.3
      },
      neutral_negative: {
        words: ['no está mal', 'podría ser mejor', 'mejorable'],
        weight: -0.3
      },
      negative: {
        words: ['malo', 'feo', 'desagradable', 'molesto', 'triste', 
                'decepcionado', 'insatisfecho', 'no me gusta'],
        weight: -1.0
      },
      very_negative: {
        words: ['terrible', 'horrible', 'pésimo', 'odio', 'detesto', 
                'furioso', 'indignado', 'estafa', 'fraude'],
        weight: -2.0
      }
    };

    // Clasificación de productos judaicos
    this.productCategories = {
      books: ['libro', 'sidur', 'chumash', 'torah', 'talmud', 'zohar', 'tehilim', 'tanaj'],
      ritual_objects: ['tefilin', 'tallit', 'mezuzah', 'kipa', 'shofar'],
      home_items: ['menorah', 'candelabros', 'velas', 'platos', 'copas'],
      jewelry: ['collar', 'pulsera', 'anillo', 'cadena', 'colgante', 'estrella'],
      clothing: ['ropa', 'vestido', 'camisa', 'falda', 'kipá', 'talit'],
      gifts: ['regalo', 'presente', 'obsequio', 'detalle']
    };

    // Respuestas automáticas contextuales
    this.autoResponses = {
      greetings: [
        'Shalom! ¿En qué puedo ayudarte hoy?',
        '¡Hola! Bienvenido a Judaica Breslov Colombia',
        'Baruj Hashem, ¿cómo te puedo asistir?'
      ],
      
      product_not_found: [
        'No encontré ese producto específico, pero puedo ayudarte a encontrar algo similar.',
        'Ese artículo no está disponible ahora, ¿te interesa algo parecido?',
        'Permiteme revisar nuestro inventario y sugerirte alternativas.'
      ],
      
      shipping_info: [
        'Tenemos envíos gratis a toda Colombia para compras mayores a $185.000',
        'Los envíos son rápidos y seguros a todo el país',
        'Puedes elegir entre diferentes métodos de entrega'
      ],
      
      payment_info: [
        'Aceptamos múltiples formas de pago: tarjetas, PSE, Efecty y transferencias',
        'Puedes reservar tu producto y pagar como prefieras',
        'Ofrecemos facilidades de pago para tu comodidad'
      ]
    };

    // Configuración de procesamiento
    this.config = {
      minWordLength: 2,
      maxKeywords: 15,
      similarityThreshold: 0.7,
      sentimentThreshold: 0.1,
      spamThreshold: 0.8,
      maxMessageLength: 2000,
      confidenceThreshold: 0.6
    };

    // Cache para optimización
    this.cache = new Map();
    this.cacheMaxSize = 1000;
    this.cacheHits = 0;
    this.cacheMisses = 0;
  }

  /**
   * Normalización completa de texto multiidioma
   */
  normalizeText(text, language = 'auto') {
    if (!text || typeof text !== 'string') return '';

    // Check cache
    const cacheKey = `normalize_${text}_${language}`;
    if (this.cache.has(cacheKey)) {
      this.cacheHits++;
      return this.cache.get(cacheKey);
    }

    let normalized = text;

    // 1. Detectar idioma si es automático
    if (language === 'auto') {
      language = this.detectLanguage(text).language;
    }

    // 2. Preservar entidades especiales
    const preserved = this.preserveEntities(normalized);
    normalized = preserved.text;

    // 3. Convertir a minúsculas
    normalized = normalized.toLowerCase();

    // 4. Procesar emojis
    normalized = this.processEmojis(normalized);

    // 5. Expandir contracciones
    normalized = this.expandContractions(normalized);

    // 6. Corregir jerga y abreviaciones
    normalized = this.correctSlang(normalized);

    // 7. Corrección ortográfica inteligente
    normalized = this.correctSpelling(normalized);

    // 8. Normalizar acentos y caracteres especiales
    normalized = this.removeAccents(normalized);

    // 9. Limpiar caracteres no deseados
    normalized = this.cleanText(normalized);

    // 10. Normalizar espacios
    normalized = normalized.replace(/\s+/g, ' ').trim();

    // 11. Restaurar entidades preservadas
    normalized = this.restoreEntities(normalized, preserved.entities);

    // Guardar en cache
    this.updateCache(cacheKey, normalized);

    return normalized;
  }

  /**
   * Preservar entidades importantes durante el procesamiento
   */
  preserveEntities(text) {
    const entities = {};
    let processed = text;
    let counter = 0;

    // Preservar patrones importantes
    Object.entries(this.patterns).forEach(([type, pattern]) => {
      processed = processed.replace(pattern, (match) => {
        const placeholder = `__${type.toUpperCase()}_${counter++}__`;
        entities[placeholder] = match;
        return placeholder;
      });
    });

    return { text: processed, entities };
  }

  /**
   * Restaurar entidades preservadas
   */
  restoreEntities(text, entities) {
    let restored = text;
    Object.entries(entities).forEach(([placeholder, original]) => {
      restored = restored.replace(placeholder, original);
    });
    return restored;
  }

  /**
   * Procesamiento avanzado de emojis
   */
  processEmojis(text) {
    let processed = text;

    // Convertir emojis conocidos a palabras
    Object.entries(this.emojiMap).forEach(([emoji, meaning]) => {
      const regex = new RegExp(emoji.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
      processed = processed.replace(regex, ` ${meaning} `);
    });

    // Remover emojis no mapeados
    processed = processed.replace(/[\u{1F600}-\u{1F64F}]|[\u{1F300}-\u{1F5FF}]|[\u{1F680}-\u{1F6FF}]|[\u{1F1E0}-\u{1F1FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]/gu, ' ');

    return processed;
  }

  /**
   * Corrección ortográfica inteligente y contextual
   */
  correctSpelling(text) {
    let corrected = text;

    // Aplicar correcciones específicas
    Object.entries(this.spellCorrections).forEach(([wrong, right]) => {
      const regex = new RegExp(`\\b${this.escapeRegex(wrong)}\\b`, 'gi');
      corrected = corrected.replace(regex, right);
    });

    // Corrección de términos judaicos con variaciones
    Object.entries(this.jewishTerms).forEach(([category, terms]) => {
      Object.entries(terms).forEach(([correct, variations]) => {
        variations.forEach(variation => {
          const regex = new RegExp(`\\b${this.escapeRegex(variation)}\\b`, 'gi');
          corrected = corrected.replace(regex, correct);
        });
      });
    });

    return corrected;
  }

  /**
   * Análisis de intenciones del usuario
   */
  analyzeIntent(text) {
    const normalized = this.normalizeText(text);
    const intents = [];

    Object.entries(this.intentPatterns).forEach(([intent, pattern]) => {
      if (pattern.test(text)) {
        const matches = text.match(pattern) || [];
        intents.push({
          intent,
          confidence: Math.min(matches.length * 0.3 + 0.4, 1.0),
          matches
        });
      }
    });

    // Ordenar por confianza
    intents.sort((a, b) => b.confidence - a.confidence);

    return {
      primaryIntent: intents[0]?.intent || 'general',
      confidence: intents[0]?.confidence || 0.0,
      allIntents: intents
    };
  }

  /**
   * Clasificación automática de productos
   */
  classifyProduct(text) {
    const normalized = this.normalizeText(text);
    const tokens = this.tokenize(normalized);
    
    const scores = {};

    Object.entries(this.productCategories).forEach(([category, keywords]) => {
      scores[category] = 0;
      keywords.forEach(keyword => {
        if (tokens.includes(keyword)) {
          scores[category] += 1;
        }
        // Búsqueda parcial
        tokens.forEach(token => {
          if (token.includes(keyword) || keyword.includes(token)) {
            scores[category] += 0.5;
          }
        });
      });
    });

    const bestCategory = Object.entries(scores)
      .sort(([,a], [,b]) => b - a)[0];

    return {
      category: bestCategory?.[0] || 'general',
      confidence: bestCategory?.[1] || 0,
      scores
    };
  }

  /**
   * Análisis de sentimientos avanzado con contexto
   */
  analyzeSentiment(text) {
    const normalized = this.normalizeText(text);
    const tokens = this.tokenize(normalized);

    let totalScore = 0;
    let wordCount = 0;
    const detectedWords = [];

    Object.entries(this.sentimentWords).forEach(([category, data]) => {
      data.words.forEach(word => {
        tokens.forEach(token => {
          if (token.includes(word) || word.includes(token)) {
            totalScore += data.weight;
            wordCount++;
            detectedWords.push({ word, category, weight: data.weight });
          }
        });
      });
    });

    // Normalizar puntuación
    const avgScore = wordCount > 0 ? totalScore / wordCount : 0;
    
    let sentiment = 'neutral';
    let confidence = Math.abs(avgScore);

    if (avgScore > this.config.sentimentThreshold) {
      sentiment = avgScore > 1 ? 'very_positive' : 'positive';
    } else if (avgScore < -this.config.sentimentThreshold) {
      sentiment = avgScore < -1 ? 'very_negative' : 'negative';
    }

    return {
      sentiment,
      score: avgScore,
      confidence: Math.min(confidence, 1.0),
      detectedWords,
      wordCount
    };
  }

  /**
   * Detección de idioma mejorada
   */
  detectLanguage(text) {
    const tokens = this.tokenize(text.toLowerCase());
    const scores = { spanish: 0, english: 0, hebrew: 0 };

    // Contar coincidencias con palabras vacías
    Object.entries(this.stopWords).forEach(([lang, words]) => {
      tokens.forEach(token => {
        if (words.has(token)) {
          scores[lang]++;
        }
      });
    });

    // Detectar caracteres hebreos
    if (this.patterns.hebrew_text.test(text)) {
      scores.hebrew += 5;
    }

    // Detectar patrones específicos
    if (/\b(the|and|is|are)\b/i.test(text)) scores.english += 2;
    if (/\b(el|la|de|que|y)\b/i.test(text)) scores.spanish += 2;

    const maxScore = Math.max(...Object.values(scores));
    const detectedLang = Object.entries(scores)
      .find(([, score]) => score === maxScore)?.[0] || 'unknown';

    return {
      language: detectedLang,
      confidence: maxScore / tokens.length || 0,
      scores
    };
  }

  /**
   * Extracción de entidades nombradas avanzada
   */
  extractAdvancedEntities(text) {
    const entities = {
      persons: [],
      places: [],
      organizations: [],
      products: [],
      jewish_terms: [],
      dates: [],
      times: [],
      prices: [],
      contacts: {
        urls: [],
        emails: [],
        phones: []
      },
      measurements: []
    };

    // Extraer usando patrones
    Object.entries(this.patterns).forEach(([type, pattern]) => {
      const matches = text.match(pattern) || [];
      
      if (type === 'url') entities.contacts.urls = matches;
      else if (type === 'email') entities.contacts.emails = matches;
      else if (type === 'phone') entities.contacts.phones = matches;
      else if (type === 'currency') entities.prices = matches;
      else if (type === 'date') entities.dates = matches;
      else if (type === 'time') entities.times = matches;
    });

    // Extraer términos judaicos
    Object.entries(this.jewishTerms).forEach(([category, terms]) => {
      Object.keys(terms).forEach(term => {
        if (text.toLowerCase().includes(term)) {
          entities.jewish_terms.push({ term, category });
        }
      });
    });

    // Extraer nombres propios
    const properNouns = text.match(/\b[A-ZÀ-Ÿ][a-zà-ÿ]+\b/g) || [];
    entities.persons = properNouns;

    return entities;
  }

  /**
   * Generación de respuestas contextuales
   */
  generateContextualResponse(text, intent = null) {
    if (!intent) {
      intent = this.analyzeIntent(text).primaryIntent;
    }

    const responses = this.autoResponses[intent] || this.autoResponses.greetings;
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];

    // Personalizar respuesta basada en entidades encontradas
    const entities = this.extractAdvancedEntities(text);
    let personalizedResponse = randomResponse;

    // Si menciona productos específicos
    if (entities.jewish_terms.length > 0) {
      const product = entities.jewish_terms[0].term;
      personalizedResponse += ` Veo que estás interesado en ${product}.`;
    }

    // Si menciona precios
    if (entities.prices.length > 0) {
      personalizedResponse += ' Te ayudo con información de precios.';
    }

    return {
      response: personalizedResponse,
      intent,
      entities,
      confidence: this.config.confidenceThreshold
    };
  }

  /**
   * Detección avanzada de spam y contenido inapropiado
   */
  detectSpamAndInappropriate(text) {
    const checks = {
      isSpam: false,
      reason: null,
      confidence: 0,
      flags: []
    };

    const normalized = this.normalizeText(text);

    // Patrones de spam
    const spamPatterns = [
      { pattern: /click\s+here/i, weight: 0.8, name: 'click_here' },
      { pattern: /free\s+money/i, weight: 0.9, name: 'free_money' },
      { pattern: /urgent/i, weight: 0.6, name: 'urgency' },
      { pattern: /winner/i, weight: 0.7, name: 'winner' },
      { pattern: /\$\$\$+/, weight: 0.5, name: 'money_symbols' },
      { pattern: /!!!{3,}/, weight: 0.4, name: 'excessive_exclamation' },
      { pattern: /[A-Z]{10,}/, weight: 0.6, name: 'excessive_caps' }
    ];

    let totalWeight = 0;
    spamPatterns.forEach(({ pattern, weight, name }) => {
      if (pattern.test(text)) {
        totalWeight += weight;
        checks.flags.push(name);
      }
    });

    // Verificaciones adicionales
    if ((/(.)\1{5,}/).test(text)) {
      totalWeight += 0.5;
      checks.flags.push('repetitive_chars');
    }

    const uppercaseRatio = (text.match(/[A-Z]/g) || []).length / text.length;
    if (uppercaseRatio > 0.8 && text.length > 10) {
      totalWeight += 0.6;
      checks.flags.push('excessive_uppercase');
    }

    checks.confidence = Math.min(totalWeight, 1.0);
    checks.isSpam = checks.confidence > this.config.spamThreshold;
    
    if (checks.isSpam) {
      checks.reason = 'Multiple spam indicators detected';
    }

    return checks;
  }

  /**
   * Análisis de similitud semántica avanzada
   */
  calculateSemanticSimilarity(text1, text2) {
    // Jaccard similarity
    const tokens1 = new Set(this.tokenize(this.normalizeText(text1)));
    const tokens2 = new Set(this.tokenize(this.normalizeText(text2)));
    
    const intersection = new Set([...tokens1].filter(x => tokens2.has(x)));
    const union = new Set([...tokens1, ...tokens2]);
    const jaccard = intersection.size / union.size;

    // Cosine similarity con n-gramas
    const bigrams1 = new Set(this.extractNGrams([...tokens1], 2));
    const bigrams2 = new Set(this.extractNGrams([...tokens2], 2));
    
    const bigramIntersection = new Set([...bigrams1].filter(x => bigrams2.has(x)));
    const cosine = (2 * bigramIntersection.size) / (bigrams1.size + bigrams2.size) || 0;

    // Similitud semántica de términos judaicos
    const entities1 = this.extractAdvancedEntities(text1).jewish_terms;
    const entities2 = this.extractAdvancedEntities(text2).jewish_terms;
    const entitySimilarity = this.calculateEntitySimilarity(entities1, entities2);

    return {
      jaccard,
      cosine,
      entitySimilarity,
      overall: (jaccard + cosine + entitySimilarity) / 3
    };
  }

  /**
   * Similitud entre entidades judaicas
   */
  calculateEntitySimilarity(entities1, entities2) {
    if (entities1.length === 0 && entities2.length === 0) return 1;
    if (entities1.length === 0 || entities2.length === 0) return 0;

    const terms1 = new Set(entities1.map(e => e.term));
    const terms2 = new Set(entities2.map(e => e.term));
    
    const intersection = new Set([...terms1].filter(x => terms2.has(x)));
    const union = new Set([...terms1, ...terms2]);

    return intersection.size / union.size;
  }

  /**
   * Extracción de keywords inteligente
   */
  extractIntelligentKeywords(text, maxKeywords = null) {
    maxKeywords = maxKeywords || this.config.maxKeywords;
    
    const normalized = this.normalizeText(text);
    const tokens = this.tokenize(normalized);
    const language = this.detectLanguage(text).language;
    
    // Filtrar stop words según idioma detectado
    const stopWords = this.stopWords[language] || this.stopWords.spanish;
    const filteredTokens = tokens.filter(token => 
      !stopWords.has(token) && 
      token.length >= this.config.minWordLength
    );

    // Calcular frecuencias
    const frequencies = this.calculateTermFrequency(filteredTokens);
    
    // Aplicar stemming
    const stemmedFreqs = {};
    Object.entries(frequencies).forEach(([term, freq]) => {
      const stemmed = this.stem(term);
      stemmedFreqs[stemmed] = (stemmedFreqs[stemmed] || 0) + freq;
    });

    // Bonus para términos judaicos
    const entities = this.extractAdvancedEntities(text);
    entities.jewish_terms.forEach(({ term }) => {
      const stemmed = this.stem(term);
      stemmedFreqs[stemmed] = (stemmedFreqs[stemmed] || 0) + 2;
    });

    // Ordenar y limitar
    const sortedKeywords = Object.entries(stemmedFreqs)
      .sort(([,a], [,b]) => b - a)
      .slice(0, maxKeywords)
      .map(([keyword, frequency]) => ({
        keyword,
        frequency,
        importance: frequency / Math.max(...Object.values(stemmedFreqs))
      }));

    return sortedKeywords;
  }

  /**
   * Análisis completo de texto
   */
  analyzeTextCompletely(text) {
    const startTime = Date.now();
    
    const analysis = {
      // Procesamiento básico
      original: text,
      normalized: this.normalizeText(text),
      tokens: null,
      statistics: null,
      
      // Análisis semántico
      language: null,
      sentiment: null,
      intent: null,
      entities: null,
      keywords: null,
      productCategory: null,
      
      // Calidad y seguridad
      spamCheck: null,
      validation: null,
      
      // Metadata
      processingTime: null,
      confidence: 0
    };

    try {
      // Tokenización
      analysis.tokens = this.tokenize(analysis.normalized);
      
      // Estadísticas
      analysis.statistics = this.getAdvancedStatistics(text);
      
      // Detección de idioma
      analysis.language = this.detectLanguage(text);
      
      // Análisis de sentimientos
      analysis.sentiment = this.analyzeSentiment(text);
      
      // Análisis de intenciones
      analysis.intent = this.analyzeIntent(text);
      
      // Extracción de entidades
      analysis.entities = this.extractAdvancedEntities(text);
      
      // Extracción de keywords
      analysis.keywords = this.extractIntelligentKeywords(text);
      
      // Clasificación de productos
      analysis.productCategory = this.classifyProduct(text);
      
      // Verificación de spam
      analysis.spamCheck = this.detectSpamAndInappropriate(text);
      
      // Validación de estructura
      analysis.validation = this.validateAdvancedStructure(text);
      
      // Calcular confianza general
      analysis.confidence = this.calculateOverallConfidence(analysis);
      
    } catch (error) {
      console.error('Error in complete text analysis:', error);
      analysis.error = error.message;
    }

    analysis.processingTime = Date.now() - startTime;
    return analysis;
  }

  /**
   * Estadísticas avanzadas de texto
   */
  getAdvancedStatistics(text) {
    const tokens = this.tokenize(text);
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const words = tokens.length;
    const characters = text.length;
    const charactersNoSpaces = text.replace(/\s/g, '').length;
    const paragraphs = text.split(/\n\s*\n/).filter(p => p.trim().length > 0);
    
    // Análisis de complejidad
    const avgWordsPerSentence = words / sentences.length || 0;
    const avgCharsPerWord = charactersNoSpaces / words || 0;
    const avgSentencesPerParagraph = sentences.length / paragraphs.length || 0;
    
    // Diversidad lexical
    const uniqueWords = new Set(tokens.map(t => t.toLowerCase())).size;
    const lexicalDiversity = uniqueWords / words || 0;
    
    return {
      characters,
      charactersNoSpaces,
      words,
      uniqueWords,
      sentences: sentences.length,
      paragraphs: paragraphs.length,
      avgWordsPerSentence,
      avgCharsPerWord,
      avgSentencesPerParagraph,
      lexicalDiversity,
      readabilityScore: this.calculateAdvancedReadability(sentences, words, charactersNoSpaces),
      complexity: this.calculateTextComplexity(avgWordsPerSentence, avgCharsPerWord, lexicalDiversity)
    };
  }

  /**
   * Validación avanzada de estructura
   */
  validateAdvancedStructure(text) {
    const validation = {
      isValid: true,
      score: 100,
      issues: [],
      suggestions: [],
      warnings: []
    };

    // Longitud
    if (text.length < 3) {
      validation.isValid = false;
      validation.score -= 30;
      validation.issues.push('Texto demasiado corto');
      validation.suggestions.push('Proporciona más detalles');
    }

    if (text.length > this.config.maxMessageLength) {
      validation.score -= 20;
      validation.warnings.push('Texto muy largo');
      validation.suggestions.push('Intenta ser más conciso');
    }

    // Repetición excesiva
    if (/(.{3,})\1{2,}/.test(text)) {
      validation.score -= 25;
      validation.issues.push('Repetición excesiva detectada');
      validation.suggestions.push('Evita repetir frases');
    }

    // Puntuación
    const hasProperPunctuation = /[.!?]/.test(text);
    if (!hasProperPunctuation && text.length > 20) {
      validation.score -= 10;
      validation.warnings.push('Falta puntuación');
      validation.suggestions.push('Usa puntos o signos de interrogación');
    }

    // Mayúsculas excesivas
    const upperRatio = (text.match(/[A-Z]/g) || []).length / text.length;
    if (upperRatio > 0.3 && text.length > 10) {
      validation.score -= 15;
      validation.warnings.push('Demasiadas mayúsculas');
      validation.suggestions.push('Usa mayúsculas solo donde sea necesario');
    }

    validation.score = Math.max(0, validation.score);
    validation.isValid = validation.score >= 70;

    return validation;
  }

  /**
   * Calcular confianza general del análisis
   */
  calculateOverallConfidence(analysis) {
    const factors = [
      analysis.language.confidence * 0.2,
      analysis.sentiment.confidence * 0.2,
      analysis.intent.confidence * 0.3,
      (analysis.validation.score / 100) * 0.2,
      (1 - analysis.spamCheck.confidence) * 0.1
    ];

    return factors.reduce((sum, factor) => sum + factor, 0);
  }

  /**
   * Calcular complejidad de texto
   */
  calculateTextComplexity(avgWordsPerSentence, avgCharsPerWord, lexicalDiversity) {
    // Normalizar valores
    const sentenceComplexity = Math.min(avgWordsPerSentence / 20, 1);
    const wordComplexity = Math.min(avgCharsPerWord / 8, 1);
    const vocabularyComplexity = lexicalDiversity;

    const overall = (sentenceComplexity + wordComplexity + vocabularyComplexity) / 3;

    let level = 'simple';
    if (overall > 0.7) level = 'complex';
    else if (overall > 0.4) level = 'moderate';

    return {
      score: overall,
      level,
      factors: {
        sentence: sentenceComplexity,
        vocabulary: wordComplexity,
        diversity: vocabularyComplexity
      }
    };
  }

  /**
   * Legibilidad avanzada
   */
  calculateAdvancedReadability(sentences, words, characters) {
    if (sentences === 0 || words === 0) return 0;
    
    const avgWordsPerSentence = words / sentences;
    const avgSyllablesPerWord = characters / words; // Aproximación
    
    // Fórmula Flesch adaptada para español
    let score = 206.835 - (1.015 * avgWordsPerSentence) - (84.6 * avgSyllablesPerWord);
    score = Math.max(0, Math.min(100, score));
    
    let level = 'difficult';
    if (score >= 90) level = 'very_easy';
    else if (score >= 80) level = 'easy';
    else if (score >= 70) level = 'fairly_easy';
    else if (score >= 60) level = 'standard';
    else if (score >= 50) level = 'fairly_difficult';
    else if (score >= 30) level = 'difficult';
    else level = 'very_difficult';

    return { score, level };
  }

  /**
   * Stemming avanzado para español
   */
  stemAdvanced(word) {
    let stemmed = word.toLowerCase();
    
    const suffixes = [
      // Plurales
      'es', 'os', 'as',
      // Verbos
      'ando', 'iendo', 'ado', 'ido', 'ar', 'er', 'ir',
      // Adjetivos
      'mente', 'ísimo', 'ísima', 'oso', 'osa', 'ivo', 'iva',
      // Sustantivos
      'ación', 'ción', 'sión', 'dad', 'tad', 'ería', 'anza', 'encia'
    ];
    
    for (const suffix of suffixes.sort((a, b) => b.length - a.length)) {
      if (stemmed.endsWith(suffix) && stemmed.length > suffix.length + 2) {
        stemmed = stemmed.slice(0, -suffix.length);
        break;
      }
    }
    
    return stemmed;
  }

  // Utilidades auxiliares

  /**
   * Escapar caracteres especiales para regex
   */
  escapeRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  /**
   * Tokenización avanzada
   */
  tokenize(text) {
    return text
      .split(/[\s\-_.,;:!?()[\]{}"']+/)
      .filter(token => token.length >= this.config.minWordLength)
      .map(token => token.toLowerCase());
  }

  /**
   * Limpiar texto
   */
  cleanText(text) {
    return text
      .replace(/[^\w\sñáéíóúü\$\.,\?\!\-]/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Remover acentos
   */
  removeAccents(text) {
    let normalized = text;
    Object.entries(this.accentMap).forEach(([accented, normal]) => {
      const regex = new RegExp(accented, 'g');
      normalized = normalized.replace(regex, normal);
    });
    return normalized;
  }

  /**
   * Expandir contracciones
   */
  expandContractions(text) {
    let expanded = text;
    Object.entries(this.contractions).forEach(([contraction, expansion]) => {
      const regex = new RegExp(`\\b${this.escapeRegex(contraction)}\\b`, 'gi');
      expanded = expanded.replace(regex, expansion);
    });
    return expanded;
  }

  /**
   * Corregir jerga
   */
  correctSlang(text) {
    let corrected = text;
    Object.entries(this.slangMap).forEach(([slang, correction]) => {
      const regex = new RegExp(`\\b${this.escapeRegex(slang)}\\b`, 'gi');
      corrected = corrected.replace(regex, correction);
    });
    return corrected;
  }

  /**
   * Extraer n-gramas
   */
  extractNGrams(tokens, n = 2) {
    const ngrams = [];
    for (let i = 0; i <= tokens.length - n; i++) {
      ngrams.push(tokens.slice(i, i + n).join(' '));
    }
    return ngrams;
  }

  /**
   * Calcular frecuencia de términos
   */
  calculateTermFrequency(tokens) {
    const frequency = {};
    tokens.forEach(token => {
      frequency[token] = (frequency[token] || 0) + 1;
    });
    return frequency;
  }

  // Gestión de cache

  /**
   * Actualizar cache con límite de tamaño
   */
  updateCache(key, value) {
    if (this.cache.size >= this.cacheMaxSize) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }
    this.cache.set(key, value);
    this.cacheMisses++;
  }

  /**
   * Limpiar cache
   */
  clearCache() {
    this.cache.clear();
    this.cacheHits = 0;
    this.cacheMisses = 0;
  }

  /**
   * Obtener estadísticas de cache
   */
  getCacheStats() {
    const total = this.cacheHits + this.cacheMisses;
    return {
      size: this.cache.size,
      maxSize: this.cacheMaxSize,
      hits: this.cacheHits,
      misses: this.cacheMisses,
      hitRate: total > 0 ? this.cacheHits / total : 0
    };
  }

  /**
   * Obtener configuración completa
   */
  getFullConfiguration() {
    return {
      stopWords: Object.fromEntries(
        Object.entries(this.stopWords).map(([lang, words]) => [lang, words.size])
      ),
      jewishTerms: Object.fromEntries(
        Object.entries(this.jewishTerms).map(([category, terms]) => [category, Object.keys(terms).length])
      ),
      patterns: Object.keys(this.patterns).length,
      sentimentCategories: Object.keys(this.sentimentWords).length,
      productCategories: Object.keys(this.productCategories).length,
      corrections: Object.keys(this.spellCorrections).length,
      contractions: Object.keys(this.contractions).length,
      slang: Object.keys(this.slangMap).length,
      emojis: Object.keys(this.emojiMap).length,
      cache: this.getCacheStats(),
      config: this.config
    };
  }

  /**
   * Exportar análisis a JSON
   */
  exportAnalysis(analysis) {
    return JSON.stringify(analysis, null, 2);
  }

  /**
   * Limpiar recursos
   */
  cleanup() {
    this.clearCache();
    console.log('🧹 Advanced NLP Utils: Recursos limpiados');
  }
}