// lib/chatbot/engine.js - INTEGRADO CON TUS ARCHIVOS EXISTENTES

import { query } from '../database';
import { IntentClassifier } from './intents.js';
import { SynonymManager } from './synonyms.js';
import { ResponseGeneratorProfessional } from './responses.js';
import { AdvancedNLPUtils } from './nlp-utils.js';
import { IntelligentProductSearch } from './product-search.js';

export class AdvancedMultiEngineChatbot {
  constructor() {
    this.isInitialized = false;
    this.isInitializing = false;
    this.initializationError = null;
    
    this.components = {
      intentClassifier: null,
      synonymManager: null,
      responseGenerator: null,
      nlpUtils: null,
      productSearch: null
    };
    
    this.config = {
      fallbackThreshold: 0.3,
      confidenceThreshold: 0.5,
      maxRetries: 2,
      enableProductSearch: true,
      enableContextualResponses: true,
      debug: process.env.NODE_ENV === 'development'
    };
    
    this.stats = {
      totalMessages: 0,
      successfulResponses: 0,
      fallbackResponses: 0,
      errors: 0,
      averageConfidence: 0,
      productSearches: 0,
      initTime: null,
      lastProcessTime: null
    };
  }

  async initialize() {
    if (this.isInitialized) {
      return true;
    }

    if (this.isInitializing) {
      console.log('⏳ Inicialización ya en progreso, esperando...');
      return await this.waitForInitialization();
    }

    this.isInitializing = true;
    const startTime = Date.now();

    try {
      console.log('🚀 Inicializando motor del chatbot integrado...');

      await this.initializeComponents();
      this.isInitialized = true;
      this.isInitializing = false;
      this.stats.initTime = Date.now() - startTime;

      console.log(`✅ Motor integrado inicializado correctamente en ${this.stats.initTime}ms`);
      return true;

    } catch (error) {
      this.isInitializing = false;
      this.initializationError = error;
      console.error('❌ Error inicializando motor:', error);
      return false;
    }
  }

  async initializeComponents() {
    try {
      // 1. Inicializar NLP Utils
      console.log('⚙️ Inicializando NLP Utils...');
      this.components.nlpUtils = new AdvancedNLPUtils();
      
      // 2. Inicializar Synonym Manager
      console.log('⚙️ Inicializando Synonym Manager...');
      this.components.synonymManager = new SynonymManager();
      await this.components.synonymManager.initialize();
      
      // 3. Inicializar Intent Classifier
      console.log('⚙️ Inicializando Intent Classifier...');
      this.components.intentClassifier = new IntentClassifier();
      await this.components.intentClassifier.initialize();
      
      // 4. Inicializar Response Generator
      console.log('⚙️ Inicializando Response Generator...');
      this.components.responseGenerator = new ResponseGeneratorProfessional();
      
      // 5. CRÍTICO: Inicializar Product Search CON los componentes ya inicializados
      console.log('⚙️ Inicializando Product Search integrado...');
      this.components.productSearch = new IntelligentProductSearch(
        this.components.synonymManager,  // ← PASAR synonymManager
        this.components.nlpUtils         // ← PASAR nlpUtils
      );
      
      console.log('✅ Todos los componentes integrados inicializados');
      
    } catch (error) {
      console.error('❌ Error inicializando componentes:', error);
      throw error;
    }
  }

  async waitForInitialization() {
    let attempts = 0;
    const maxAttempts = 50;
    
    while (this.isInitializing && attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 100));
      attempts++;
    }

    if (this.isInitializing) {
      throw new Error('Timeout esperando inicialización');
    }

    if (this.initializationError) {
      throw this.initializationError;
    }

    return this.isInitialized;
  }

  async processMessage(message, conversationId, sessionId, userContext = {}) {
    if (!this.isInitialized) {
      if (!await this.initialize()) {
        return this.generateFallbackResponse('INIT_FAILED', message);
      }
    }

    this.stats.totalMessages++;
    const startTime = Date.now();

    try {
      console.log(`💬 Procesando: "${message.substring(0, 50)}..."`);

      // 1. Pre-procesar mensaje usando NLP Utils
      const processedMessage = await this.preprocessMessageWithNLP(message);
      
      // 2. Clasificar intención
      const intent = await this.classifyIntent(processedMessage, userContext);
      console.log(`🎯 Intención detectada: ${intent.type} (${(intent.confidence * 100).toFixed(1)}%)`);
      
      // 3. Buscar productos usando TODO el sistema integrado
      const searchResults = await this.searchProductsIntegrated(processedMessage, intent, sessionId);
      console.log(`🔍 Productos encontrados: ${searchResults.length}`);
      
      // 4. Generar respuesta
      const response = await this.generateResponse(intent, searchResults, userContext, processedMessage, sessionId);

      const processingTime = Date.now() - startTime;
      this.stats.lastProcessTime = processingTime;
      this.stats.successfulResponses++;

      if (intent.confidence) {
        this.updateAverageConfidence(intent.confidence);
      }

      const result = {
        success: true,
        response: response.text,
        intent: intent.type,
        confidence: intent.confidence,
        requiresHuman: response.requiresHuman || false,
        suggestions: response.suggestions || [],
        products: searchResults || [],
        metadata: {
          processingTime,
          intent: intent.type,
          confidence: intent.confidence,
          entitiesDetected: Object.keys(intent.entities || {}).length,
          productsFound: (searchResults || []).length,
          sessionId,
          usedIntegratedSearch: true
        }
      };

      console.log(`✅ Mensaje procesado exitosamente en ${processingTime}ms`);
      return result;

    } catch (error) {
      const processingTime = Date.now() - startTime;
      this.stats.errors++;
      
      console.error('❌ Error procesando mensaje:', error);

      return this.generateFallbackResponse('PROCESSING_ERROR', message, {
        error: error.message,
        processingTime
      });
    }
  }

  // NUEVO: Pre-procesar con NLP Utils
  async preprocessMessageWithNLP(message) {
    try {
      if (!message || typeof message !== 'string') {
        return '';
      }

      let processed = message.trim();
      
      if (processed.length === 0) return '';
      if (processed.length > 1000) processed = processed.substring(0, 1000);

      // Usar NLP Utils si está disponible
      if (this.components.nlpUtils) {
        try {
          processed = this.components.nlpUtils.normalizeText(processed);
          console.log(`🧠 NLP procesado: "${processed}"`);
        } catch (nlpError) {
          console.log('⚠️ Error en NLP Utils, usando texto original:', nlpError.message);
        }
      }

      return processed.replace(/\s+/g, ' ').trim();

    } catch (error) {
      console.error('❌ Error en preprocessMessageWithNLP:', error);
      return message || '';
    }
  }

  async classifyIntent(message, userContext) {
    if (!this.components.intentClassifier) {
      return {
        type: 'unknown',
        confidence: 0,
        entities: {},
        fallback: true,
        reason: 'NO_CLASSIFIER'
      };
    }

    try {
      const result = await this.components.intentClassifier.classify(message, userContext);
      
      if (!result || !result.type) {
        return {
          type: 'unknown',
          confidence: 0,
          entities: {},
          fallback: true,
          reason: 'CLASSIFICATION_FAILED'
        };
      }

      return result;

    } catch (error) {
      console.error('❌ Error en clasificación de intención:', error);
      return {
        type: 'unknown',
        confidence: 0,
        entities: {},
        fallback: true,
        reason: 'CLASSIFIER_ERROR',
        error: error.message
      };
    }
  }

  // MEJORADO: Búsqueda integrada con todos tus componentes
  async searchProductsIntegrated(message, intent, sessionId) {
    if (!this.config.enableProductSearch || !this.components.productSearch) {
      return [];
    }

    try {
      this.stats.productSearches++;
      
      // 1. Extraer términos básicos
      const basicTerms = this.extractProductTerms(message, intent);
      
      // 2. Usar synonymManager para expandir términos
      const expandedTerms = await this.expandTermsWithSynonyms(basicTerms, message);
      
      // 3. Usar nlpUtils para detectar productos mencionados
      const nlpDetectedTerms = await this.detectProductsWithNLP(message);
      
      // 4. Combinar todos los términos
      const allTerms = [...new Set([...basicTerms, ...expandedTerms, ...nlpDetectedTerms])];
      
      console.log(`🔍 Términos finales para búsqueda: ${allTerms.join(', ')}`);
      
      if (allTerms.length === 0) {
        // Si no hay términos específicos, mostrar productos populares
        if (['price_inquiry', 'availability_check', 'specific_product_inquiry'].includes(intent.type)) {
          return await this.components.productSearch.getPopularProducts(6);
        }
        return [];
      }

      // 5. Buscar productos usando el sistema integrado
      const searchResults = await this.components.productSearch.searchProducts(allTerms, intent, 8);
      
      return searchResults;

    } catch (error) {
      console.error('❌ Error en búsqueda integrada:', error);
      return [];
    }
  }

  // Expandir términos usando synonymManager
  async expandTermsWithSynonyms(basicTerms, originalMessage) {
    try {
      if (!this.components.synonymManager) {
        return basicTerms;
      }

      const expandedTerms = [];
      
      for (const term of basicTerms) {
        try {
          const synonymData = await this.components.synonymManager.getSynonymsForTerm(term);
          if (synonymData) {
            // Agregar variaciones más relevantes
            if (synonymData.variations) {
              expandedTerms.push(...synonymData.variations.slice(0, 3));
            }
            if (synonymData.related) {
              expandedTerms.push(...synonymData.related.slice(0, 2));
            }
          }
        } catch (synError) {
          console.log(`⚠️ Error expandiendo sinónimos para "${term}":`, synError.message);
        }
      }

      // También expandir el mensaje completo
      try {
        const expandedMessage = await this.components.synonymManager.expandSynonyms(originalMessage);
        if (expandedMessage && expandedMessage !== originalMessage) {
          const additionalTerms = expandedMessage.split(' ').filter(t => t.length > 2);
          expandedTerms.push(...additionalTerms.slice(0, 5));
        }
      } catch (expandError) {
        console.log('⚠️ Error expandiendo mensaje completo:', expandError.message);
      }

      return [...new Set(expandedTerms)];
      
    } catch (error) {
      console.error('❌ Error en expandTermsWithSynonyms:', error);
      return basicTerms;
    }
  }

  // Detectar productos usando nlpUtils
  async detectProductsWithNLP(message) {
    try {
      if (!this.components.nlpUtils) {
        return [];
      }

      // Usar nlpUtils para análisis completo
      const analysis = this.components.nlpUtils.analyzeTextCompletely(message);
      
      const detectedTerms = [];
      
      // Extraer keywords relevantes
      if (analysis.keywords) {
        analysis.keywords.forEach(keywordObj => {
          if (keywordObj.importance > 0.5) {
            detectedTerms.push(keywordObj.keyword);
          }
        });
      }

      // Usar detectCategories y detectProducts si están disponibles
      if (this.components.synonymManager.detectProducts) {
        const products = await this.components.synonymManager.detectProducts(message);
        detectedTerms.push(...products);
      }

      if (this.components.synonymManager.detectCategories) {
        const categories = await this.components.synonymManager.detectCategories(message);
        detectedTerms.push(...categories);
      }

      return [...new Set(detectedTerms)].filter(term => term && term.length > 1);
      
    } catch (error) {
      console.error('❌ Error en detectProductsWithNLP:', error);
      return [];
    }
  }

  extractProductTerms(message, intent) {
    const terms = [];
    
    // Términos de entidades detectadas
    if (intent.entities) {
      if (intent.entities.products) terms.push(...intent.entities.products);
      if (intent.entities.breslov_books) terms.push(...intent.entities.breslov_books);
      if (intent.entities.religious_books) terms.push(...intent.entities.religious_books);
      if (intent.entities.ritual_items) terms.push(...intent.entities.ritual_items);
    }

    // Patrones mejorados para extraer productos
    const patterns = [
      /(?:precio|costo|valor|cuanto|cuánto)\s+(?:de|del|para)?\s*([^?¿.!]+)/i,
      /(?:busco|necesito|quiero|tengo interés en|me interesa)\s+([^?¿.!]+)/i,
      /(?:hay|tienen|venden|manejan|disponible)\s+([^?¿.!]+)/i,
      /(?:comprar|adquirir)\s+(?:un|una|el|la)?\s*([^?¿.!]+)/i
    ];

    patterns.forEach(pattern => {
      const match = message.match(pattern);
      if (match && match[1]) {
        const extractedTerm = match[1].trim().toLowerCase();
        if (extractedTerm.length > 2 && extractedTerm.length < 50) {
          terms.push(extractedTerm);
        }
      }
    });

    // Términos directos importantes
    const directTerms = [
      'emunah', 'emuna', 'vivamos con emunah',
      'torah', 'torá', 'la torah explicada', 'bereshit',
      'tehilim', 'salmos', 'interlineal',
      'tefilin', 'tefilín', 'filacterias',
      'tallit', 'talit', 'tzitzit',
      'mezuzah', 'mezuzá', 'pergamino',
      'kipa', 'kipá', 'yarmulke',
      'menorah', 'candelabro', 'janukia',
      'breslov', 'shalom arush', 'najmán'
    ];

    const lowerMessage = message.toLowerCase();
    directTerms.forEach(term => {
      if (lowerMessage.includes(term)) {
        terms.push(term);
      }
    });

    return [...new Set(terms)].filter(term => term && term.length > 1);
  }

  async generateResponse(intent, searchResults, userContext, originalMessage, sessionId) {
    if (!this.components.responseGenerator) {
      return {
        text: this.getBasicFallbackResponse(),
        requiresHuman: true,
        suggestions: ['Contactar WhatsApp', 'Ver catálogo online']
      };
    }

    try {
      const context = {
        intent,
        searchResults: searchResults || [],
        conversationContext: userContext,
        userContext,
        originalMessage,
        sessionId
      };

      const response = await this.components.responseGenerator.generate(context);
      
      if (!response || !response.text) {
        throw new Error('Response generator returned invalid response');
      }

      return {
        text: response.text,
        requiresHuman: response.requiresHuman || false,
        suggestions: response.suggestions || [],
        followUpQuestions: response.followUpQuestions || [],
        metadata: response.metadata || {}
      };

    } catch (error) {
      console.error('❌ Error generando respuesta:', error);
      return {
        text: this.getBasicFallbackResponse(),
        requiresHuman: true,
        suggestions: ['Reformular pregunta', 'Contactar WhatsApp'],
        error: error.message
      };
    }
  }

  generateFallbackResponse(reason, originalMessage, metadata = {}) {
    this.stats.fallbackResponses++;
    
    const fallbackResponses = {
      'INIT_FAILED': 'Nuestro asistente se está iniciando. Contacta: https://wa.me/573009291156',
      'NO_CLASSIFIER': 'Procesando tu consulta. Para respuesta inmediata: https://wa.me/573009291156',
      'PROCESSING_ERROR': 'Problema técnico temporal. Contacta: https://wa.me/573009291156',
      'CLASSIFICATION_FAILED': 'No entendí tu consulta. ¿Puedes reformularla? O contacta: https://wa.me/573009291156'
    };

    const fallbackText = fallbackResponses[reason] || this.getBasicFallbackResponse();

    return {
      success: false,
      response: fallbackText,
      intent: 'system_fallback',
      confidence: 0,
      requiresHuman: true,
      suggestions: ['Reformular consulta', 'Contactar WhatsApp', 'Ver catálogo'],
      products: [],
      fallback: true,
      metadata: {
        reason,
        originalMessage: originalMessage?.substring(0, 100),
        ...metadata
      }
    };
  }

  getBasicFallbackResponse() {
    return `Disculpa, tengo dificultades para procesar tu consulta.

**Asistencia inmediata:**
📱 WhatsApp: https://wa.me/573009291156
🌐 Catálogo: https://www.judaicabreslovcolombia.com

¿Puedes intentar reformular tu pregunta?`;
  }

  updateAverageConfidence(newConfidence) {
    if (this.stats.successfulResponses === 1) {
      this.stats.averageConfidence = newConfidence;
    } else {
      this.stats.averageConfidence = (
        (this.stats.averageConfidence * (this.stats.successfulResponses - 1) + newConfidence) / 
        this.stats.successfulResponses
      );
    }
  }

  getSystemInfo() {
    const componentStatus = {};
    Object.entries(this.components).forEach(([name, component]) => {
      componentStatus[name] = {
        initialized: !!component,
        type: component?.constructor?.name || 'null',
        integrated: name === 'productSearch' ? {
          hasSynonymManager: !!component?.synonymManager,
          hasNlpUtils: !!component?.nlpUtils
        } : undefined
      };
    });

    return {
      isInitialized: this.isInitialized,
      isInitializing: this.isInitializing,
      initializationError: this.initializationError?.message || null,
      components: componentStatus,
      config: this.config,
      stats: {
        ...this.stats,
        successRate: this.stats.totalMessages > 0 ? 
          (this.stats.successfulResponses / this.stats.totalMessages * 100).toFixed(2) + '%' : '0%',
        errorRate: this.stats.totalMessages > 0 ? 
          (this.stats.errors / this.stats.totalMessages * 100).toFixed(2) + '%' : '0%',
        fallbackRate: this.stats.totalMessages > 0 ? 
          (this.stats.fallbackResponses / this.stats.totalMessages * 100).toFixed(2) + '%' : '0%'
      },
      integration: {
        synonymManagerConnected: !!this.components.productSearch?.synonymManager,
        nlpUtilsConnected: !!this.components.productSearch?.nlpUtils,
        fullIntegrationActive: !!(this.components.productSearch?.synonymManager && this.components.productSearch?.nlpUtils)
      },
      health: this.getHealthStatus()
    };
  }

  getHealthStatus() {
    let score = 0;
    let issues = [];

    if (this.isInitialized) score += 25;
    else issues.push('Not initialized');

    if (this.components.intentClassifier) score += 20;
    else issues.push('Intent classifier missing');

    if (this.components.responseGenerator) score += 20;
    else issues.push('Response generator missing');

    if (this.components.productSearch) score += 15;
    else issues.push('Product search missing');

    if (this.components.synonymManager) score += 10;
    else issues.push('Synonym manager missing');

    if (this.components.nlpUtils) score += 10;
    else issues.push('NLP utils missing');

    // Bonus por integración completa
    if (this.components.productSearch?.synonymManager && this.components.productSearch?.nlpUtils) {
      score += 10;
    } else {
      issues.push('Product search not fully integrated');
    }

    let status = 'critical';
    if (score >= 95) status = 'excellent';
    else if (score >= 80) status = 'good';
    else if (score >= 60) status = 'degraded';
    else if (score >= 40) status = 'poor';

    return {
      status,
      score,
      issues,
      canProcess: this.isInitialized && (this.components.intentClassifier || this.components.responseGenerator),
      isFullyIntegrated: !!(this.components.productSearch?.synonymManager && this.components.productSearch?.nlpUtils)
    };
  }

  clearCache(type = 'all') {
    if (type === 'all' || type === 'products') {
      if (this.components.productSearch) {
        this.components.productSearch.clearCache();
      }
    }
    if (type === 'all' || type === 'synonyms') {
      if (this.components.synonymManager) {
        this.components.synonymManager.clearCache();
      }
    }
    if (type === 'all' || type === 'intents') {
      if (this.components.intentClassifier) {
        this.components.intentClassifier.clearCache();
      }
    }
    
    console.log(`🧹 Cache limpiado: ${type}`);
  }

  async reinitialize() {
    console.log('🔄 Reinicializando motor del chatbot integrado...');
    
    this.isInitialized = false;
    this.isInitializing = false;
    this.initializationError = null;
    
    this.components = {
      intentClassifier: null,
      synonymManager: null,
      responseGenerator: null,
      nlpUtils: null,
      productSearch: null
    };
    
    this.clearCache();
    
    return await this.initialize();
  }

  getStats() {
    return {
      ...this.stats,
      uptime: this.stats.initTime ? Date.now() - this.stats.initTime : 0,
      memoryUsage: process.memoryUsage ? process.memoryUsage() : null,
      integration: {
        synonymsLoaded: this.components.synonymManager ? 
          this.components.synonymManager.getStats() : null,
        nlpActive: !!this.components.nlpUtils,
        productSearchStats: this.components.productSearch ? 
          this.components.productSearch.getSearchStats() : null
      }
    };
  }

  async shutdown() {
    console.log('🛑 Cerrando motor del chatbot integrado...');
    
    this.isInitialized = false;
    this.clearCache();
    
    // Cleanup de todos los componentes
    if (this.components.synonymManager?.cleanup) {
      await this.components.synonymManager.cleanup();
    }
    
    if (this.components.nlpUtils?.cleanup) {
      await this.components.nlpUtils.cleanup();
    }

    if (this.components.productSearch?.clearCache) {
      this.components.productSearch.clearCache();
    }
    
    this.components = {
      intentClassifier: null,
      synonymManager: null,
      responseGenerator: null,
      nlpUtils: null,
      productSearch: null
    };
    
    console.log('✅ Motor integrado cerrado correctamente');
  }

  // Métodos específicos para usar la integración completa
  async searchProductsByCategory(category, limit = 6) {
    if (!this.components.productSearch) return [];
    return await this.components.productSearch.searchByCategory ? 
      this.components.productSearch.searchByCategory(category, limit) :
      this.components.productSearch.getPopularProducts(limit);
  }

  async getPopularProducts(limit = 6) {
    if (!this.components.productSearch) return [];
    return await this.components.productSearch.getPopularProducts(limit);
  }

  async findSimilarProducts(productName, limit = 4) {
    if (!this.components.productSearch || !this.components.synonymManager) {
      return [];
    }
    
    try {
      // Usar synonymManager para encontrar términos relacionados
      const synonymData = await this.components.synonymManager.getSynonymsForTerm(productName);
      let searchTerms = [productName];
      
      if (synonymData) {
        searchTerms.push(...(synonymData.variations || []).slice(0, 3));
        searchTerms.push(...(synonymData.related || []).slice(0, 2));
      }
      
      return await this.components.productSearch.searchProducts(searchTerms, { type: 'similarity' }, limit);
      
    } catch (error) {
      console.error('❌ Error buscando productos similares:', error);
      return [];
    }
  }

  // Método de diagnóstico completo
  async diagnoseIntegration() {
    const diagnosis = {
      systemHealth: this.getHealthStatus(),
      components: {},
      integration: {},
      performance: this.getStats(),
      recommendations: []
    };

    // Test de componentes individuales
    for (const componentName of Object.keys(this.components)) {
      diagnosis.components[componentName] = await this.testComponent(componentName);
    }

    // Test de integración
    diagnosis.integration = {
      synonymsToProductSearch: false,
      nlpToProductSearch: false,
      fullPipeline: false
    };

    try {
      // Test búsqueda con sinónimos
      if (this.components.productSearch && this.components.synonymManager) {
        const testResult = await this.components.productSearch.searchProducts(['emunah'], {type: 'test'}, 1);
        diagnosis.integration.synonymsToProductSearch = testResult.length > 0;
      }

      // Test pipeline completo
      const testMessage = await this.processMessage('precio de emunah', 'test', 'test-session', {});
      diagnosis.integration.fullPipeline = testMessage.success && testMessage.products.length > 0;

    } catch (integrationError) {
      diagnosis.integration.error = integrationError.message;
    }

    // Recomendaciones
    if (!diagnosis.integration.fullPipeline) {
      diagnosis.recommendations.push('Pipeline completo no funciona - revisar integración');
    }
    if (!diagnosis.integration.synonymsToProductSearch) {
      diagnosis.recommendations.push('Sinónimos no están conectados a búsqueda de productos');
    }
    if (diagnosis.components.productSearch && !diagnosis.components.productSearch.success) {
      diagnosis.recommendations.push('Motor de búsqueda de productos tiene problemas');
    }

    return diagnosis;
  }

  async testComponent(componentName) {
    const component = this.components[componentName];
    if (!component) {
      return { success: false, error: `Component ${componentName} not found` };
    }

    try {
      switch (componentName) {
        case 'intentClassifier':
          const intent = await component.classify('precio de libro', {});
          return { success: !!intent.type, data: intent };
          
        case 'synonymManager':
          const synonyms = await component.getSynonymsForTerm('emunah');
          return { success: !!synonyms, data: synonyms };
          
        case 'responseGenerator':
          const response = await component.generate({
            intent: { type: 'price_inquiry', confidence: 1.0 },
            searchResults: [],
            conversationContext: {},
            sessionId: 'test'
          });
          return { success: !!response.text, data: response };
          
        case 'nlpUtils':
          const analysis = component.analyzeTextCompletely('test emunah book');
          return { success: !!analysis, data: analysis };

        case 'productSearch':
          const products = await component.searchProducts(['emunah'], { type: 'test' }, 3);
          return { 
            success: Array.isArray(products), 
            data: products,
            integrated: {
              hasSynonymManager: !!component.synonymManager,
              hasNlpUtils: !!component.nlpUtils
            }
          };
          
        default:
          return { success: false, error: 'Unknown component' };
      }
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
}