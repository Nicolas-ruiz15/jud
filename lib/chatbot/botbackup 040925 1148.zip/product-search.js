// lib/chatbot/product-search.js - INTEGRADO CON SYNONYMS.JS Y NLP-UTILS.JS

import { query } from '../database';

export class IntelligentProductSearch {
  constructor(synonymManager = null, nlpUtils = null) {
    this.searchCache = new Map();
    this.cacheTimeout = 5 * 60 * 1000;
    
    // USAR los managers que ya tienes
    this.synonymManager = synonymManager;
    this.nlpUtils = nlpUtils;
    
    // Solo sinónimos básicos como fallback
    this.basicSynonyms = {
      'emunah': ['emuna', 'vivamos con emunah'],
      'torah': ['torá', 'tora', 'la torah explicada'],
      'tehilim': ['salmos', 'interlineal'],
      'tefilin': ['tefilín', 'filacterias'],
      'tallit': ['talit', 'tzitzit'],
      'mezuzah': ['mezuzá', 'pergamino'],
      'kipa': ['kipá', 'yarmulke']
    };
  }

  async searchProducts(searchTerms, intent, limit = 10) {
    try {
      console.log(`🔍 Búsqueda inteligente para: ${searchTerms}`);

      // 1. USAR synonymManager para expandir términos
      const expandedTerms = await this.expandSearchTermsWithManager(searchTerms);
      console.log(`📋 Términos expandidos: ${expandedTerms.join(', ')}`);

      // 2. Construir query optimizada para tu BD
      const searchQuery = this.buildOptimizedQuery(expandedTerms, limit);
      
      // 3. Ejecutar búsqueda en tu BD real
      const results = await query(searchQuery.sql, searchQuery.params);
      
      // 4. Procesar resultados con enlaces reales
      const processedResults = this.processResultsWithLinks(results, searchTerms);
      
      console.log(`✅ Encontrados ${processedResults.length} productos de ${results.length} en BD`);
      return processedResults;

    } catch (error) {
      console.error('❌ Error en búsqueda inteligente:', error);
      
      // Fallback: búsqueda simple
      return await this.fallbackSearch(searchTerms, limit);
    }
  }

  async expandSearchTermsWithManager(originalTerms) {
    if (typeof originalTerms === 'string') {
      originalTerms = [originalTerms];
    }

    const expandedSet = new Set();
    
    for (const term of originalTerms) {
      const cleanTerm = term.toLowerCase().trim();
      expandedSet.add(cleanTerm);
      
      try {
        // USAR tu synonymManager existente
        if (this.synonymManager) {
          const synonymData = await this.synonymManager.getSynonymsForTerm(cleanTerm);
          if (synonymData) {
            // Agregar variaciones del synonymManager
            synonymData.variations?.forEach(syn => expandedSet.add(syn));
            synonymData.related?.slice(0, 3).forEach(rel => expandedSet.add(rel));
            synonymData.types?.slice(0, 2).forEach(type => expandedSet.add(type));
          }
        }
      } catch (error) {
        console.log(`⚠️ Error con synonymManager para "${cleanTerm}":`, error.message);
      }
      
      // Fallback a sinónimos básicos
      if (this.basicSynonyms[cleanTerm]) {
        this.basicSynonyms[cleanTerm].forEach(syn => expandedSet.add(syn));
      }

      // USAR nlpUtils si está disponible
      try {
        if (this.nlpUtils) {
          const normalizedTerm = this.nlpUtils.normalizeText(cleanTerm);
          if (normalizedTerm && normalizedTerm !== cleanTerm) {
            expandedSet.add(normalizedTerm);
          }
        }
      } catch (error) {
        console.log(`⚠️ Error con nlpUtils para "${cleanTerm}":`, error.message);
      }
    }

    return Array.from(expandedSet).filter(term => term.length > 1);
  }

  buildOptimizedQuery(terms, limit) {
    if (!terms || terms.length === 0) {
      // Query para productos populares cuando no hay términos
      return {
        sql: `
          SELECT 
            id, name, slug, description, short_description, tags, keywords,
            price, sale_price, stock_status, stock_quantity, featured,
            CASE WHEN sale_price > 0 AND sale_price < price THEN sale_price ELSE price END as display_price
          FROM products 
          WHERE status = 'active'
          ORDER BY featured DESC, created_at DESC
          LIMIT ?
        `,
        params: [limit]
      };
    }

    // Construir condiciones de búsqueda múltiples
    const searchConditions = [];
    const params = [];

    terms.forEach(term => {
      // Búsqueda en múltiples campos de tu BD
      searchConditions.push(`(
        name LIKE ? OR 
        description LIKE ? OR 
        short_description LIKE ? OR 
        tags LIKE ? OR 
        keywords LIKE ? OR
        MATCH(name, description) AGAINST(? IN BOOLEAN MODE)
      )`);
      
      const searchPattern = `%${term}%`;
      const booleanPattern = `+${term}*`;
      params.push(searchPattern, searchPattern, searchPattern, searchPattern, searchPattern, booleanPattern);
    });

    params.push(limit);

    return {
      sql: `
        SELECT 
          id, name, slug, description, short_description, tags, keywords,
          price, sale_price, stock_status, stock_quantity, featured,
          CASE WHEN sale_price > 0 AND sale_price < price THEN sale_price ELSE price END as display_price,
          -- Scoring para relevancia
          (
            CASE WHEN name LIKE ? THEN 100 ELSE 0 END +
            CASE WHEN description LIKE ? THEN 50 ELSE 0 END +
            CASE WHEN featured = 1 THEN 25 ELSE 0 END +
            CASE WHEN stock_status = 'in_stock' THEN 15 ELSE 0 END
          ) as relevance_score
        FROM products 
        WHERE status = 'active' 
        AND (${searchConditions.join(' OR ')})
        ORDER BY 
          relevance_score DESC,
          CASE WHEN stock_status = 'in_stock' THEN 1 ELSE 2 END,
          featured DESC,
          display_price ASC
        LIMIT ?
      `,
      params: [
        // Parámetros para scoring
        `%${terms[0]}%`, `%${terms[0]}%`,
        // Parámetros para condiciones de búsqueda
        ...params
      ]
    };
  }

  processResultsWithLinks(results, originalTerms) {
    if (!results || results.length === 0) {
      return [];
    }

    return results.map(product => {
      // Generar slug limpio para URL
      let cleanSlug = product.slug;
      if (!cleanSlug || cleanSlug === 'NULL' || cleanSlug === '') {
        cleanSlug = this.generateSlugFromName(product.name);
      }

      return {
        id: product.id,
        name: product.name,
        description: product.description,
        short_description: product.short_description,
        price: parseFloat(product.price || 0),
        sale_price: parseFloat(product.sale_price || 0),
        display_price: parseFloat(product.display_price || product.price || 0),
        stock_status: product.stock_status || 'in_stock',
        stock_quantity: parseInt(product.stock_quantity || 0),
        featured: product.featured === 1,
        slug: cleanSlug,
        // URLs reales para tu sitio
        url: `https://www.judaicabreslovcolombia.com/producto/${cleanSlug}`,
        category: this.detectProductCategory(product.name, product.description),
        relevance_score: product.relevance_score || 0
      };
    });
  }

  generateSlugFromName(name) {
    if (!name) return 'producto';
    
    return name
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "") // Quitar acentos
      .replace(/[^a-z0-9\s-]/g, '') // Solo letras, números, espacios y guiones
      .trim()
      .replace(/\s+/g, '-') // Espacios a guiones
      .replace(/-+/g, '-') // Múltiples guiones a uno solo
      .substring(0, 100); // Limitar longitud
  }

  detectProductCategory(name, description) {
    const text = `${name} ${description || ''}`.toLowerCase();
    
    // Usar tu synonymManager para detectar categorías si está disponible
    if (this.synonymManager) {
      try {
        const categories = this.synonymManager.detectCategories ? 
          this.synonymManager.detectCategories(text) : [];
        if (categories.length > 0) {
          return categories[0];
        }
      } catch (error) {
        console.log('⚠️ Error detectando categorías:', error.message);
      }
    }

    // Fallback a detección básica
    if (text.includes('libro') || text.includes('torah') || text.includes('talmud')) return 'libros';
    if (text.includes('tefilin') || text.includes('filact')) return 'tefilin';
    if (text.includes('tallit') || text.includes('tzitzit')) return 'tallitot';
    if (text.includes('mezuzah') || text.includes('pergamino')) return 'mezuzot';
    if (text.includes('kipa') || text.includes('yarmulke')) return 'kipot';
    if (text.includes('copa') || text.includes('kidush') || text.includes('vela')) return 'shabat';
    if (text.includes('collar') || text.includes('cadena') || text.includes('anillo')) return 'joyeria';
    
    return 'general';
  }

  // Búsqueda de fallback simple
  async fallbackSearch(searchTerms, limit) {
    try {
      console.log('🆘 Usando búsqueda de fallback');
      
      if (typeof searchTerms === 'string') {
        searchTerms = [searchTerms];
      }
      
      if (searchTerms.length === 0) {
        return await this.getPopularProducts(limit);
      }

      const term = searchTerms[0];
      const results = await query(`
        SELECT 
          id, name, slug, description, short_description,
          price, sale_price, stock_status, featured,
          CASE WHEN sale_price > 0 AND sale_price < price THEN sale_price ELSE price END as display_price
        FROM products 
        WHERE status = 'active' 
        AND (name LIKE ? OR description LIKE ?)
        ORDER BY featured DESC, name ASC
        LIMIT ?
      `, [`%${term}%`, `%${term}%`, limit]);

      return this.processResultsWithLinks(results, searchTerms);
      
    } catch (error) {
      console.error('❌ Error en fallback search:', error);
      return [];
    }
  }

  // Productos populares
  async getPopularProducts(limit = 6) {
    try {
      const results = await query(`
        SELECT 
          id, name, slug, description, short_description,
          price, sale_price, stock_status, featured,
          CASE WHEN sale_price > 0 AND sale_price < price THEN sale_price ELSE price END as display_price
        FROM products 
        WHERE status = 'active'
        ORDER BY featured DESC, created_at DESC
        LIMIT ?
      `, [limit]);

      return this.processResultsWithLinks(results, ['populares']);
      
    } catch (error) {
      console.error('❌ Error obteniendo productos populares:', error);
      return [];
    }
  }

  // Búsqueda rápida
  async quickSearch(searchQuery, limit = 5) {
    try {
      const results = await query(`
        SELECT name, slug, price, sale_price, stock_status,
               CASE WHEN sale_price > 0 AND sale_price < price THEN sale_price ELSE price END as display_price
        FROM products 
        WHERE status = 'active' 
        AND (name LIKE ? OR description LIKE ?)
        ORDER BY featured DESC, name ASC
        LIMIT ?
      `, [`%${searchQuery}%`, `%${searchQuery}%`, limit]);
      
      return this.processResultsWithLinks(results, [searchQuery]);
      
    } catch (error) {
      console.error('Error en búsqueda rápida:', error);
      return [];
    }
  }

  clearCache() {
    this.searchCache.clear();
    console.log('🧹 Cache de búsqueda limpiado');
  }

  getSearchStats() {
    return {
      cacheSize: this.searchCache.size,
      hasNlpUtils: !!this.nlpUtils,
      hasSynonymManager: !!this.synonymManager,
      basicSynonymsCount: Object.keys(this.basicSynonyms).length
    };
  }
}