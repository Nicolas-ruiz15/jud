// pages/api/chat/send.js - API CORREGIDA

import { getChatbotInstance } from '../../../lib/chatbot/chatbotInstance';
import { query } from '../../../lib/database';
import { v4 as uuidv4 } from 'uuid';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ 
      error: 'Método no permitido',
      success: false 
    });
  }

  const startTime = Date.now();
  let chatbotInstance = null;

  try {
    console.log('📨 Nueva solicitud de chat recibida');

    const { 
      message, 
      sessionId, 
      conversationId,
      userInfo = {},
      context = {}
    } = req.body;

    // Validaciones básicas
    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      return res.status(400).json({
        error: 'Mensaje requerido',
        success: false
      });
    }

    if (message.length > 1000) {
      return res.status(400).json({
        error: 'Mensaje demasiado largo (máximo 1000 caracteres)',
        success: false
      });
    }

    const finalSessionId = sessionId || `session_${uuidv4()}`;
    const finalConversationId = conversationId || `conv_${uuidv4()}`;

    console.log(`💬 Procesando: "${message.substring(0, 50)}..." (Sesión: ${finalSessionId.substring(0, 20)})`);

    // Obtener instancia del chatbot con mejor manejo de errores
    try {
      chatbotInstance = await getChatbotInstance();
      console.log('✅ Instancia del chatbot obtenida');
    } catch (chatbotError) {
      console.error('❌ Error obteniendo instancia del chatbot:', chatbotError);
      return res.status(503).json({
        error: 'Chatbot no disponible temporalmente',
        success: false,
        fallbackResponse: {
          text: `Disculpa, nuestro asistente está inicializando.

**Para asistencia inmediata:**
📱 WhatsApp: https://wa.me/573009291156
🌐 Tienda: https://www.judaicabreslovcolombia.com

Por favor intenta nuevamente en unos segundos.`,
          suggestions: ['Reintentar', 'WhatsApp directo', 'Ver tienda'],
          requiresHuman: true
        }
      });
    }

    // Obtener contexto conversacional
    const conversationContext = await getConversationContext(finalSessionId, finalConversationId);

    // Contexto mejorado
    const enhancedContext = {
      ...conversationContext,
      userInfo,
      requestContext: {
        userAgent: req.headers['user-agent'],
        ip: req.headers['x-forwarded-for'] || req.connection.remoteAddress,
        timestamp: new Date().toISOString(),
        ...context
      }
    };

    // Guardar mensaje del usuario
    const userMessageId = await saveUserMessage({
      conversationId: finalConversationId,
      sessionId: finalSessionId,
      message: message.trim(),
      userInfo,
      context: enhancedContext
    });

    console.log('💾 Mensaje del usuario guardado:', userMessageId);

    // Procesar mensaje con el chatbot
    let chatbotResponse;
    try {
      chatbotResponse = await chatbotInstance.processMessage(
        message.trim(),
        finalConversationId,
        finalSessionId,
        enhancedContext
      );
      console.log('🤖 Respuesta del chatbot generada');
    } catch (processingError) {
      console.error('❌ Error procesando mensaje:', processingError);
      
      chatbotResponse = {
        success: false,
        response: `Disculpa, hay un problema temporal.

**Asistencia directa:**
📱 WhatsApp: https://wa.me/573009291156
🌐 https://www.judaicabreslovcolombia.com

¿Puedes reformular tu consulta?`,
        intent: 'processing_error',
        confidence: 0,
        requiresHuman: true,
        suggestions: ['Reformular pregunta', 'WhatsApp directo', 'Ver tienda'],
        products: [],
        fallback: true,
        error: processingError.message
      };
    }

    // Guardar respuesta del bot
    const botMessageId = await saveBotMessage({
      conversationId: finalConversationId,
      sessionId: finalSessionId,
      response: chatbotResponse.response,
      intent: chatbotResponse.intent,
      confidence: chatbotResponse.confidence,
      requiresHuman: chatbotResponse.requiresHuman,
      suggestions: chatbotResponse.suggestions,
      products: chatbotResponse.products,
      metadata: chatbotResponse.metadata
    });

    console.log('💾 Respuesta del bot guardada:', botMessageId);

    // Actualizar contexto de conversación
    await updateConversationContext({
      sessionId: finalSessionId,
      conversationId: finalConversationId,
      lastIntent: chatbotResponse.intent,
      lastConfidence: chatbotResponse.confidence,
      messageCount: (conversationContext.messageCount || 0) + 1,
      lastProducts: chatbotResponse.products || []
    });

    const processingTime = Date.now() - startTime;
    
    console.log(`✅ Solicitud completada en ${processingTime}ms`);

    return res.status(200).json({
      success: true,
      response: {
        text: chatbotResponse.response,
        intent: chatbotResponse.intent,
        confidence: chatbotResponse.confidence,
        requiresHuman: chatbotResponse.requiresHuman || false,
        suggestions: chatbotResponse.suggestions || [],
        products: chatbotResponse.products || [],
        metadata: {
          ...(chatbotResponse.metadata || {}),
          processingTime,
          sessionId: finalSessionId,
          conversationId: finalConversationId,
          messageId: botMessageId,
          timestamp: new Date().toISOString()
        }
      },
      context: {
        sessionId: finalSessionId,
        conversationId: finalConversationId,
        messageCount: (conversationContext.messageCount || 0) + 1
      }
    });

  } catch (error) {
    const processingTime = Date.now() - startTime;
    console.error('❌ Error crítico en API send:', error);

    // Log del error
    try {
      await logCriticalError(error, req.body, processingTime);
    } catch (logError) {
      console.error('❌ No se pudo guardar el error en BD:', logError);
    }

    return res.status(500).json({
      error: 'Error interno del servidor',
      success: false,
      fallbackResponse: {
        text: `Error temporal del sistema.

**Contacto directo:**
📱 WhatsApp: https://wa.me/573009291156
🌐 Tienda: https://www.judaicabreslovcolombia.com

Nuestros especialistas te ayudarán inmediatamente.`,
        suggestions: ['WhatsApp directo', 'Ver tienda', 'Reintentar'],
        requiresHuman: true
      },
      metadata: {
        processingTime,
        timestamp: new Date().toISOString(),
        errorType: error.name || 'UnknownError'
      }
    });
  }
}

async function getConversationContext(sessionId, conversationId) {
  try {
    const conversationData = await query(`
      SELECT * FROM chat_conversations 
      WHERE session_id = ? OR id = ?
      ORDER BY created_at DESC 
      LIMIT 1
    `, [sessionId, conversationId]);

    const recentMessages = await query(`
      SELECT message_content, intent_type, bot_confidence, sender_type, created_at
      FROM chat_messages 
      WHERE session_id = ?
      ORDER BY created_at DESC 
      LIMIT 5
    `, [sessionId]);

    return {
      conversation: conversationData[0] || null,
      recentMessages: recentMessages || [],
      messageCount: recentMessages.length,
      lastIntent: recentMessages[0]?.intent_type || null,
      lastConfidence: recentMessages[0]?.bot_confidence || 0,
      sessionAge: conversationData[0] ? 
        Date.now() - new Date(conversationData[0].created_at).getTime() : 0
    };
  } catch (error) {
    console.error('❌ Error obteniendo contexto conversacional:', error);
    return {
      conversation: null,
      recentMessages: [],
      messageCount: 0,
      lastIntent: null,
      lastConfidence: 0,
      sessionAge: 0
    };
  }
}

async function saveUserMessage({ conversationId, sessionId, message, userInfo, context }) {
  try {
    await ensureConversationExists(conversationId, sessionId, userInfo);

    const result = await query(`
      INSERT INTO chat_messages (
        conversation_id, session_id, sender_type, sender_id, sender_name,
        message_type, message_content, metadata, ip_address, user_agent, created_at
      ) VALUES (?, ?, 'user', ?, ?, 'text', ?, ?, ?, ?, NOW())
    `, [
      conversationId,
      sessionId,
      userInfo.id || null,
      userInfo.name || 'Usuario',
      message,
      JSON.stringify(context),
      context.requestContext?.ip || null,
      context.requestContext?.userAgent || null
    ]);

    return result.insertId;
  } catch (error) {
    console.error('❌ Error guardando mensaje de usuario:', error);
    return null;
  }
}

async function saveBotMessage({ conversationId, sessionId, response, intent, confidence, requiresHuman, suggestions, products, metadata }) {
  try {
    const result = await query(`
      INSERT INTO chat_messages (
        conversation_id, session_id, sender_type, sender_id, sender_name,
        message_type, message_content, metadata, is_automated, bot_confidence,
        requires_human, intent_type, processing_time_ms, ai_engine_version, created_at
      ) VALUES (?, ?, 'bot', 'system', 'Asistente Judaica Breslov', 'text', ?, ?, 1, ?, ?, ?, ?, 'enhanced-v2.1', NOW())
    `, [
      conversationId,
      sessionId,
      response,
      JSON.stringify({
        suggestions: suggestions || [],
        products: products || [],
        metadata: metadata || {}
      }),
      confidence || 0,
      requiresHuman ? 1 : 0,
      intent || 'unknown',
      metadata?.processingTime || 0
    ]);

    return result.insertId;
  } catch (error) {
    console.error('❌ Error guardando respuesta del bot:', error);
    return null;
  }
}

async function ensureConversationExists(conversationId, sessionId, userInfo) {
  try {
    const existing = await query(`
      SELECT id FROM chat_conversations WHERE session_id = ? OR id = ?
    `, [sessionId, conversationId]);

    if (existing.length === 0) {
      await query(`
        INSERT INTO chat_conversations (
          session_id, visitor_name, visitor_email, ip_address, 
          user_agent, status, priority, department, created_at, last_message_at
        ) VALUES (?, ?, ?, ?, ?, 'active', 'normal', 'sales', NOW(), NOW())
      `, [
        sessionId,
        userInfo.name || 'Usuario Anónimo',
        userInfo.email || null,
        userInfo.ip || null,
        userInfo.userAgent || null
      ]);
    } else {
      await query(`
        UPDATE chat_conversations 
        SET last_message_at = NOW(), message_count = message_count + 1
        WHERE session_id = ? OR id = ?
      `, [sessionId, conversationId]);
    }
  } catch (error) {
    console.error('❌ Error asegurando existencia de conversación:', error);
  }
}

async function updateConversationContext({ sessionId, conversationId, lastIntent, lastConfidence, messageCount, lastProducts }) {
  try {
    await query(`
      UPDATE chat_conversations 
      SET 
        message_count = ?,
        last_message_at = NOW(),
        tags = JSON_SET(COALESCE(tags, '{}'), '$.lastIntent', ?, '$.lastConfidence', ?, '$.lastProducts', ?)
      WHERE session_id = ? OR id = ?
    `, [
      messageCount,
      lastIntent,
      lastConfidence,
      JSON.stringify(lastProducts),
      sessionId,
      conversationId
    ]);
  } catch (error) {
    console.error('❌ Error actualizando contexto conversacional:', error);
  }
}

async function logCriticalError(error, requestData, processingTime) {
  try {
    // Verificar si la tabla existe
    const tableExists = await query("SHOW TABLES LIKE 'chat_critical_errors'");
    if (tableExists.length === 0) {
      console.warn('⚠️ Tabla chat_critical_errors no existe');
      return;
    }

    await query(`
      INSERT INTO chat_critical_errors 
      (error_message, error_stack, request_data, processing_time, created_at) 
      VALUES (?, ?, ?, ?, NOW())
    `, [
      error.message,
      error.stack,
      JSON.stringify(requestData),
      processingTime
    ]);
  } catch (logError) {
    console.error('❌ Error guardando log crítico:', logError);
  }
}

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '1mb',
    },
  },
};